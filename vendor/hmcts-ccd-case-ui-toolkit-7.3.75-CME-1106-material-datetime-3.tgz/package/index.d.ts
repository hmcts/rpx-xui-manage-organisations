import * as i0 from '@angular/core';
import { OnInit, OnDestroy, PipeTransform, EventEmitter, AfterContentInit, QueryList, ElementRef, InjectionToken, NgZone, OnChanges, SimpleChanges, ChangeDetectorRef, Type, ViewContainerRef, ComponentFactoryResolver, AfterViewInit, Renderer2, ModuleWithProviders, Injector, TemplateRef, RendererFactory2, AfterViewChecked } from '@angular/core';
import * as i2 from '@angular/common';
import { AsyncPipe, Location as Location$1 } from '@angular/common';
import * as i3 from '@angular/router';
import { ActivatedRoute, CanActivate, Router, ActivatedRouteSnapshot, Resolve, Routes, Navigation } from '@angular/router';
import * as i7 from 'rpx-xui-translation';
import { RpxTranslationService, RpxTranslatePipe } from 'rpx-xui-translation';
import * as i3$1 from '@angular/forms';
import { ControlValueAccessor, Validator, FormControl, AbstractControl, ValidationErrors, FormGroup, FormArray, ValidatorFn, FormBuilder } from '@angular/forms';
import * as rxjs from 'rxjs';
import { Observable, Subject, ConnectableObservable, BehaviorSubject, Subscribable, Subscription } from 'rxjs';
import { HttpErrorResponse, HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable as Observable$1 } from 'rxjs-compat';
import * as i144 from '@angular/material/dialog';
import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material/dialog';
import { State, StateMachine } from '@edium/fsm';
import * as i16 from '@angular/cdk/portal';
import * as i135 from '@ngxmc/datetime-picker';
import { NgxMatDatetimepicker } from '@ngxmc/datetime-picker';
import { ThemePalette, MatDateFormats } from '@angular/material/core';
import { Moment } from 'moment/moment';
import * as i140 from '@angular/cdk/tree';
import { NestedTreeControl } from '@angular/cdk/tree';
import { DomSanitizer } from '@angular/platform-browser';
import * as i6 from 'ngx-markdown';
import * as i136 from '@angular/material/form-field';
import * as i137 from '@angular/material/input';
import * as i138 from '@angular/material/datepicker';
import * as i139 from '@angular/material/autocomplete';
import * as i141 from '@angular/cdk/overlay';
import * as i142 from '@hmcts/ccpay-web-component';
import * as i145 from '@hmcts/media-viewer';
import * as i3$2 from 'ngx-pagination';
import * as i25 from '@angular/material/tabs';
import { MatTabGroup } from '@angular/material/tabs';

declare class FooterComponent {
    email: string;
    isSolicitor: boolean;
    phone: string;
    workhours: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FooterComponent, "cut-footer-bar", never, { "email": { "alias": "email"; "required": false; }; "isSolicitor": { "alias": "isSolicitor"; "required": false; }; "phone": { "alias": "phone"; "required": false; }; "workhours": { "alias": "workhours"; "required": false; }; }, {}, never, ["[footerSolsNavLinks]", "[footerCaseWorkerNavLinks]"], false, never>;
}

declare class HeaderBarComponent {
    title: string;
    isSolicitor: boolean;
    username: string;
    private readonly signOutRequest;
    signOut(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HeaderBarComponent, "cut-header-bar", never, { "title": { "alias": "title"; "required": false; }; "isSolicitor": { "alias": "isSolicitor"; "required": false; }; "username": { "alias": "username"; "required": false; }; }, { "signOutRequest": "signOutRequest"; }, never, ["[headerNavigation]"], false, never>;
}

declare class NavigationComponent {
    isSolicitor: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavigationComponent, "cut-nav-bar", never, { "isSolicitor": { "alias": "isSolicitor"; "required": false; }; }, {}, never, ["[leftNavLinks]", "[rightNavLinks]"], false, never>;
}

declare class NavigationItemComponent {
    label: string;
    link: string;
    imageLink: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NavigationItemComponent, "cut-nav-item", never, { "label": { "alias": "label"; "required": false; }; "link": { "alias": "link"; "required": false; }; "imageLink": { "alias": "imageLink"; "required": false; }; }, {}, never, never, false, never>;
}

declare class PhaseComponent {
    phaseLabel: string;
    phaseLink: string;
    isSolicitor: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<PhaseComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PhaseComponent, "cut-phase-bar", never, { "phaseLabel": { "alias": "phaseLabel"; "required": false; }; "phaseLink": { "alias": "phaseLink"; "required": false; }; "isSolicitor": { "alias": "isSolicitor"; "required": false; }; }, {}, never, never, false, never>;
}

declare class HeadersModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<HeadersModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<HeadersModule, [typeof PhaseComponent, typeof HeaderBarComponent, typeof NavigationComponent, typeof NavigationItemComponent], [typeof i2.CommonModule, typeof i3.RouterModule, typeof i7.RpxTranslationModule], [typeof PhaseComponent, typeof HeaderBarComponent, typeof NavigationComponent, typeof NavigationItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<HeadersModule>;
}

declare class BodyComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<BodyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BodyComponent, "cut-body", never, {}, {}, never, ["[topBody]", "[leftBody]", "[rightBody]"], false, never>;
}

declare class DateInputComponent implements ControlValueAccessor, Validator, OnInit, OnDestroy {
    id: string;
    mandatory: boolean;
    isDateTime: boolean;
    formControl: FormControl;
    isInvalid: boolean;
    isTouched: boolean;
    displayDay: string;
    displayMonth: string;
    displayYear: string;
    displayHour: string;
    displayMinute: string;
    displaySecond: string;
    private readonly DATE_FORMAT;
    private propagateChange;
    private rawValue;
    private day;
    private month;
    private year;
    private hour;
    private minute;
    private second;
    ngOnInit(): void;
    writeValue(obj: string): void;
    validate(control: AbstractControl): ValidationErrors;
    registerOnChange(fn: any): void;
    registerOnTouched(fn: any): void;
    ngOnDestroy(): void;
    dayChange(value: string): void;
    monthChange(value: string): void;
    yearChange(value: string): void;
    hourChange(value: string): void;
    minuteChange(value: string): void;
    secondChange(value: string): void;
    inputFocus(): void;
    touch(): void;
    dayId(): string;
    monthId(): string;
    yearId(): string;
    hourId(): string;
    minuteId(): string;
    secondId(): string;
    private viewValue;
    private isDateFormat;
    private pad;
    private getValueForValidation;
    private removeMilliseconds;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateInputComponent, "cut-date-input", never, { "id": { "alias": "id"; "required": false; }; "mandatory": { "alias": "mandatory"; "required": false; }; "isDateTime": { "alias": "isDateTime"; "required": false; }; "formControl": { "alias": "formControl"; "required": false; }; "isInvalid": { "alias": "isInvalid"; "required": false; }; }, {}, never, never, false, never>;
}

declare enum AlertMessageType {
    WARNING = "warning",
    SUCCESS = "success",
    ERROR = "error",
    INFORMATION = "information"
}
declare class AlertComponent {
    static readonly TYPE_WARNING = "warning";
    static readonly TYPE_SUCCESS = "success";
    static readonly TYPE_ERROR = "error";
    static readonly TYPE_INFORMATION = "information";
    type: AlertMessageType;
    showIcon: boolean;
    alertMessageType: typeof AlertMessageType;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AlertComponent, "cut-alert", never, { "type": { "alias": "type"; "required": false; }; "showIcon": { "alias": "showIcon"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class AlertIconClassPipe implements PipeTransform {
    private static readonly CLASS_WARNING;
    private static readonly CLASS_SUCCESS;
    transform(type: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertIconClassPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<AlertIconClassPipe, "cutAlertIconClass", false>;
}

declare class AlertModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AlertModule, [typeof AlertComponent, typeof AlertIconClassPipe], [typeof i2.CommonModule, typeof i7.RpxTranslationModule], [typeof AlertComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AlertModule>;
}

declare enum NotificationBannerType {
    WARNING = "warning",
    SUCCESS = "success",
    ERROR = "error",
    INFORMATION = "information"
}

interface NotificationBannerConfig {
    bannerType: NotificationBannerType;
    headingText: string;
    description: string;
    showLink: boolean;
    linkUrl?: string;
    linkText?: string;
    triggerOutputEvent?: boolean;
    triggerOutputEventText?: string;
    headerClass: string;
}

declare enum NotificationBannerHeaderClass {
    INFORMATION = "notification-banner-information",
    ERROR = "notification-banner-error",
    SUCCESS = "notification-banner-warning",
    WARNING = "notification-banner-success"
}

declare class NotificationBannerComponent {
    notificationBannerConfig: NotificationBannerConfig;
    linkClicked: EventEmitter<string>;
    get notificationBannerType(): typeof NotificationBannerType;
    onLinkClick(triggerOutputEventText: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationBannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotificationBannerComponent, "ccd-notification-banner", never, { "notificationBannerConfig": { "alias": "notificationBannerConfig"; "required": false; }; }, { "linkClicked": "linkClicked"; }, never, never, false, never>;
}

declare class TabComponent {
    id: string;
    title: string;
    selected: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabComponent, "cut-tab", never, { "id": { "alias": "id"; "required": false; }; "title": { "alias": "title"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class TabsComponent implements AfterContentInit {
    private readonly route;
    tabs: QueryList<ElementRef>;
    panels: QueryList<TabComponent>;
    private readonly panelIds;
    constructor(route: ActivatedRoute);
    ngAfterContentInit(): void;
    show(id: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TabsComponent, "cut-tabs", never, {}, {}, ["panels"], ["*"], false, never>;
}

declare class TabsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TabsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TabsModule, [typeof TabsComponent, typeof TabComponent], [typeof i2.CommonModule, typeof i3.RouterModule, typeof i7.RpxTranslationModule], [typeof TabsComponent, typeof TabComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TabsModule>;
}

declare class ActivityBannerComponent implements OnInit {
    bannerType: string;
    description: string;
    imageLink: string;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActivityBannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActivityBannerComponent, "ccd-activity-banner", never, { "bannerType": { "alias": "bannerType"; "required": false; }; "description": { "alias": "description"; "required": false; }; "imageLink": { "alias": "imageLink"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ActivityIconComponent implements OnInit {
    description: string;
    imageLink: string;
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActivityIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActivityIconComponent, "ccd-activity-icon", never, { "description": { "alias": "description"; "required": false; }; "imageLink": { "alias": "imageLink"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ActivityInfo {
    forename: string;
    surname: string;
}
declare class Activity {
    caseId: string;
    viewers: ActivityInfo[];
    editors: ActivityInfo[];
    unknownViewers: number;
    unknownEditors: number;
}
declare enum DisplayMode {
    BANNER = 0,
    ICON = 1
}

interface AccessManagementBasicViewMockModel {
    active?: boolean;
    basicFields?: {
        caseNameHmctsInternal?: string;
        caseManagementLocation?: {
            baseLocation?: number;
        };
    };
    accessProcess?: string;
}
interface AccessManagementRequestReviewMockModel {
    active?: boolean;
    details?: {
        caseName: string;
        caseReference: string;
        dateSubmitted: string;
        requestFrom: string;
        reasonForCaseAccess: string;
    };
    accessProcess?: string;
}
declare abstract class AbstractAppConfig {
    abstract load(): Promise<void>;
    abstract getLoginUrl(): string;
    abstract getApiUrl(): string;
    abstract getCaseDataUrl(): string;
    abstract getDocumentManagementUrl(): string;
    abstract getDocumentManagementUrlV2(): string;
    abstract getCdamExclusionList(): string;
    abstract getDocumentSecureModeCaseTypeExclusions(): string;
    abstract getRemoteDocumentManagementUrl(): string;
    abstract getHrsUrl(): string;
    abstract getRemoteHrsUrl(): string;
    abstract getAnnotationApiUrl(): string;
    abstract getPostcodeLookupUrl(): string;
    abstract getOAuth2ClientId(): string;
    abstract getPaymentsUrl(): string;
    abstract getPayBulkScanBaseUrl(): string;
    abstract getCreateOrUpdateDraftsUrl(ctid: string): string;
    abstract getViewOrDeleteDraftsUrl(did: string): string;
    abstract getActivityUrl(): string;
    abstract getActivityNexPollRequestMs(): number;
    abstract getActivityRetry(): number;
    abstract getTimeoutsForCaseRetrieval(): number[];
    abstract getTimeoutsCaseRetrievalArtificialDelay(): number;
    abstract getActivityBatchCollectionDelayMs(): number;
    abstract getActivityMaxRequestPerBatch(): number;
    abstract getCaseHistoryUrl(caseId: string, eventId: string): string;
    abstract getPrintServiceUrl(): string;
    abstract getIcpEnable(): boolean;
    abstract getIcpJurisdictions(): string[];
    abstract logMessage(logMessage: string): void;
    abstract getEnableServiceSpecificMultiFollowups(): string[];
    /**
     * Dummy version replacing deprecated `getRemotePrintServiceUrl()`, to be removed in next major release
     * @deprecated
     * @returns `undefined`
     */
    getRemotePrintServiceUrl(): string;
    abstract getPaginationPageSize(): number;
    abstract getBannersUrl(): string;
    abstract getPrdUrl(): string;
    abstract getCacheTimeOut(): number;
    abstract getWorkAllocationApiUrl(): string;
    getUserInfoApiUrl(): string;
    getWAServiceConfig(): any;
    getAccessManagementBasicViewMock(): AccessManagementBasicViewMockModel;
    getAccessManagementRequestReviewMockModel(): AccessManagementRequestReviewMockModel;
    getLocationRefApiUrl(): string;
    getEnvironment(): "aat" | "preview" | "demo" | "ithc" | "prod";
    abstract getRefundsUrl(): string;
    abstract getNotificationUrl(): string;
    abstract getPaymentReturnUrl(): string;
    abstract getCategoriesAndDocumentsUrl(): string;
    abstract getDocumentDataUrl(): string;
    getCamRoleAssignmentsApiUrl(): string;
    abstract getCaseFlagsRefdataApiUrl(): string;
    abstract getRDCommonDataApiUrl(): string;
    abstract getCaseDataStoreApiUrl(): string;
    abstract getEventsToHide(): string[];
}
declare class CaseEditorConfig {
    api_url: string;
    case_data_url: string;
    document_management_url: string;
    document_management_url_v2: string;
    hrs_url: string;
    document_management_secure_enabled: boolean;
    documentSecureModeCaseTypeExclusions: string;
    mc_cdam_exclusion_list: string;
    login_url: string;
    oauth2_client_id: string;
    postcode_lookup_url: string;
    remote_document_management_url: string;
    remote_hrs_url: string;
    annotation_api_url: string;
    payments_url: string;
    pay_bulk_scan_url: string;
    activity_batch_collection_delay_ms: number;
    activity_next_poll_request_ms: number;
    activity_retry: number;
    timeouts_case_retrieval: number[];
    timeouts_case_retrieval_artificial_delay: number;
    activity_url: string;
    activity_max_request_per_batch: number;
    print_service_url: string;
    /**
     * remote_print_service_url marked as optional since deprecation, ahead of removal in next major release
     * @deprecated
     */
    remote_print_service_url?: string;
    pagination_page_size: number;
    prd_url: string;
    cache_time_out: number;
    work_allocation_api_url: string;
    user_info_api_url: string;
    wa_service_config?: any;
    access_management_basic_view_mock?: {
        active?: boolean;
        basicFields?: {
            caseNameHmctsInternal?: string;
            caseManagementLocation?: {
                baseLocation?: number;
            };
        };
        accessProcess?: string;
    };
    access_management_request_review_mock?: {
        active?: boolean;
        details?: {
            caseName: string;
            caseReference: string;
            dateSubmitted: string;
            requestFrom: string;
            reasonForCaseAccess: string;
        };
        accessProcess?: string;
    };
    location_ref_api_url?: string;
    cam_role_assignments_api_url?: string;
    refunds_url: string;
    notification_url: string;
    payment_return_url: string;
    categories_and_documents_url: string;
    document_data_url: string;
    case_flags_refdata_api_url: string;
    rd_common_data_api_url: string;
    case_data_store_api_url: string;
    icp_enabled: boolean;
    icp_jurisdictions: string[];
    events_to_hide: string[];
    enable_service_specific_multi_followups: string[];
}

declare class HttpError {
    constructor();
    private static readonly DEFAULT_ERROR;
    private static readonly DEFAULT_MESSAGE;
    private static readonly DEFAULT_STATUS;
    private static readonly MESSAGE_ERROR_429;
    timestamp: string;
    status: number;
    error: string;
    exception: string;
    message: string;
    path: string;
    details?: any;
    callbackErrors?: any;
    callbackWarnings?: any;
    static from(response: HttpErrorResponse): HttpError;
}

/**
 * `Oauth2Service` and `AuthService` cannot be merged as it creates a cyclic dependency on `AuthService` through `HttpErrorService`.
 */
declare class AuthService {
    private readonly appConfig;
    private readonly document;
    private static readonly PATH_OAUTH2_REDIRECT;
    constructor(appConfig: AbstractAppConfig, document: any);
    signIn(): void;
    redirectUri(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthService>;
}

declare class LoadingService {
    private readonly registered;
    private readonly loading;
    private readonly sharedSpinners;
    get isLoading(): Observable<boolean>;
    register(): string;
    unregister(token: string): void;
    addSharedSpinner(spinnerId: string): void;
    hasSharedSpinner(): boolean;
    unregisterSharedSpinner(): void;
    private generateToken;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoadingService>;
}

declare class LoadingModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LoadingModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LoadingModule>;
}

declare class HttpErrorService {
    private readonly authService;
    private readonly loadingService;
    private static readonly logger;
    constructor(authService: AuthService, loadingService: LoadingService);
    private static readonly CONTENT_TYPE;
    private static readonly JSON;
    private error;
    static convertToHttpError(error: HttpErrorResponse | any): HttpError;
    setError(error: HttpError): void;
    removeError(): HttpError;
    handle(error: HttpErrorResponse | any, redirectIfNotAuthorised?: boolean): Observable<never>;
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpErrorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HttpErrorService>;
}

declare class HttpService {
    private readonly httpclient;
    private readonly httpErrorService;
    private static readonly HEADER_ACCEPT;
    private static readonly HEADER_CONTENT_TYPE;
    constructor(httpclient: HttpClient, httpErrorService: HttpErrorService);
    /**
     *
     * @param url Url resolved using UrlResolverService
     * @param options OptionsType
     * @returns Observable<any> return value
     * @see UrlResolverService
     */
    get(url: string, options?: OptionsType, redirectIfNotAuthorised?: boolean, errorHandler?: (error: HttpErrorResponse) => HttpError): Observable<any>;
    /**
     *
     * @param url Url resolved using UrlResolverService
     * @param body Body for post
     * @param options OptionsType
     * @returns Observable<any> return value
     * @see UrlResolverService
     */
    post(url: string, body: any, options?: OptionsType, redirectIfNotAuthorised?: boolean): Observable<any>;
    /**
     *
     * @param url Url resolved using UrlResolverService
     * @param body Body for post
     * @param options OptionsType
     * @returns Observable<any> return value
     * @see UrlResolverService
     */
    put(url: string, body: any, options?: OptionsType): Observable<any>;
    /**
     *
     * @param url Url resolved using UrlResolverService
     * @param options OptionsType
     * @returns Observable<any> return value
     * @see UrlResolverService
     */
    delete(url: string, options?: OptionsType): Observable<any>;
    setDefaultValue(options?: OptionsType): OptionsType;
    static ɵfac: i0.ɵɵFactoryDeclaration<HttpService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HttpService>;
}
interface OptionsType {
    headers?: HttpHeaders;
    observe: 'body';
    params?: HttpParams | {
        [param: string]: string | string[];
    };
    reportProgress?: boolean;
    responseType?: 'json';
    withCredentials?: boolean;
}

declare class SessionStorageService {
    /**
     * Get an item from the session storage.
     */
    getItem(key: string): string | null;
    /**
     * Set an item in the session storage.
     */
    setItem(key: string, value: string): void;
    /**
     * Remove an item from the session storage.
     */
    removeItem(key: string): void;
    /**
     * Clear all the items held in session storage.
     */
    clear(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SessionStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SessionStorageService>;
}

declare const SessionErrorRoute: InjectionToken<string>;
type SessionJsonErrorLogger = (error: unknown) => void;
declare const SessionJsonErrorLogger: InjectionToken<SessionJsonErrorLogger>;
declare class SessionStorageGuard implements CanActivate {
    private readonly sessionStorageService;
    private readonly router;
    private readonly errorRoute?;
    private readonly errorLogger?;
    private readonly logger;
    constructor(sessionStorageService: SessionStorageService, router: Router, errorRoute?: string, errorLogger?: SessionJsonErrorLogger);
    canActivate(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SessionStorageGuard, [null, null, { optional: true; }, { optional: true; }]>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SessionStorageGuard>;
}

declare class ActivityService {
    private readonly http;
    private readonly appConfig;
    private readonly sessionStorageService;
    static get ACTIVITY_VIEW(): string;
    static get ACTIVITY_EDIT(): string;
    private readonly logger;
    constructor(http: HttpService, appConfig: AbstractAppConfig, sessionStorageService: SessionStorageService);
    get isEnabled(): boolean;
    static readonly DUMMY_CASE_REFERENCE = "0";
    private userAuthorised;
    private static handleHttpError;
    getOptions(): OptionsType;
    getActivities(...caseId: string[]): Observable<Activity[]>;
    postActivity(caseId: string, activity: string): Observable<Activity[]>;
    verifyUserIsAuthorized(): void;
    private activityUrl;
    private logUserMayNotBeAuthenticated;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActivityService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ActivityService>;
}

declare class ActivityPollingService {
    private readonly activityService;
    private readonly ngZone;
    private readonly config;
    private readonly logger;
    private readonly pendingRequests;
    private currentTimeoutHandle;
    private pollActivitiesSubscription;
    private readonly pollConfig;
    private readonly batchCollectionDelayMs;
    private readonly maxRequestsPerBatch;
    constructor(activityService: ActivityService, ngZone: NgZone, config: AbstractAppConfig);
    get isEnabled(): boolean;
    subscribeToActivity(caseId: string, done: (activity: Activity) => void): Subject<Activity>;
    stopPolling(): void;
    flushRequests(): void;
    pollActivities(...caseIds: string[]): Observable<Activity[]>;
    postViewActivity(caseId: string): Observable<Activity[]>;
    postEditActivity(caseId: string): Observable<Activity[]>;
    protected performBatchRequest(requests: Map<string, Subject<Activity>>): void;
    private postActivity;
    private addPendingRequest;
    private removePendingRequest;
    private polling;
    private getExponentialRetryDelay;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActivityPollingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ActivityPollingService>;
}

declare class ActivityComponent implements OnInit, OnDestroy {
    private readonly activityPollingService;
    activity: Activity;
    dspMode: typeof DisplayMode;
    viewersText: string;
    editorsText: string;
    subscription: Subject<Activity>;
    caseId: string;
    displayMode: DisplayMode;
    private readonly VIEWERS_PREFIX;
    private readonly VIEWERS_SUFFIX;
    private readonly EDITORS_PREFIX;
    private readonly EDITORS_SUFFIX;
    constructor(activityPollingService: ActivityPollingService);
    ngOnInit(): void;
    onActivityChange(newActivity: Activity): void;
    isActivityEnabled(): boolean;
    isActiveCase(): number;
    viewersPresent(): boolean;
    editorsPresent(): boolean;
    ngOnDestroy(): void;
    generateDescription(prefix: string, suffix: string, namesArray: ActivityInfo[], unknownCount: any): string;
    private replaceLastCommaWithAnd;
    static ɵfac: i0.ɵɵFactoryDeclaration<ActivityComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ActivityComponent, "ccd-activity", never, { "caseId": { "alias": "caseId"; "required": false; }; "displayMode": { "alias": "displayMode"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ActivityModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ActivityModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ActivityModule, [typeof ActivityComponent, typeof ActivityBannerComponent, typeof ActivityIconComponent], [typeof i2.CommonModule, typeof i3.RouterModule, typeof i7.RpxTranslationModule], [typeof ActivityComponent, typeof ActivityBannerComponent, typeof ActivityIconComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ActivityModule>;
}

declare class CaseEventData {
    event: {
        id: string;
        summary: string;
        description: string;
    };
    data?: object;
    event_data?: object;
    event_token: string;
    ignore_warning: boolean;
    draft_id?: string;
    case_reference?: string;
}

interface Orderable {
    order?: number;
}

declare class ComplexFieldOverride {
    complex_field_element_id: string;
    display_context: string;
    label?: string;
    hint_text?: string;
    show_condition?: string;
}

declare class WizardPageField implements Orderable {
    case_field_id: string;
    order?: number;
    page_column_no?: number;
    complex_field_overrides?: ComplexFieldOverride[];
}

declare class AccessControlList {
    role: string;
    create: boolean;
    read: boolean;
    update: boolean;
    delete: boolean;
}

type FieldTypeEnum = 'Text' | 'TextArea' | 'Postcode' | 'Number' | 'YesOrNo' | 'Date' | 'DateTime' | 'Email' | 'PhoneUK' | 'MoneyGBP' | 'FixedList' | 'DynamicList' | 'FixedRadioList' | 'DynamicRadioList' | 'DynamicMultiSelectList' | 'Complex' | 'Collection' | 'MultiSelectList' | 'Document' | 'Label' | 'AddressGlobal' | 'AddressGlobalUK' | 'AddressUK' | 'CasePaymentHistoryViewer' | 'CaseHistoryViewer' | 'Organisation' | 'WaysToPay' | 'ComponentLauncher' | 'Flags' | 'FlagDetail' | 'FlagLauncher' | 'CaseFlag' | 'JudicialUser';

declare class FixedListItem implements Orderable {
    code: string;
    label: string;
    order?: number;
}

declare class FieldType {
    id: string;
    type: FieldTypeEnum;
    min?: number | Date;
    max?: number | Date;
    regular_expression?: string;
    fixed_list_items?: FixedListItem[];
    complex_fields?: CaseField[];
    collection_field_type?: FieldType;
}

declare class CaseField implements Orderable {
    private static readonly logger;
    id: string;
    hidden: boolean;
    hiddenCannotChange: boolean;
    label: string;
    originalLabel?: string;
    noCacheLabel?: string;
    order?: number;
    parent?: CaseField;
    field_type: FieldType;
    hint_text?: string;
    security_label?: string;
    display_context: string;
    display_context_parameter?: string;
    month_format?: string;
    show_condition?: string;
    show_summary_change_option?: boolean;
    show_summary_content_option?: number;
    acls?: AccessControlList[];
    metadata?: boolean;
    formatted_value?: any;
    retain_hidden_value: boolean;
    wizardProps?: WizardPageField;
    _value: any;
    _list_items: any;
    private isTranslatedFlag;
    get value(): any;
    set value(value: any);
    get list_items(): any;
    set list_items(items: any);
    get dateTimeEntryFormat(): string;
    get dateTimeDisplayFormat(): string;
    isComplexDisplay(): boolean;
    isComplexEntry(): boolean;
    isReadonly(): boolean;
    isOptional(): boolean;
    isMandatory(): boolean;
    isCollection(): boolean;
    isComplex(): boolean;
    isDynamic(): boolean;
    isCaseLink(): boolean;
    extractBracketValue(fmt: string, paramName: string, leftBracket?: string, rightBracket?: string): string;
    getHierachicalId(curr?: string): string;
    set isTranslated(val: boolean);
    get isTranslated(): boolean;
}

declare class ShowCondition {
    condition: string;
    static readonly CONDITION_NOT_EQUALS = "!=";
    static readonly CONDITION_EQUALS = "=";
    static readonly CONTAINS = "CONTAINS";
    private static instanceCache;
    private static readonly validJoinComparators;
    private static processedList;
    private conditions;
    static addPathPrefixToCondition(showCondition: string, pathPrefix: string): string;
    private static processAddPathPrefixToCondition;
    private static extractConditions;
    static getInstance(condition: string): ShowCondition;
    private static getField;
    private static getConditions;
    /**
     * Determine whether a ShowCondition model is affected by fields that have
     * a display_context of HIDDEN or READONLY, which means they aren't able to
     * be changed by the user's actions.
     *
     * @param showCondition The ShowCondition model to evaluate.
     * @param caseFields Inspected to see appropriate display_contexts.
     */
    static hiddenCannotChange(showCondition: ShowCondition, caseFields: CaseField[]): boolean;
    constructor(condition: string);
    match(fields: object, path?: string): boolean;
    private updatePathName;
    matchByContextFields(contextFields: CaseField[]): boolean;
    /**
     * Determine whether this is affected by fields that have a display_context
     * of HIDDEN or READONLY, which means they aren't able to be changed by the
     * user's actions.
     *
     * @param caseFields Inspected to see appropriate display_contexts.
     */
    hiddenCannotChange(caseFields: CaseField[]): boolean;
}

declare class WizardPage implements Orderable {
    id: string;
    label: string;
    order?: number;
    wizard_page_fields: WizardPageField[];
    case_fields: CaseField[];
    show_condition?: string;
    parsedShowCondition: ShowCondition;
    getCol1Fields(): CaseField[];
    getCol2Fields(): CaseField[];
    isMultiColumn(): boolean;
}

declare class CaseEventTrigger {
    id: string;
    name: string;
    description?: string;
    case_id?: string;
    case_fields: CaseField[];
    event_token: string;
    wizard_pages: WizardPage[];
    show_summary?: boolean;
    show_event_notes?: boolean;
    end_button_label?: string;
    can_save_draft?: boolean;
    hasFields(): boolean;
    hasPages(): boolean;
}

declare class CaseDetails {
    id: string;
    jurisdiction: string;
    case_type_id: string;
    state: string;
    created_date?: string;
    last_modified?: string;
    locked_by_user_id?: string;
    security_level?: string;
    case_data?: object;
}

declare const DRAFT_PREFIX = "DRAFT";
declare const DRAFT_QUERY_PARAM = "draft";
declare class Draft {
    id: string;
    document?: CaseDetails;
    type?: string;
    created?: string;
    updated?: string;
    static stripDraftId(draftId: string): string;
    static isDraft(id: string): boolean;
}

type AlertLevel = 'error' | 'success' | 'message' | 'warning';

interface AlertStatusParams {
    phrase: string;
    replacements?: Record<string, string>;
    preserve?: boolean;
}

declare class Alert {
    level: AlertLevel;
    message: string;
}

declare class AlertService {
    private readonly router;
    private readonly rpxTranslationService;
    preservedError: string;
    preservedWarning: string;
    preservedSuccess: string;
    message: string;
    level: AlertLevel;
    successes: ConnectableObservable<Alert>;
    errors: ConnectableObservable<Alert>;
    warnings: ConnectableObservable<Alert>;
    alerts: ConnectableObservable<Alert>;
    private successObserver;
    private errorObserver;
    private warningObserver;
    private alertObserver;
    private preserveAlerts;
    constructor(router: Router, rpxTranslationService: RpxTranslationService);
    clear(): void;
    error({ phrase, replacements }: Omit<AlertStatusParams, 'preserve'>): void;
    warning({ phrase, replacements }: Omit<AlertStatusParams, 'preserve'>): void;
    success({ preserve, phrase, replacements }: AlertStatusParams): void;
    private getTranslationWithReplacements;
    setPreserveAlerts(preserve: boolean, urlInfo?: string[]): void;
    currentUrlIncludesInfo(preserve: boolean, urlInfo: string[]): boolean;
    isPreserveAlerts(): boolean;
    preserveMessages(message: string): string;
    push(msgObject: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AlertService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AlertService>;
}

declare class AddressModel {
    AddressLine1: string;
    AddressLine2: string;
    AddressLine3: string;
    PostTown: string;
    County: string;
    PostCode: string;
    Country: string;
}

interface CaseEditModel {
    wizard: Wizard;
    currentPageId: string;
    eventTrigger: CaseEventTrigger;
    form: FormGroup;
    eventCanBeCompleted: boolean;
    caseDetails: CaseView;
    caseEventData: CaseEventData;
    submit(caseEventData: CaseEventData, profile?: Profile): Observable$1<object>;
}
interface CaseEditGetNextPage extends Pick<CaseEditModel, 'wizard' | 'currentPageId' | 'eventTrigger' | 'form'> {
}
interface CaseEditSubmitForm extends Pick<CaseEditModel, 'eventTrigger' | 'form' | 'caseDetails' | 'submit'> {
}
interface CaseEditGenerateCaseEventData extends Pick<CaseEditModel, 'eventTrigger' | 'form'> {
}
interface CaseEditCaseSubmit extends Pick<CaseEditModel, 'form' | 'caseEventData' | 'submit'> {
}
interface CaseEditonEventCanBeCompleted extends Pick<CaseEditModel, 'eventCanBeCompleted' | 'eventTrigger' | 'caseDetails' | 'form' | 'submit'> {
}

declare class CaseViewEvent {
    id: number;
    timestamp: string;
    summary: string;
    comment: string;
    event_id: string;
    event_name: string;
    state_id: string;
    state_name: string;
    user_id: number;
    user_last_name: string;
    user_first_name: string;
    significant_item: {
        type: string;
        description: string;
        url: string;
    };
}

declare class CaseViewTrigger implements Orderable {
    id: string;
    name: string;
    description: string;
    order?: number;
}

declare class EventCaseField {
    case_field_id: string;
    showCondition: string;
}

declare class CaseEvent implements Orderable {
    id: string;
    name: string;
    post_state: string;
    pre_states: string[];
    case_fields: EventCaseField[];
    description: string;
    order?: number;
    acls?: AccessControlList[];
}

declare class CaseState implements Orderable {
    id: string;
    name: string;
    description: string;
    order?: number;
}

declare class CaseTypeLite {
    id: string;
    name: string;
    events: CaseEvent[];
    states: CaseState[];
    description: string;
}

declare class Jurisdiction {
    id: string;
    name: string;
    description: string;
    caseTypes: CaseTypeLite[];
    currentCaseType?: CaseTypeLite;
}

declare class CaseType {
    id: string;
    name: string;
    events: CaseEvent[];
    states: CaseState[];
    case_fields: CaseField[];
    description: string;
    jurisdiction: Jurisdiction;
    printEnabled?: boolean;
}

declare class Banner {
    bannerDescription: string;
    bannerUrlText: string;
    bannerUrl: string;
    bannerViewed: boolean;
    bannerEnabled: boolean;
}

declare class CaseTab implements Orderable {
    id: string;
    label: string;
    order?: number;
    fields: CaseField[];
    show_condition?: string;
}

declare class CasePrintDocument {
    name: string;
    type: string;
    url: string;
}

interface RoleRequestPayload {
    roleRequest: RoleRequest;
    requestedRoles: RequestedRole[];
}
interface RequestedRole {
    actorIdType: 'IDAM';
    actorId: string;
    roleType: RoleType;
    roleName: string;
    classification: RoleClassification;
    grantType: RoleGrantTypeCategory;
    roleCategory: RoleCategory;
    readOnly?: boolean;
    beginTime: Date;
    endTime: Date;
    authorisations?: string[];
    attributes: object;
    notes: RequestedRoleNote[];
}
interface RoleRequest {
    assignerId: string;
    process: string;
    replaceExisting: boolean;
    reference: string;
}
interface RequestedRoleNote {
    userId: string;
    time: Date;
    comment: string;
}
type RoleCategory = 'JUDICIAL' | 'LEGAL_OPERATIONS' | 'ADMIN' | 'PROFESSIONAL' | 'CITIZEN' | 'CTSC';
type RoleGrantTypeCategory = 'BASIC' | 'STANDARD' | 'SPECIFIC' | 'CHALLENGED' | 'EXCLUDED';
type RoleClassification = 'PUBLIC' | 'PRIVATE' | 'RESTRICTED';
type RoleType = 'ORGANISATION' | 'CASE';

interface RoleAssignmentResponse {
    roleRequest: RoleRequest;
    requestedRoles: RequestedRole[];
}

interface ChallengedAccessRequest {
    reason: number;
    caseReference: string | null;
    otherReason: string | null;
}

interface SpecificAccessRequest {
    specificReason?: string;
}

interface ReviewSpecificAccessRequest {
    reason: number;
    caseId: string;
}

declare class HRef {
    href: string;
}
declare class DocumentLinks {
    self: HRef;
    binary: HRef;
}
declare class Document {
    _links: DocumentLinks;
    originalDocumentName: string;
    hashToken?: string;
}
declare class Embedded {
    documents: Document[];
}
declare class DocumentData {
    _embedded: Embedded;
    documents: Document[];
}
declare class FormDocument {
    document_url: string;
    document_binary_url: string;
    document_filename: string;
    document_hash?: string;
    upload_timestamp?: string;
}

/**
 * Cloned from rpx-xui-webapp src/app/models/error-message.model.ts
 */
interface ErrorMessage {
    title: string;
    description: string;
    fieldId?: string;
}

interface Journey {
    next(): void;
    previous(): void;
    hasNext(): boolean;
    hasPrevious(): boolean;
    isFinished(): boolean;
    isStart(): boolean;
    onPageChange(): void;
    journeyId: string;
    journeyPageNumber: number;
    journeyStartPageNumber: number;
    journeyEndPageNumber: number;
    journeyPreviousPageNumber: number;
    childJourney: Journey;
    fieldState?: number;
    linkedCasesPage?: number;
    searchLanguageInterpreterHint?: any;
}

interface JourneyInstigator {
    onFinalNext(): void;
    onFinalPrevious(): void;
}

interface OrganisationSuperUser {
    firstName: string;
    lastName: string;
    email: string;
}
interface OrganisationAddress {
    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    townCity: string;
    county: string;
    country: string;
    postCode: string;
    dxAddress: any[];
}
interface Organisation {
    organisationIdentifier: string;
    name: string;
    status: string;
    sraId: string;
    sraRegulated: boolean;
    companyNumber: string;
    companyUrl: string;
    superUser: OrganisationSuperUser;
    paymentAccount: string[];
    contactInformation: OrganisationAddress[];
}
interface OrganisationVm {
    organisationIdentifier: string;
    name: string;
    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    townCity: string;
    county: string;
    country: string;
    postCode: string;
}
declare class OrganisationService {
    private readonly http;
    private readonly appconfig;
    private readonly logger;
    constructor(http: HttpClient, appconfig: AbstractAppConfig);
    private organisations$;
    static mapOrganisation(organisations: Organisation[]): OrganisationVm[];
    getActiveOrganisations(): Observable<OrganisationVm[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganisationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrganisationService>;
}

interface SimpleOrganisationModel {
    organisationIdentifier: string;
    name: string;
    address: string;
}

declare class OrganisationConverter {
    private static toSimpleAddress;
    toSimpleOrganisationModel(organisationModel: OrganisationVm): SimpleOrganisationModel;
    static ɵfac: i0.ɵɵFactoryDeclaration<OrganisationConverter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrganisationConverter>;
}

declare class PaginationMetadata {
    totalResultsCount: number;
    totalPagesCount: number;
}

type Predicate<T> = (value: T) => boolean;

declare class Profile {
    user: {
        idam: {
            id: string;
            email: string;
            forename: string;
            surname: string;
            roles: string[];
        };
    };
    channels: string[];
    jurisdictions: Jurisdiction[];
    default: {
        workbasket: {
            jurisdiction_id: string;
            case_type_id: string;
            state_id: string;
        };
    };
    isSolicitor(): boolean;
    isCourtAdmin(): boolean;
}

declare class Field {
    id: string;
    field_type: FieldType;
    elementPath?: string;
    value?: string;
    label?: string;
    metadata?: boolean;
    constructor(id: string, field_type: FieldType, elementPath?: string, value?: string, label?: string, metadata?: boolean);
}

declare class SearchResultViewColumn {
    case_field_id: string;
    case_field_type: FieldType;
    display_context?: string;
    display_context_parameter?: string;
    label: string;
    order: number;
}

declare class SearchResultViewItem {
    case_id: string;
    case_fields: object;
    hydrated_case_fields?: CaseField[];
    columns?: object;
    supplementary_data?: any;
    display_context_parameter?: any;
}

declare class SearchResultView {
    columns: SearchResultViewColumn[];
    results: SearchResultViewItem[];
    result_error?: string;
    hasDrafts(): boolean;
}

interface SearchResultViewItemComparator {
    compare(a: SearchResultViewItem, b: SearchResultViewItem): number;
}

declare enum SortOrder$1 {
    ASCENDING = 0,
    DESCENDING = 1,
    UNSORTED = 2
}

declare class SortParameters {
    comparator: SearchResultViewItemComparator;
    sortOrder: SortOrder$1;
    constructor(comparator: SearchResultViewItemComparator, sortOrder: SortOrder$1);
}

interface TaskSearchParameter {
    ccdId?: string;
    eventId?: string;
    jurisdiction?: string;
    location?: string[];
    postEventState?: string;
    preEventState?: string;
    state?: string[];
    user?: string[];
    caseTypeId?: string;
}
interface TaskSearchParameters {
    parameters: TaskSearchParameter[];
}

interface ServiceConfig {
    serviceName: string;
    caseTypes: string[];
    releaseVersion: string;
}
interface WAFeatureConfig {
    configurations?: ServiceConfig[];
}

declare class WorkbasketInputModel implements Orderable {
    label: string;
    order: number;
    field: Field;
    metadata?: boolean;
    display_context_parameter?: string;
}
declare class WorkbasketInput {
    workbasketInputs: WorkbasketInputModel[];
}

interface FlagPath {
    id?: string;
    value: string;
}
interface FlagDetail {
    id?: string;
    name: string;
    name_cy?: string;
    subTypeValue?: string;
    subTypeValue_cy?: string;
    subTypeKey?: string;
    otherDescription?: string;
    otherDescription_cy?: string;
    flagComment?: string;
    flagComment_cy?: string;
    flagUpdateComment?: string;
    dateTimeModified?: Date | string;
    dateTimeCreated: Date | string;
    path: FlagPath[];
    hearingRelevant: boolean | string;
    flagCode: string;
    status: string;
    availableExternally?: boolean | string;
}
interface Flags {
    flagsCaseFieldId?: string;
    partyName?: string;
    roleOnCase?: string;
    details?: FlagDetail[];
    visibility?: string;
    groupId?: string;
}
interface FlagDetailDisplay {
    partyName: string;
    flagDetail: FlagDetail;
    flagsCaseFieldId: string;
    visibility: string;
}
/**
 * Wrapper interface for Flags that adds the path to the corresponding FormGroup, and the CaseField
 */
interface FlagsWithFormGroupPath {
    flags: Flags;
    pathToFlagsFormGroup: string;
    caseField: CaseField;
}
/**
 * Wrapper interface for FlagDetailDisplay that adds the path to the corresponding FormGroup, the CaseField, and the
 * original flag status
 */
interface FlagDetailDisplayWithFormGroupPath {
    flagDetailDisplay: FlagDetailDisplay;
    pathToFlagsFormGroup: string;
    caseField: CaseField;
    roleOnCase?: string;
    label?: string;
    originalStatus?: string;
}

interface CaseFlagState {
    currentCaseFlagFieldState: number;
    isParentFlagType?: boolean;
    errorMessages: ErrorMessage[];
    selectedFlag?: FlagDetailDisplayWithFormGroupPath;
}

interface Language {
    key: string;
    value: string;
    value_cy: string;
}

declare enum AddCommentsErrorMessage {
    FLAG_COMMENTS_NOT_ENTERED = "Please enter comments for this flag",
    FLAG_COMMENTS_NOT_ENTERED_EXTERNAL = "Please enter comments for this support request",
    FLAG_COMMENTS_CHAR_LIMIT_EXCEEDED = "Comments for this flag must be 200 characters or fewer"
}

declare enum AddCommentsStep {
    HINT_TEXT = "Explain why you are creating this flag. Do not include any sensitive information such as personal details.",
    HINT_TEXT_EXTERNAL = "Explain why you are creating this support request. Do not include any sensitive information such as personal details.",
    CHARACTER_LIMIT_INFO = "You can enter up to 200 characters",
    WARNING_TEXT = "The details entered here MAY be visible to the party in the future."
}

declare enum CaseFlagCheckYourAnswersPageStep {
    CASE_LEVEL_LOCATION = "Case level",
    ADD_FLAG_HEADER_TEXT = "Add flag to",
    ADD_FLAG_HEADER_TEXT_EXTERNAL = "Add support to",
    UPDATE_FLAG_HEADER_TEXT = "Update flag for",
    UPDATE_FLAG_HEADER_TEXT_EXTERNAL = "Update support for",
    FLAG_TYPE_HEADER_TEXT = "Flag type",
    FLAG_TYPE_HEADER_TEXT_EXTERNAL = "Support type",
    NONE = ""
}

/**
 * Create and update contexts for external users are, by definition, part of Case Flags 2.1 - thus there is no enum
 * value for these.
 */
declare enum CaseFlagDisplayContextParameter {
    CREATE = "#ARGUMENT(CREATE)",
    CREATE_EXTERNAL = "#ARGUMENT(CREATE,EXTERNAL)",
    CREATE_2_POINT_1 = "#ARGUMENT(CREATE,VERSION2.1)",
    READ_EXTERNAL = "#ARGUMENT(READ,EXTERNAL)",
    UPDATE = "#ARGUMENT(UPDATE)",
    UPDATE_EXTERNAL = "#ARGUMENT(UPDATE,EXTERNAL)",
    UPDATE_2_POINT_1 = "#ARGUMENT(UPDATE,VERSION2.1)"
}

declare enum CaseFlagFormFields {
    FLAG_TYPE = "flagType",
    COMMENTS = "flagComment",
    COMMENTS_WELSH = "flagComment_cy",
    OTHER_FLAG_DESCRIPTION = "otherDescription",
    OTHER_FLAG_DESCRIPTION_WELSH = "otherDescription_cy",
    STATUS = "status",
    STATUS_CHANGE_REASON = "flagStatusReasonChange",
    IS_WELSH_TRANSLATION_NEEDED = "flagIsWelshTranslationNeeded",
    IS_VISIBLE_INTERNALLY_ONLY = "flagIsVisibleInternallyOnly"
}

declare enum CaseFlagStatus {
    REQUESTED = "Requested",
    ACTIVE = "Active",
    INACTIVE = "Inactive",
    NOT_APPROVED = "Not approved"
}

declare enum CaseFlagSummaryListDisplayMode {
    CREATE = 0,
    MANAGE = 1
}

declare enum CaseFlagWizardStepTitle {
    SELECT_FLAG_LOCATION = "Where should this flag be added?",
    SELECT_FLAG_LOCATION_EXTERNAL = "Who is the support for?",
    SELECT_CASE_FLAG = "Select flag type",
    SELECT_CASE_FLAG_EXTERNAL = "Select support type",
    OTHER_FLAG_TYPE_DESCRIPTION = "Enter a flag type",
    OTHER_FLAG_TYPE_DESCRIPTION_EXTERNAL = "Enter a support type",
    ADD_FLAG_COMMENTS = "Add comments for this flag",
    ADD_FLAG_COMMENTS_EXTERNAL_MODE = "Tell us more about the request",
    CONFIRM_FLAG_STATUS = "Confirm the status of the flag",
    FLAG_STATUS = "Flag status",
    MANAGE_CASE_FLAGS = "Manage case flags",
    MANAGE_SUPPORT = "Which support is no longer needed?",
    UPDATE_FLAG_TITLE = "Update flag",
    UPDATE_FLAG_TITLE_EXTERNAL = "Tell us why the support is no longer needed",
    UPDATE_FLAG_ADD_TRANSLATION = "Add translations to flag",
    NONE = ""
}

declare enum ConfirmStatusErrorMessage {
    STATUS_REASON_NOT_ENTERED = "Comments and/or the name of the person approving the decision should be entered",
    STATUS_REASON_CHAR_LIMIT_EXCEEDED = "Comments must be 200 characters or fewer"
}

declare enum ConfirmStatusStep {
    HINT_TEXT = "Describe reason for status; if choosing 'Not approved' provide name of person approving decision.",
    CHARACTER_LIMIT_INFO = "You can enter up to 200 characters"
}

declare enum SearchLanguageInterpreterErrorMessage {
    LANGUAGE_NOT_ENTERED = "Enter the language that will need to be interpreted",
    LANGUAGE_CHAR_LIMIT_EXCEEDED = "You can enter up to 80 characters for the required language",
    LANGUAGE_ENTERED_IN_BOTH_FIELDS = "The language can only be entered in one of the fields"
}

declare enum SearchLanguageInterpreterStep {
    HINT_TEXT = "Enter the language that will need to be interpreted. If this language is not listed, you can enter it manually.",
    SIGN_HINT_TEXT = "Enter the sign language that will need to be interpreted. If this language is not listed, you can enter it manually.",
    CHECKBOX_LABEL = "Enter the language manually",
    INPUT_LABEL = "Enter the language"
}

declare enum SelectFlagErrorMessage {
    MANAGE_CASE_FLAGS_FLAG_NOT_SELECTED = "Please make a selection",
    MANAGE_SUPPORT_FLAG_NOT_SELECTED = "Select which support is no longer needed",
    NO_FLAGS = "This case has no flags"
}

declare enum SelectFlagLocationErrorMessage {
    FLAG_LOCATION_NOT_SELECTED = "Please make a selection",
    FLAGS_NOT_CONFIGURED = "Flags have not been configured for this case type"
}

declare enum SelectFlagTypeErrorMessage {
    FLAG_TYPE_NOT_SELECTED = "Please select a flag type",
    FLAG_TYPE_NOT_SELECTED_EXTERNAL = "Please select a support type",
    FLAG_TYPE_OPTION_NOT_SELECTED = "Select an option",
    FLAG_TYPE_NOT_ENTERED = "Please enter a flag type",
    FLAG_TYPE_NOT_ENTERED_EXTERNAL = "Please enter a support type",
    FLAG_TYPE_LIMIT_EXCEEDED = "You can enter up to 80 characters only"
}

declare enum UpdateFlagAddTranslationErrorMessage {
    DESCRIPTION_CHAR_LIMIT_EXCEEDED = "Original description or translation must be 200 characters or fewer",
    COMMENTS_CHAR_LIMIT_EXCEEDED = "Original comments or translation must be 200 characters or fewer"
}

declare enum UpdateFlagAddTranslationStep {
    HINT_TEXT = "Write translation for flag description or comments in the boxes provided.",
    CHARACTER_LIMIT_INFO = "You can enter up to 200 characters"
}

declare enum UpdateFlagErrorMessage {
    FLAG_COMMENTS_NOT_ENTERED = "Please enter comments for this flag",
    FLAG_COMMENTS_CHAR_LIMIT_EXCEEDED = "Comments for this flag must be 200 characters or fewer",
    STATUS_REASON_NOT_ENTERED = "Comments and/or the name of the person approving the decision should be entered",
    STATUS_REASON_NOT_ENTERED_EXTERNAL = "You must explain why the support is no longer needed",
    STATUS_REASON_CHAR_LIMIT_EXCEEDED = "Comments must be 200 characters or fewer",
    NONE = ""
}

declare enum UpdateFlagStep {
    COMMENT_HINT_TEXT_INTERNAL = "Explain why you are updating this flag. Do not include any sensitive information such as personal details.",
    COMMENT_HINT_TEXT_INTERNAL_2_POINT_1 = "Update the comments describing the user's support needs or flag description. Do not include any sensitive information such as personal details.",
    COMMENT_HINT_TEXT_EXTERNAL = "Do not include any sensitive information such as personal details.",
    COMMENT_FIELD_LABEL_EXTERNAL = "Please provide your comments below",
    CHARACTER_LIMIT_INFO = "You can enter up to 200 characters",
    STATUS_HINT_TEXT = "Describe reason for status change.",
    WARNING_TEXT = "The details entered here MAY be visible to the party in the future."
}

declare enum CaseFlagFieldState {
    FLAG_LOCATION = 0,
    FLAG_TYPE = 1,
    FLAG_LANGUAGE_INTERPRETER = 2,
    FLAG_COMMENTS = 3,
    FLAG_STATUS = 4,
    FLAG_MANAGE_CASE_FLAGS = 5,
    FLAG_UPDATE = 6,
    FLAG_UPDATE_WELSH_TRANSLATION = 7
}
declare enum CaseFlagErrorMessage {
    NO_EXTERNAL_FLAGS_COLLECTION = "External collection for storing this case flag has not been configured for this case type",
    NO_INTERNAL_FLAGS_COLLECTION = "Internal collection for storing this case flag has not been configured for this case type"
}

type FormContainer = FormGroup | FormArray;
declare abstract class AbstractFormFieldComponent {
    caseField: CaseField;
    formGroup: FormGroup;
    parent?: FormContainer;
    idPrefix: string;
    id(): string;
    isTranslatable(field: CaseField): boolean;
    protected registerControl<T extends AbstractControl>(control: T, replace?: boolean): AbstractControl;
    protected addValidators(caseField: CaseField, control: AbstractControl): void;
    private addControlToParent;
    private addControlToFormArray;
    private addControlToFormGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractFormFieldComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AbstractFormFieldComponent, never, never, { "caseField": { "alias": "caseField"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "parent": { "alias": "parent"; "required": false; }; "idPrefix": { "alias": "idPrefix"; "required": false; }; }, {}, never, never, true, never>;
}

declare enum PaletteContext {
    DEFAULT = "DEFAULT",
    CHECK_YOUR_ANSWER = "CHECK_YOUR_ANSWER",
    TABLE_VIEW = "TABLE_VIEW"
}

declare abstract class AbstractFieldReadComponent extends AbstractFormFieldComponent implements OnInit {
    caseReference: string;
    topLevelFormGroup: FormGroup | AbstractControl;
    /**
     * Optional. Enable context-aware rendering of fields.
     */
    context: PaletteContext;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractFieldReadComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AbstractFieldReadComponent, never, never, { "caseReference": { "alias": "caseReference"; "required": false; }; "topLevelFormGroup": { "alias": "topLevelFormGroup"; "required": false; }; "context": { "alias": "context"; "required": false; }; }, {}, never, never, true, never>;
}

declare abstract class AbstractFieldWriteComponent extends AbstractFormFieldComponent implements OnChanges {
    isExpanded: boolean;
    isInSearchBlock: boolean;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    createElementId(elementId: string): string;
    protected addValidators(caseField: CaseField, control: AbstractControl): void;
    private fixCaseField;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractFieldWriteComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AbstractFieldWriteComponent, never, never, { "isExpanded": { "alias": "isExpanded"; "required": false; }; "isInSearchBlock": { "alias": "isInSearchBlock"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AddressesService {
    private readonly http;
    private readonly appConfig;
    private mandatoryError;
    constructor(http: HttpService, appConfig: AbstractAppConfig);
    getAddressesForPostcode(postcode: string): Observable<AddressModel[]>;
    getMandatoryError(): Observable<boolean>;
    setMandatoryError(value: boolean): void;
    private format;
    private formatAddressLines;
    private shiftAddressLinesUp;
    private toCapitalCase;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AddressesService>;
}

declare class CaseFieldService {
    isOptional(field: CaseField): boolean;
    isReadOnly(field: CaseField): boolean;
    isMandatory(field: CaseField): boolean;
    isLabel(field: CaseField): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFieldService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CaseFieldService>;
}

declare class FormatTranslatorService {
    translate(javaFormat: string): string;
    showOnlyDates(dateFormat: string): string;
    removeTime(dateFormat: string): string;
    hasDate(value: string): boolean;
    is24Hour(value: string): boolean;
    hasNoDay(value: string): boolean;
    hasNoDayAndMonth(value: string): boolean;
    hasHours(value: string): boolean;
    hasMinutes(value: string): boolean;
    hasSeconds(value: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormatTranslatorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormatTranslatorService>;
}

declare class CaseFileViewDocument {
    document_url: string;
    document_filename: string;
    document_binary_url: string;
    attribute_path: string;
    upload_timestamp: Date | string;
    content_type: string;
}

declare class CaseFileViewCategory {
    category_id: string;
    category_name: string;
    category_order: number;
    documents: CaseFileViewDocument[];
    sub_categories: CaseFileViewCategory[];
}

/**
 * DTO to provide typing of the response from the CCD Data Store API for Categories and Documents data.
 * @see {@link https://tools.hmcts.net/confluence/x/0KSDX#CaseFileViewDocumentDataendpointLLD-SuccessResponsePayload} for full details
 */
declare class CategoriesAndDocuments {
    case_version: number;
    categories: CaseFileViewCategory[];
    uncategorised_documents: CaseFileViewDocument[];
}

declare enum DocumentTreeNodeType {
    FOLDER = "folder",
    DOCUMENT = "document"
}

declare class DocumentTreeNode {
    name: string;
    type: DocumentTreeNodeType;
    children?: DocumentTreeNode[];
    document_filename?: string;
    document_binary_url?: string;
    content_type?: string;
    attribute_path?: string;
    upload_timestamp?: string;
    category_order?: number;
    get childDocumentCount(): number;
    sortChildrenAscending(column: number, sortOrder: any): void;
    sortChildrenDescending(column: number, sortOrder: any): void;
    get flattenedAll(): DocumentTreeNode[];
    private getNodeToSort;
}

declare class CaseFileViewService {
    private readonly http;
    private readonly appConfig;
    constructor(http: HttpService, appConfig: AbstractAppConfig);
    /**
     * Retrieves the categories and documents for a case.
     *
     * @param caseRef 16-digit Case Reference number of the case
     * @returns An `Observable` of the `CategoriesAndDocuments` for the case
     */
    getCategoriesAndDocuments(caseRef: string): Observable<CategoriesAndDocuments>;
    updateDocumentCategory(caseRef: string, caseVersion: number, attributePath: string, categoryId: string): Observable<CategoriesAndDocuments>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFileViewService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CaseFileViewService>;
}

/**
 * DTO to provide typing of the response from the Reference Data Common API for Case Flags data.
 *
 * @see {@link https://tools.hmcts.net/confluence/pages/viewpage.action?pageId=1597741121#CaseFlagsHLDVersion2.0-Output}
 * for full details
 */
declare class FlagType {
    name: string;
    name_cy: string;
    hearingRelevant: boolean;
    flagComment: boolean;
    defaultStatus: string;
    externallyAvailable: boolean;
    flagCode: string;
    isParent: boolean;
    Path: string[];
    childFlags: FlagType[];
    listOfValuesLength: number;
    listOfValues: {
        key: string;
        value: string;
        value_cy: string;
    }[];
    static searchPathByFlagTypeObject(singleFlag: FlagType, flags: FlagType[], path?: FlagType[]): [FlagType | false, FlagType[]];
}

/**
 * DTO to provide typing of the response from the Reference Data Location API for HMCTS service details.
 */
declare class HmctsServiceDetail {
    business_area: string;
    ccd_case_types: string[];
    ccd_service_name: string;
    jurisdiction: string;
    last_update?: string;
    org_unit: string;
    service_code?: string;
    service_description?: string;
    service_id: number;
    service_short_description?: string;
    sub_business_area: string;
}

declare enum RefdataCaseFlagType {
    PARTY = "PARTY",
    CASE = "CASE"
}

declare class CaseFlagRefdataService {
    private readonly http;
    private readonly appConfig;
    constructor(http: HttpService, appConfig: AbstractAppConfig);
    /**
     * Retrieves the Case Flag types for an HMCTS service.
     *
     * @param serviceId The HMCTS Service Code for a jurisdiction or service. **Note:** This is _not_ the service name
     * @param flagType `PARTY` for party-level flags; `CASE` for case-level
     * @param welshRequired `true` if Welsh language versions of flags are required; `false` otherwise
     * @param externalFlagsOnly Only flags with the attribute `availableExternally` set to `true` will be returned
     * @returns An `Observable` of an array of flag types
     */
    getCaseFlagsRefdata(serviceId: string, flagType?: RefdataCaseFlagType, welshRequired?: boolean, externalFlagsOnly?: boolean): Observable<FlagType[]>;
    /**
     * Retrieves the HMCTS service details for a jurisdiction or service, including service codes. More than one
     * service code may be present. For example, the Divorce jurisdiction/service has corresponding service codes of
     * "ABA1" and "ABA2".
     *
     * @param serviceNames The service name(s) to look up, comma-separated if more than one
     * @returns An `Observable` of an array of service details
     */
    getHmctsServiceDetailsByServiceName(serviceNames?: string): Observable<HmctsServiceDetail[]>;
    /**
     * Retrieves the HMCTS service details for a case type, including service code. For example, the
     * "FinancialRemedyContested" case type is associated with the Divorce jurisdiction/service and service code "ABA2".
     *
     * Note that a case type might not be associated with any service codes of a jurisdiction or service.
     *
     * @param caseTypeId The case type ID to look up
     * @returns An `Observable` of an array of service details
     */
    getHmctsServiceDetailsByCaseType(caseTypeId?: string): Observable<HmctsServiceDetail[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFlagRefdataService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CaseFlagRefdataService>;
}

declare class ReadCookieService {
    private readonly document?;
    constructor(doc?: any);
    getCookie(key: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadCookieService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ReadCookieService>;
}

declare class DocumentManagementService {
    private readonly http;
    private readonly appConfig;
    private readonly sessionStorageService;
    private static readonly PDF;
    private static readonly IMAGE;
    private static readonly WORD;
    private static readonly EXCEL;
    private static readonly POWERPOINT;
    private static readonly TXT;
    private static readonly RTF;
    private static readonly HTML_MIME_ALLOWLIST;
    private static readonly HTML_EXTENSION_ALLOWLIST;
    private static readonly RESPONSE_DELAY;
    private static readonly imagesList;
    private static readonly wordList;
    private static readonly excelList;
    private static readonly powerpointList;
    private caseTypeId;
    private caseId?;
    constructor(http: HttpService, appConfig: AbstractAppConfig, sessionStorageService: SessionStorageService);
    uploadFile(formData: FormData): Observable<DocumentData>;
    setCaseInfo(): void;
    getMediaViewerInfo(documentFieldValue: any): string;
    getDocumentBinaryUrl(documentFieldValue: any): string;
    isHtmlDocument(documentFieldValue: any): boolean;
    getContentType(documentFieldValue: any): string;
    isImage(imageType: string): boolean;
    isWord(wordType: string): boolean;
    isExcel(excelType: string): boolean;
    isPowerpoint(powerpointType: string): boolean;
    parseCaseInfo(caseInfo: string | null): {
        caseType?: string;
        caseId?: string;
        jurisdiction?: string;
    } | null;
    private getCurrentPathname;
    private resolveCaseTypeId;
    private transformDocumentUrl;
    private normaliseMimeType;
    private getFileExtension;
    private getDocStoreUrl;
    isDocumentSecureModeEnabled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentManagementService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocumentManagementService>;
}

declare class ErrorNotifierService {
    errorSource: Subject<any>;
    error: rxjs.Observable<any>;
    announceError(error: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorNotifierService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ErrorNotifierService>;
}

declare class EventStatusService {
    static readonly CALLBACK_STATUS_INCOMPLETE = "INCOMPLETE_CALLBACK";
    static readonly DELETE_DRAFT_STATUS_INCOMPLETE = "INCOMPLETE_DELETE_DRAFT";
    static readonly CALLBACK_STATUS_COMPLETE = "CALLBACK_COMPLETED";
    static readonly DELETE_DRAFT_STATUS_COMPLETE = "DELETE_DRAFT_COMPLETED";
    static isIncomplete(eventStatus: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventStatusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EventStatusService>;
}

declare class Confirmation {
    private readonly caseId;
    private readonly status;
    private readonly header;
    private readonly body;
    constructor(caseId: string, status: string, header: string, body: string);
    getCaseId(): string;
    getStatus(): string;
    getHeader(): string;
    getBody(): string;
}

declare enum EventCompletionReturnStates {
    InProgress = "in-progress",
    CompleteEvent = "complete-event",
    CancelEvent = "cancel-event"
}

interface Task {
    assignee?: string;
    auto_assigned?: boolean;
    case_category: string;
    case_id: string;
    case_management_category?: string;
    case_name?: string;
    case_type_id?: string;
    created_date: string;
    due_date?: string;
    description?: string;
    execution_type?: string;
    id: string;
    jurisdiction: string;
    location?: string;
    location_name?: string;
    name?: string;
    permissions: {
        values: Permissions[];
    };
    region?: string;
    security_classification?: string;
    task_state?: string;
    task_system?: string;
    task_title?: string;
    type?: string;
    warning_list?: {
        values: string[];
    };
    warnings?: true;
    work_type_id?: string;
}
interface UserTask {
    task_data: Task;
    complete_task: boolean;
}
interface TaskEventCompletionInfo {
    taskId: string;
    eventId: string;
    caseId: string;
    userId: string;
    createdTimestamp: number;
}
interface EventDetails {
    eventId: string;
    caseId: string;
    userId: string;
    assignNeeded?: string;
}
declare enum Permissions {
    Own = "OWN",
    Execute = "EXECUTE",
    Read = "READ",
    Manage = "MANAGE",
    Cancel = "CANCEL"
}

interface TaskResponse {
    task: Task;
}

interface TaskPayload {
    task_required_for_event: boolean;
    tasks: Task[];
}

declare class LinkCaseReason {
    key: string;
    value_en: string;
    value_cy: string;
    hint_text_en: string;
    hint_text_cy: string;
    lov_order: number;
    parent_key: string;
    category_key: string;
    parent_category: string;
    active_flag: string;
    child_nodes: string;
    from: string;
    selected?: boolean;
}
declare class CCDCaseLinkType {
    CaseReference: string;
    CaseType: string;
    CreatedDateTime: string;
    ReasonForLink: LinkReason[];
}
declare class CaseLink {
    caseReference: string;
    reasons: LinkReason[];
    createdDateTime: string;
    caseType: string;
    caseTypeDescription: string;
    caseState: string;
    caseStateDescription: string;
    caseService: string;
    caseName: string;
    unlink?: boolean;
}
declare class LinkReason {
    Reason: string;
    OtherDescription?: string;
}
declare class LinkFromReason {
    reasonCode: string;
    otherDescription?: string;
}
declare class LinkedCasesResponse$1 {
    linkedCases: CaseLinkResponse[];
}
declare class CaseLinkResponse {
    caseNameHmctsInternal: string;
    caseReference: string;
    ccdCaseType: string;
    ccdCaseTypeDescription: string;
    ccdJurisdiction: string;
    state: string;
    stateDescription: string;
    linkDetails: LinkDetails[];
}
declare class LinkDetails {
    createdDateTime: Date;
    reasons: LinkFromReason[];
}
declare class Terms {
    terms: {
        reference: any[];
    };
}
declare class ESQueryType {
    query: Terms;
    size: number;
}

declare class WizardPageFieldToCaseFieldMapper {
    mapAll(wizardPageFields: WizardPageField[], caseFields: CaseField[]): CaseField[];
    private map;
    private processComplexFieldOverride;
    private fixShowConditionPath;
    private preparePathPrefix;
    private getCaseFieldLeaf;
    private hideParentIfAllChildrenHidden;
    private getCaseFieldChildren;
    private allCaseFieldsHidden;
    static ɵfac: i0.ɵɵFactoryDeclaration<WizardPageFieldToCaseFieldMapper, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WizardPageFieldToCaseFieldMapper>;
}

declare class CasesService {
    private http;
    private appConfig;
    private orderService;
    private errorService;
    private wizardPageFieldToCaseFieldMapper;
    private loadingService;
    private readonly sessionStorageService;
    private readonly retryUtil;
    private readonly logger;
    static readonly V2_MEDIATYPE_CASE_VIEW = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-case-view.v2+json";
    static readonly V2_MEDIATYPE_START_CASE_TRIGGER = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-start-case-trigger.v2+json;charset=UTF-8";
    static readonly V2_MEDIATYPE_START_EVENT_TRIGGER = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-start-event-trigger.v2+json;charset=UTF-8";
    static readonly V2_MEDIATYPE_START_DRAFT_TRIGGER = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-start-draft-trigger.v2+json;charset=UTF-8";
    static readonly V2_MEDIATYPE_CASE_DOCUMENTS = "application/vnd.uk.gov.hmcts.ccd-data-store-api.case-documents.v2+json;charset=UTF-8";
    static readonly V2_MEDIATYPE_CASE_DATA_VALIDATE = "application/vnd.uk.gov.hmcts.ccd-data-store-api.case-data-validate.v2+json;charset=UTF-8";
    static readonly V2_MEDIATYPE_CREATE_EVENT = "application/vnd.uk.gov.hmcts.ccd-data-store-api.create-event.v2+json;charset=UTF-8";
    static readonly V2_MEDIATYPE_CREATE_CASE = "application/vnd.uk.gov.hmcts.ccd-data-store-api.create-case.v2+json;charset=UTF-8";
    static readonly PUI_CASE_MANAGER = "pui-case-manager";
    get: (jurisdictionId: string, caseTypeId: string, caseId: string) => Observable<CaseView>;
    static updateChallengedAccessRequestAttributes(httpClient: HttpClient, caseId: string, attributesToUpdate: {
        [x: string]: any;
    }): Observable<RoleAssignmentResponse>;
    static updateSpecificAccessRequestAttributes(httpClient: HttpClient, caseId: string, attributesToUpdate: {
        [x: string]: any;
    }): Observable<RoleAssignmentResponse>;
    constructor(http: HttpService, appConfig: AbstractAppConfig, orderService: OrderService, errorService: HttpErrorService, wizardPageFieldToCaseFieldMapper: WizardPageFieldToCaseFieldMapper, loadingService: LoadingService, sessionStorageService: SessionStorageService, retryUtil: RetryUtil);
    getCaseView(jurisdictionId: string, caseTypeId: string, caseId: string): Observable<CaseView>;
    getCaseViewV2(caseId: string): Observable<CaseView>;
    private pipeErrorProcessor;
    private finalizeGetCaseViewWith;
    syncWait(seconds: any): void;
    getEventTrigger(caseTypeId: string, eventTriggerId: string, caseId?: string, ignoreWarning?: string): Observable<CaseEventTrigger>;
    createEvent(caseDetails: CaseView, eventData: CaseEventData): Observable<{}>;
    validateCase(ctid: string, eventData: CaseEventData, pageId: string): Observable<object>;
    createCase(ctid: string, eventData: CaseEventData): Observable<object>;
    getPrintDocuments(caseId: string): Observable<CasePrintDocument[]>;
    private buildEventTriggerUrl;
    private initialiseEventTrigger;
    getCourtOrHearingCentreName(locationId: number): Observable<any>;
    createChallengedAccessRequest(caseId: string, request: ChallengedAccessRequest): Observable<RoleAssignmentResponse>;
    createSpecificAccessRequest(caseId: string, sar: SpecificAccessRequest): Observable<RoleAssignmentResponse>;
    getLinkedCases(caseId: string): Observable<LinkedCasesResponse$1>;
    private addClientContextHeader;
    private updateClientContextStorage;
    static ɵfac: i0.ɵɵFactoryDeclaration<CasesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CasesService>;
}

declare class CaseNotifier {
    private readonly casesService;
    static readonly CASE_NAME = "caseNameHmctsInternal";
    static readonly CASE_LOCATION = "caseManagementLocation";
    private readonly caseViewSource;
    caseView: rxjs.Observable<CaseView>;
    cachedCaseView: CaseView;
    constructor(casesService: CasesService);
    removeCachedCase(): void;
    announceCase(c: CaseView): void;
    fetchAndRefresh(cid: string): rxjs.Observable<CaseView>;
    setBasicFields(tabs: CaseTab[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseNotifier, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CaseNotifier>;
}

declare const MULTIPLE_TASKS_FOUND = "More than one task found!";
declare class WorkAllocationService {
    private readonly http;
    private readonly appConfig;
    private readonly errorService;
    private readonly alertService;
    private readonly caseNotifier;
    private readonly sessionStorageService;
    static iACCaseOfficer: string;
    static iACAdmOfficer: string;
    private features;
    private jurisdiction;
    private caseType;
    constructor(http: HttpService, appConfig: AbstractAppConfig, errorService: HttpErrorService, alertService: AlertService, caseNotifier: CaseNotifier, sessionStorageService: SessionStorageService);
    /**
     * Call the API to get tasks matching the search criteria.
     * @param searchRequest The search parameters that specify which tasks to match.
     */
    searchTasks(searchRequest: TaskSearchParameter): Observable<object>;
    private isWAEnabled;
    /**
     * Call the API to assign a task.
     * @param taskId specifies which task should be assigned.
     * @param userId specifies the user the task should be assigned to.
     */
    assignTask(taskId: string, userId: string): Observable<any>;
    /**
     * Call the API to complete a task.
     * @param taskId specifies which task should be completed.
     */
    completeTask(taskId: string, eventName?: string): Observable<any>;
    /**
     * Call the API to assign and complete a task.
     * @param taskId specifies which task should be completed.
     */
    assignAndCompleteTask(taskId: string, eventName?: string): Observable<any>;
    /**
     * Handles the response from the observable to get the user details when task is completed.
     * @param response is the response given from the observable which contains the user detaild.
     */
    handleTaskCompletionError(): void;
    /**
     * Look for open tasks for a case and event combination. There are 5 possible scenarios:
     *   1. No tasks found                              => Success.
     *   2. One task found => Mark as done              => Success.
     *   3. One task found => Mark as done throws error => Failure.
     *   4. More than one task found                    => Failure.
     *   5. Search call throws an error                 => Failure.
     * @param ccdId The ID of the case to find tasks for.
     * @param eventId The ID of the event to find tasks for.
     */
    completeAppropriateTask(ccdId: string, eventId: string, jurisdiction: string, caseTypeId: string): Observable<any>;
    /**
     * Return tasks for case and event.
     */
    getTasksByCaseIdAndEventId(eventId: string, caseId: string, caseType: string, jurisdiction: string): Observable<TaskPayload>;
    /**
     * Call the API to get a task
     */
    getTask(taskId: string): Observable<TaskResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkAllocationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WorkAllocationService>;
}

interface EventCompletionComponentEmitter {
    eventCanBeCompleted: EventEmitter<boolean>;
    setTaskState(taskState: number): any;
}
interface EventCompletionStateMachineContext {
    task: Task;
    caseId: string;
    eventId: string;
    reassignedTask: Task;
    router: Router;
    route: ActivatedRoute;
    sessionStorageService: SessionStorageService;
    workAllocationService: WorkAllocationService;
    alertService: AlertService;
    canBeCompleted: boolean;
    component: EventCompletionComponentEmitter;
}

declare enum EventCompletionStates {
    CheckTasksCanBeCompleted = "check-tasks-can-be-completed",
    CompleteEventAndTask = "complete-event-and-task",
    CancelEvent = "cancel-event",
    CompleteEventNotTask = "complete-event-not-task",
    TaskCompetedOrCancelled = "task-completed-or-cancelled",
    TaskAssignedToAnotherUser = "task-assigned-to-another-user",
    TaskReassignToUser = "task-reassign-to-user",
    TaskAssignToUser = "task-assign-to-user",
    TaskUnassigned = "task-unassigned",
    Final = "final"
}

declare class Wizard {
    pages: WizardPage[];
    private readonly orderService;
    constructor(wizardPages: WizardPage[]);
    firstPage(canShow: Predicate<WizardPage>): WizardPage;
    getPage(pageId: string, canShow: Predicate<WizardPage>): WizardPage;
    findWizardPage(caseFieldId: string): WizardPage;
    nextPage(pageId: string, canShow: Predicate<WizardPage>): WizardPage;
    previousPage(pageId: string, canShow: Predicate<WizardPage>): WizardPage;
    hasPage(pageId: string): boolean;
    hasPreviousPage(pageId: string, canShow: Predicate<WizardPage>): boolean;
    reverse(): WizardPage[];
    private findPage;
    private findExistingIndex;
}

declare class FieldsUtils {
    private static readonly logger;
    private static readonly caseLevelCaseFlagsFieldId;
    private static readonly currencyPipe;
    private static readonly datePipe;
    static readonly LABEL_SUFFIX = "---LABEL";
    static readonly SERVER_RESPONSE_FIELD_TYPE_COLLECTION = "Collection";
    static readonly SERVER_RESPONSE_FIELD_TYPE_COMPLEX = "Complex";
    static readonly SERVER_RESPONSE_FIELD_TYPE_DYNAMIC_LIST_TYPE: FieldTypeEnum[];
    static readonly defaultTabList: {
        PRLAPPS: string;
    };
    static isValidDisplayContext(ctx: string): boolean;
    static createToken(): string;
    static isTranslatable(fieldType: FieldType): boolean;
    static convertToCaseField(obj: any): CaseField;
    static toValuesMap(caseFields: CaseField[]): any;
    static isObject(elem: any): boolean;
    static isNonEmptyObject(elem: any): boolean;
    static isArray(elem: any): boolean;
    static areCollectionValuesSimpleFields(fieldValue: any[]): boolean;
    static isCollectionOfSimpleTypes(fieldValue: any): boolean;
    static isMultiSelectValue(form: any): boolean;
    static isNonEmptyArray(pageFormFields: any): boolean;
    static isCollection(pageFormFields: any): boolean;
    static isCollectionWithValue(pageFormFields: any[]): boolean;
    static cloneObject(obj: any): any;
    static getCaseFields(caseView: CaseView): CaseField[];
    static addCaseFieldAndComponentReferences(c: AbstractControl, cf: CaseField, comp: AbstractFormFieldComponent): void;
    /**
     * Recursive check of an array or object and its descendants for the presence of any non-empty values.
     *
     * @param object The array or object to check
     * @returns `true` if the array or object (or a descendant) contains at least one non-empty value; `false` otherwise
     */
    static containsNonEmptyValues(object: object): boolean;
    /**
     * handleNestedDynamicLists()
     * Reassigns list_item and value data to DynamicList children
     * down the tree. Server response returns data only in
     * the `value` object of parent complex type
     *
     * EUI-2530 Dynamic Lists for Elements in a Complex Type
     *
     * @param jsonBody - { case_fields: [ CaseField, CaseField ] }
     */
    static handleNestedDynamicLists(jsonBody: {
        case_fields: CaseField[];
    }): any;
    private static prepareValue;
    private static readonly DEFAULT_MERGE_FUNCTION;
    private static readonly LABEL_MERGE_FUNCTION;
    /**
     * Formats a `MoneyGBP` value to include currency units.
     * @param fieldValue The CurrencyPipe expects an `any` parameter so this must also be `any`,
     * but it should be "number-like" (e.g., '1234')
     * @returns A formatted string (e.g., £12.34)
     */
    private static getMoneyGBP;
    private static getLabel;
    private static getDate;
    private static getFixedListLabelByCodeOrEmpty;
    private static textForInvalidField;
    private static setDynamicListDefinition;
    private static getDynamicListValue;
    private static getNestedFieldValues;
    static isFlagsCaseField(caseField: CaseField): boolean;
    /**
     * @deprecated Use {@link isCaseFieldOfType} instead, passing 'FlagLauncher' as the single type in the `types` array
     */
    static isFlagLauncherCaseField(caseField: CaseField): boolean;
    /**
     * @deprecated Use {@link isCaseFieldOfType} instead, passing 'ComponentLauncher' as the single type in the `types`
     * array
     */
    static isComponentLauncherCaseField(caseField: CaseField): boolean;
    /**
     * Checks if a {@link CaseField} is of one of the given field types.
     *
     * @param caseField The `CaseField` to check
     * @param types An array of one or more field types
     * @returns `true` if the `CaseField` type is one of those in the array of types to check against; `false`
     * otherwise or if `caseField` or `types` are falsy
     */
    static isCaseFieldOfType(caseField: CaseField, types: FieldTypeEnum[]): boolean;
    static isLinkedCasesCaseField(caseField: CaseField): boolean;
    static containsLinkedCasesCaseField(caseFields: CaseField[]): boolean;
    static isFlagsFieldType(fieldType: FieldType): boolean;
    /**
     * Extract flags data from a `CaseField` instance, recursing and iterating through sub-fields of a Complex field or
     * each field in a Collection field.
     *
     * @param flags An array for accumulating extracted flags data and derived `FormGroup` paths
     * @param caseField A `CaseField` instance from which to extract the flags data
     * @param pathToFlagsFormGroup A (dot-delimited) string for concatenating the name of each control that forms the path
     * to the `FormGroup` for the `Flags` instance
     * @param topLevelCaseField The top-level `CaseField` that contains the value property. This is required because _only
     * top-level_ `CaseField`s contain actual values and a reference needs to be maintained to such a field
     * @param currentValue The current value object of a `CaseField` that is a sub-field of a non root-level Complex field.
     * Required for mapping the `CaseField` value to a `Flags` object if it is a "Flags" `CaseField`. (For Complex types,
     * only the _root-level_ `CaseField` contains a value property - all sub-fields, including any nested Complex fields,
     * do *not* contain any values themselves.)
     * @returns An array of `FlagsWithFormGroupPath`, each instance comprising a `Flags` object derived from a `CaseField`
     * of type "Flags", and the dot-delimited path string to the corresponding `FormGroup`
     */
    static extractFlagsDataFromCaseField(flags: FlagsWithFormGroupPath[], caseField: CaseField, pathToFlagsFormGroup: string, topLevelCaseField: CaseField, currentValue?: object): FlagsWithFormGroupPath[];
    private static mapCaseFieldToFlagsWithFormGroupPathObject;
    private static mapValueToFlagsWithFormGroupPathObject;
    /**
     * Count active flags in a `CaseField` instance, recursing and iterating through sub-fields of a Complex field or each
     * field in a Collection field.
     *
     * @param activeCount An accumulation of the total number of active flags
     * @param caseField A `CaseField` instance for which to count the active flags
     * @param currentValue The current value object of a `CaseField` that is a sub-field of a non root-level Complex field.
     * (For Complex types, only the _root-level_ `CaseField` contains a value property - all sub-fields, including any
     * nested Complex fields, do *not* contain any values themselves.)
     * @returns The count of active flags
     */
    static countActiveFlagsInCaseField(activeCount: number, caseField: CaseField, currentValue?: object): number;
    static getValidationErrorMessageForFlagLauncherCaseField(caseField: CaseField): string;
    static getUserTaskFromClientContext(clientContextStr: string): UserTask;
    buildCanShowPredicate(eventTrigger: CaseEventTrigger, form: any): Predicate<WizardPage>;
    getCurrentEventState(eventTrigger: {
        case_fields: CaseField[];
    }, form: FormGroup): object;
    cloneCaseField(obj: any): CaseField;
    mergeCaseFieldsAndFormFields(caseFields: CaseField[], formFields: object): object;
    mergeLabelCaseFieldsAndFormFields(caseFields: CaseField[], formFields: object): object;
    controlIterator(aControl: AbstractControl, formArrayFn: (array: FormArray) => void, formGroupFn: (group: FormGroup) => void, controlFn: (control: FormControl) => void): void;
    private mergeFields;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldsUtils, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FieldsUtils>;
}

declare class FieldsPurger {
    private readonly fieldsUtils;
    constructor(fieldsUtils: FieldsUtils);
    clearHiddenFields(form: FormGroup, wizard: Wizard, eventTrigger: CaseEventTrigger, currentPageId: string): void;
    private clearHiddenFieldForPageShowCondition;
    private clearHiddenFieldForFieldShowCondition;
    private retainHiddenValueByFieldType;
    private isHidden;
    private findCaseFieldByWizardPageFieldId;
    private hasShowConditionPage;
    private hasShowConditionField;
    private getShowConditionKey;
    private resetField;
    private resetPage;
    private getType;
    private isObject;
    private isReadonly;
    /**
     * Deletes a field value by setting the value of the corresponding {@link FormControl} to null (or an empty array
     * if the field type is `Collection`), except when the field type is `Complex` or `Document`. For `Complex` field
     * types, this recursive method is called until simple or "base" field types are reached. For `Document` field
     * types, its _sub-field_ `FormControl` values are set to null.
     *
     * @param formGroup The `FormGroup` instance containing the `FormControl` for the specified field
     * @param field The `CaseField` whose value is to be deleted in the backend
     * @param parentField Reference to the parent `CaseField`. Used for checking specifically where a Complex field and
     * its sub-fields have `retain_hidden_value` set to `true`, but the field's parent has it set to `false` or undefined
     */
    deleteFieldValue(formGroup: FormGroup, field: CaseField, parentField?: CaseField): void;
    /**
     * Maps all values of an array to `null`, retaining keys for any values that are objects. For example,
     * `[{ id: '0', value: 'Test' }, 'Test']` would become `[{ id: null, value: null }, null]`.
     * @param array The array of values to map
     * @returns A new array with the mapped values
     */
    mapArrayValuesToNull(array: any[]): any[];
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldsPurger, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FieldsPurger>;
}

declare class FormErrorService {
    mapFieldErrors(errors: {
        id: string;
        message: string;
    }[], form: FormGroup, errorKey: string): void;
    private getFormControl;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormErrorService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormErrorService>;
}

declare class FormValidatorsService {
    private static readonly CUSTOM_VALIDATED_TYPES;
    private static readonly DEFAULT_INPUT_TEXT;
    private static readonly DEFAULT_INPUT_TEXTAREA;
    static addValidators(caseField: CaseField, control: AbstractControl): AbstractControl;
    static emptyValidator(): ValidatorFn;
    static markDownPatternValidator(): ValidatorFn;
    addValidators(caseField: CaseField, control: AbstractControl): AbstractControl;
    addMarkDownValidators(formGroup: AbstractControl, controlPath: string): AbstractControl;
    private static hasMultiBracket;
    private static findOpeningTextClose;
    private static extendClosingRunAndRequireParen;
    private static isValidReferenceUrlTitleTail;
    private static matchesReferenceUrlDef;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormValidatorsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormValidatorsService>;
}

declare class FieldTypeSanitiser {
    static readonly FIELD_TYPE_COMPLEX: FieldTypeEnum;
    static readonly FIELD_TYPE_COLLECTION: FieldTypeEnum;
    static readonly FIELD_TYPE_DYNAMIC_LIST: FieldTypeEnum;
    static readonly FIELD_TYPE_DYNAMIC_RADIO_LIST: FieldTypeEnum;
    static readonly FIELD_TYPE_DYNAMIC_MULTISELECT_LIST: FieldTypeEnum;
    static readonly DYNAMIC_LIST_TYPE: FieldTypeEnum[];
    /**
     * This method finds dynamiclists in a form and replaces their string
     * values, with a JSON object, as below:
     * From: 'xyz'
     * To  : {
     *   value: { code:'xyz', label:'XYZ' },
     *   list_items: [
     *     { code:'xyz', label:'XYZ'},
     *     { code:'abc', label:'ABC'}
     *   ]
     * }
     * @param caseFields The CaseFields to assess.
     * @param data The data in the form.
     */
    sanitiseLists(caseFields: CaseField[], data: any): void;
    ensureDynamicMultiSelectListPopulated(caseFields: CaseField[]): CaseField[];
    private checkNestedDynamicList;
    private isDynamicList;
    private convertArrayToDynamicListOutput;
    private convertStringToDynamicListOutput;
    private getListItems;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldTypeSanitiser, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FieldTypeSanitiser>;
}

declare class FormValueService {
    private readonly fieldTypeSanitiser;
    static getFieldValue(form: any, fieldKey: any, colIndex: any): any;
    /**
     * A recursive method to remove anything with a `---LABEL` suffix.
     * @param data The data to recurse through and remove MultiSelect labels.
     */
    static removeMultiSelectLabels(data: any): void;
    private static isReadOnly;
    private static isOptional;
    private static isLabel;
    private static isEmptyData;
    /**
     * Should we clear out optional, empty, complex objects?
     * @param clearEmpty False property if we simply want to skip it.
     * @param data The data to assess for "emptiness".
     * @param field The CaseField that will tell us if this is optional.
     */
    private static clearOptionalEmpty;
    constructor(fieldTypeSanitiser: FieldTypeSanitiser);
    sanitise(rawValue: object, isCaseFlagJourney?: boolean): object;
    sanitiseCaseReference(reference: string): string;
    filterCurrentPageFields(caseFields: CaseField[], editForm: any): any;
    sanitiseDynamicLists(caseFields: CaseField[], editForm: any): any;
    private sanitiseObject;
    private sanitiseArray;
    private sanitiseValue;
    clearNonCaseFields(data: object, caseFields: CaseField[]): void;
    removeNullLabels(data: object, caseFields: CaseField[]): void;
    removeEmptyDocuments(data: object, caseFields: CaseField[]): void;
    /**
     * Clear out unnecessary fields from a data object, based on an array of CaseFields.
     * This method is recursive and will call itself if it encounters particular field types.
     *
     * @param data The object to be tidied up.
     * @param caseFields The CaseFields that need to be cleaned up.
     * @param clearEmpty Whether or not we should clear out empty, optional, complex objects.
     * @param clearNonCase Whether or not we should clear out non-case fields at the top level.
     */
    removeUnnecessaryFields(data: object, caseFields: CaseField[], clearEmpty?: boolean, clearNonCase?: boolean, fromPreviousPage?: boolean, currentPageCaseFields?: any[]): void;
    removeInvalidCollectionData(data: object, field: CaseField): void;
    /**
     * Remove any empty collection fields where a value of greater than zero is specified in the field's {@link FieldType}
     * `min` attribute.
     *
     * @param data The object tree of form values on which to perform the removal
     * @param caseFields The list of underlying {@link CaseField} domain model objects for each field
     */
    removeEmptyCollectionsWithMinValidation(data: object, caseFields: CaseField[]): void;
    /**
     * Remove from the top level of the form data any case fields of a given type or types that are not intended to be
     * persisted. This function is intended to remove "special" case field types from the data, such as FlagLauncher or
     * ComponentLauncher fields.
     *
     * @param data The object tree of form values on which to perform the removal at the top level only
     * @param caseFields The list of underlying {@link CaseField} domain model objects for each field
     * @param types An array of one or more field types
     */
    removeCaseFieldsOfType(data: object, caseFields: CaseField[], types: FieldTypeEnum[]): void;
    /**
     * Re-populate the form data from the values held in the case fields. This is necessary in order to pick up, for
     * each `Flags` field, any flag details data not currently present.
     *
     * `Flags` fields may be contained in other `CaseField` instances, either as a sub-field of a Complex field, or
     * fields in a collection (or sub-fields of Complex fields in a collection). Therefore, it is necessary to
     * iterate through all `CaseField`s.
     *
     * @param data The object tree of form values on which to perform the data population
     * @param caseFields The list of underlying {@link CaseField} domain model objects for each field
     */
    repopulateFormDataFromCaseFieldValues(data: object, caseFields: CaseField[]): void;
    /**
     * Populate the linked cases from the data held in its corresponding CaseField.
     *
     * @param data The object tree of form values on which to perform the data population
     * @param caseFields The list of underlying {@link CaseField} domain model objects for each field
     */
    populateLinkedCasesDetailsFromCaseFields(data: object, caseFields: CaseField[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormValueService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FormValueService>;
}

declare class MultipageComponentStateService {
    private isJourneyAtStart;
    private journeyCollection;
    private instigator;
    private readonly journeyState;
    setJourneyCollection(journeyCollection: Journey[]): void;
    getJourneyCollection(): Journey[];
    addTojourneyCollection(journey: Journey): void;
    resetJourneyCollection(): void;
    setInstigator(instigator: JourneyInstigator): void;
    getInstigator(): JourneyInstigator | null;
    setJourneyState(journey: Journey): void;
    getJourneyState(journey: Journey): Journey | null;
    resetJourneyState(): void;
    getJourneyCollectionMainObject(): Journey;
    reset(): void;
    next(): void;
    previous(): void;
    get isAtStart(): boolean;
    set isAtStart(isAtStart: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<MultipageComponentStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MultipageComponentStateService>;
}

interface JudicialUserModel {
    emailId: string;
    fullName: string;
    idamId: string;
    isJudge: string;
    isMagistrate: string;
    isPanelMember: string;
    knownAs: string;
    personalCode: string;
    surname: string;
    title: string;
}

declare class JurisdictionService {
    private readonly httpService;
    readonly selectedJurisdictionSource: Subject<Jurisdiction>;
    private readonly _selectedJurisdictionBS;
    readonly selectedJurisdiction: Observable<Jurisdiction>;
    constructor(httpService: HttpService);
    getJurisdictions(): Observable<Jurisdiction[]>;
    announceSelectedJurisdiction(jurisdiction: Jurisdiction): void;
    getSelectedJurisdiction(): BehaviorSubject<Jurisdiction>;
    searchJudicialUsers(searchTerm: string, serviceId: string): Observable<JudicialUserModel[]>;
    searchJudicialUsersByPersonalCodes(personalCodes: string[]): Observable<JudicialUserModel[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<JurisdictionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JurisdictionService>;
}

declare class BannersService {
    private readonly httpService;
    private readonly appConfig;
    static readonly V2_MEDIATYPE_BANNERS = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-banners.v2+json;charset=UTF-8";
    constructor(httpService: HttpService, appConfig: AbstractAppConfig);
    getBanners(jurisdictionReferences: string[]): Observable<Banner[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BannersService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BannersService>;
}

type StructuredLogLevel = 'error' | 'warn' | 'info' | 'debug';
interface StructuredLogEntry {
    level: StructuredLogLevel;
    message: string;
    timestamp: string;
    context?: unknown;
}
declare class StructuredLoggerService {
    private static readonly CIRCULAR_VALUE;
    private static readonly MAX_DEPTH_VALUE;
    private static readonly MAX_REDACTION_DEPTH;
    private static readonly REDACTED_VALUE;
    private static readonly KEY_VALUE_PATTERN;
    private static readonly SENSITIVE_KEY_PATTERN;
    private static readonly BEARER_TOKEN_PATTERN;
    debug(message: string, context?: unknown): void;
    error(message: string, context?: unknown): void;
    info(message: string, context?: unknown): void;
    warn(message: string, context?: unknown): void;
    redact(value: unknown): unknown;
    private write;
    private redactValue;
    private redactError;
    private redactObject;
    private redactSensitiveString;
    private hasSensitiveNamedValue;
    private isNameKey;
    private isSensitiveKey;
    private isValueKey;
    static ɵfac: i0.ɵɵFactoryDeclaration<StructuredLoggerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<StructuredLoggerService>;
}

declare enum NavigationOrigin {
    DRAFT_DELETED = 0,
    ERROR_DELETING_DRAFT = 1,
    DRAFT_RESUMED = 2,
    EVENT_TRIGGERED = 3,
    NO_READ_ACCESS_REDIRECTION = 4
}

declare class NavigationNotifierService {
    navigationSource: BehaviorSubject<any>;
    navigation: rxjs.Observable<any>;
    announceNavigation(origin: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NavigationNotifierService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<NavigationNotifierService>;
}

declare class OrderService {
    /**
     * Use `sort` function instead or `compareAsc`
     */
    private static readonly DEFAULT_COMPARE_FUNCTION;
    sortAsc: (a: Orderable, b: Orderable) => number;
    /**
     * Clone and sort array. Ascending order used by default.
     *
     * @param array Array to sort
     * @returns Orderable[] Sorted clone array.
     */
    sort<T extends Orderable>(array: T[], sortingFunction?: (a: Orderable, b: Orderable) => number): T[];
    static ɵfac: i0.ɵɵFactoryDeclaration<OrderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OrderService>;
}

declare class ProfileService {
    private readonly httpService;
    private readonly appConfig;
    static readonly V2_MEDIATYPE_USER_PROFILE = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-user-profile.v2+json;charset=UTF-8";
    private static readonly URL;
    constructor(httpService: HttpService, appConfig: AbstractAppConfig);
    get(): Observable<Profile>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProfileService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProfileService>;
}

declare class ProfileNotifier {
    readonly profileSource: BehaviorSubject<Profile>;
    profile: rxjs.Observable<Profile>;
    announceProfile(profile: Profile): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ProfileNotifier, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ProfileNotifier>;
}

declare class RequestOptionsBuilder {
    static readonly FIELD_PREFIX = "case.";
    /**
     * Assess the value to see if it should be included in the request options.
     * If it's null or an "empty" string, it shouldn't be.
     *
     * @param value The value to be assessed.
     */
    private static includeParam;
    buildOptions(metaCriteria: object, caseCriteria: object, view?: SearchView): OptionsType;
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestOptionsBuilder, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RequestOptionsBuilder>;
}
type SearchView = 'SEARCH' | 'WORKBASKET';

declare class SearchInput implements Orderable {
    label: string;
    order: number;
    field: Field;
    metadata?: boolean;
    display_context_parameter?: string;
    constructor(label: string, order: number, field: Field, metadata?: boolean, display_context_parameter?: string);
}

declare class WindowService {
    locationAssign(url: string): void;
    setLocalStorage(key: string, value: string): void;
    getLocalStorage(key: string): string;
    clearLocalStorage(): void;
    removeLocalStorage(key: string): void;
    setSessionStorage(key: string, value: string): void;
    getSessionStorage(key: string): string;
    openOnNewTab(url: string): void;
    confirm(message: string): boolean;
    alert(message: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WindowService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WindowService>;
}

declare class SearchFiltersComponent implements OnInit {
    private readonly searchService;
    private readonly orderService;
    private readonly jurisdictionService;
    private readonly windowService;
    private readonly logger;
    readonly PARAM_JURISDICTION = "jurisdiction";
    readonly PARAM_CASE_TYPE = "case-type";
    readonly PARAM_CASE_STATE = "case-state";
    caseFields: CaseField[];
    jurisdictions: Jurisdiction[];
    autoApply: boolean;
    onApply: EventEmitter<any>;
    onReset: EventEmitter<any>;
    onJurisdiction: EventEmitter<any>;
    searchInputs: SearchInput[];
    searchInputsReady: boolean;
    selected: {
        jurisdiction?: Jurisdiction;
        caseType?: CaseTypeLite;
        formGroup?: FormGroup;
        caseState?: CaseState;
        page?: number;
        metadataFields?: string[];
    };
    selectedJurisdictionCaseTypes?: CaseTypeLite[];
    formGroup: FormGroup;
    constructor(searchService: SearchService, orderService: OrderService, jurisdictionService: JurisdictionService, windowService: WindowService);
    ngOnInit(): void;
    reset(): void;
    apply(): void;
    populateValuesInLocalStorage(): void;
    getValuesFromLocalStorage(): Jurisdiction;
    getMetadataFields(): string[];
    isSearchable(): boolean;
    isSearchableAndSearchInputsReady(): boolean;
    onJurisdictionIdChange(): void;
    onCaseTypeIdChange(): void;
    isJurisdictionSelected(): boolean;
    private getQueryParams;
    private selectCaseType;
    private setFocusToTop;
    private getCaseFields;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchFiltersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchFiltersComponent, "ccd-search-filters", never, { "jurisdictions": { "alias": "jurisdictions"; "required": false; }; "autoApply": { "alias": "autoApply"; "required": false; }; }, { "onApply": "onApply"; "onReset": "onReset"; "onJurisdiction": "onJurisdiction"; }, never, never, false, never>;
}

declare class DefinitionsService {
    private readonly http;
    private readonly appConfig;
    constructor(http: HttpService, appConfig: AbstractAppConfig);
    getCaseTypes(jurisdictionId: string, access: string): Observable<CaseTypeLite[]>;
    getJurisdictions(access: string): Observable<Jurisdiction[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DefinitionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DefinitionsService>;
}

declare class SearchFiltersWrapperComponent implements OnInit {
    private readonly definitionsService;
    autoApply: boolean;
    onApply: EventEmitter<any>;
    onReset: EventEmitter<any>;
    onJurisdiction: EventEmitter<any>;
    jurisdictions: Jurisdiction[];
    isVisible: boolean;
    constructor(definitionsService: DefinitionsService);
    ngOnInit(): void;
    onWrapperApply(value: any): void;
    onWrapperReset(value: any): void;
    onWrapperJurisdiction(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchFiltersWrapperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchFiltersWrapperComponent, "ccd-search-filters-wrapper", never, { "autoApply": { "alias": "autoApply"; "required": false; }; }, { "onApply": "onApply"; "onReset": "onReset"; "onJurisdiction": "onJurisdiction"; }, never, never, false, never>;
}

declare class FixedListPipe implements PipeTransform {
    private static readonly EMPTY;
    transform(value: string, items: FixedListItem[]): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FixedListPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FixedListPipe, "ccdFixedList", false>;
}

declare class FixedRadioListPipe implements PipeTransform {
    private static readonly EMPTY;
    transform(value: string, items: FixedListItem[]): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FixedRadioListPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FixedRadioListPipe, "ccdFixedRadioList", false>;
}

declare class DynamicListPipe implements PipeTransform {
    private static readonly EMPTY;
    transform(value: string, items: FixedListItem[]): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicListPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DynamicListPipe, "ccdDynamicList", false>;
}

declare class DynamicRadioListPipe implements PipeTransform {
    private static readonly EMPTY;
    transform(value: any, items: FixedListItem[]): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DynamicRadioListPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DynamicRadioListPipe, "ccdDynamicRadioList", false>;
}

declare class DocumentUrlPipe implements PipeTransform {
    private readonly appConfig;
    constructor(appConfig: AbstractAppConfig);
    transform(value: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentUrlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DocumentUrlPipe, "ccdDocumentUrl", false>;
}

declare class FlagFieldDisplayPipe extends AsyncPipe implements PipeTransform {
    private readonly translationService;
    private readonly ref;
    private languageObservables;
    constructor(translationService: RpxTranslationService, ref: ChangeDetectorRef);
    transform<T>(obj: null | undefined): null;
    transform<T>(obj: Observable<T> | Subscribable<T> | Promise<T> | null | undefined): T | null;
    transform<T = FlagType | FlagDetail>(value: T, fieldName: string): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<FlagFieldDisplayPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FlagFieldDisplayPipe, "flagFieldDisplay", false>;
}

declare class LanguageInterpreterDisplayPipe extends AsyncPipe implements PipeTransform {
    private readonly translationService;
    private readonly ref;
    private languageObservables;
    constructor(translationService: RpxTranslationService, ref: ChangeDetectorRef);
    transform<T>(obj: null | undefined): null;
    transform<T>(obj: Observable<T> | Subscribable<T> | Promise<T> | null | undefined): T | null;
    transform<T = Language>(value: T): string | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<LanguageInterpreterDisplayPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<LanguageInterpreterDisplayPipe, "languageInterpreterDisplay", false>;
}

declare class ManageCaseFlagsLabelDisplayPipe extends AsyncPipe implements PipeTransform {
    private readonly translationService;
    private readonly ref;
    private static readonly CASE_LEVEL_CASE_FLAGS_FIELD_ID;
    private languageObservables;
    constructor(translationService: RpxTranslationService, ref: ChangeDetectorRef);
    transform<T>(obj: null | undefined): null;
    transform<T>(obj: Observable<T> | Subscribable<T> | Promise<T> | null | undefined): T | null;
    transform<T = FlagDetailDisplayWithFormGroupPath>(value: T): string | null;
    getPartyName(flagDisplay: FlagDetailDisplayWithFormGroupPath): Observable<string>;
    getRoleOnCase(flagDisplay: FlagDetailDisplayWithFormGroupPath): string;
    getFlagName(flagDetail: FlagDetail): string;
    getFlagDescription(flagDetail: FlagDetail): string;
    getFlagComments(flagDetail: FlagDetail): string;
    private getNonFlagPathName;
    static ɵfac: i0.ɵɵFactoryDeclaration<ManageCaseFlagsLabelDisplayPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ManageCaseFlagsLabelDisplayPipe, "manageCaseFlagsLabelDisplay", false>;
}

declare class UpdateFlagTitleDisplayPipe extends AsyncPipe implements PipeTransform {
    private readonly translationService;
    private readonly ref;
    private languageObservables;
    constructor(translationService: RpxTranslationService, ref: ChangeDetectorRef);
    transform<T>(obj: null | undefined): null;
    transform<T>(obj: Observable<T> | Subscribable<T> | Promise<T> | null | undefined): T | null;
    transform<T = FlagDetail>(value: T): string | null;
    getFlagName(flagDetail: FlagDetail): string;
    getFlagDescription(flagDetail: FlagDetail): string;
    getFlagComments(flagDetail: FlagDetail): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdateFlagTitleDisplayPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<UpdateFlagTitleDisplayPipe, "updateFlagTitleDisplay", false>;
}

declare class UnsupportedFieldComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<UnsupportedFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnsupportedFieldComponent, "ccd-unsupported-field", never, {}, {}, never, never, false, never>;
}

declare class DatetimePickerComponent extends AbstractFormFieldComponent implements OnInit {
    private readonly formatTranslationService;
    private readonly ngxMatDateFormats;
    showSpinners: boolean;
    showSeconds: boolean;
    touchUi: boolean;
    enableMeridian: boolean;
    stepHour: number;
    stepMinute: number;
    stepSecond: number;
    color: ThemePalette;
    disableMinute: boolean;
    hideTime: boolean;
    hideMinutes: boolean;
    startView: string;
    yearSelection: boolean;
    checkTime: boolean;
    stringEdited: boolean;
    minError: boolean;
    maxError: boolean;
    dateTimeEntryFormat: string;
    datetimePicker: NgxMatDatetimepicker<any>;
    inputElement: ElementRef<HTMLInputElement>;
    dateControl: FormControl;
    private minimumDate;
    private maximumDate;
    private momentFormat;
    constructor(formatTranslationService: FormatTranslatorService, ngxMatDateFormats: MatDateFormats);
    ngOnInit(): void;
    setDateTimeFormat(): void;
    valueChanged(): void;
    focusIn(): void;
    focusOut(): void;
    toggleClick(): void;
    minDate(caseField: CaseField): Date;
    maxDate(caseField: CaseField): Date;
    configureDatePicker(dateTimePickerFormat: string): void;
    yearSelected(event: Moment): void;
    monthSelected(event: Moment): void;
    private formatValueAndSetErrors;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatetimePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatetimePickerComponent, "ccd-datetime-picker", never, { "dateControl": { "alias": "dateControl"; "required": false; }; }, {}, never, never, false, never>;
}

declare abstract class PaymentField extends AbstractFieldReadComponent {
    protected readonly appConfig: AbstractAppConfig;
    protected readonly sessionStorage: SessionStorageService;
    constructor(appConfig: AbstractAppConfig, sessionStorage: SessionStorageService);
    getBaseURL(): string;
    getPayBulkScanBaseURL(): string;
    getRefundsUrl(): string;
    getNotificationUrl(): string;
    getUserRoles(): any;
    getUserEmail(): any;
}

declare class WaysToPayFieldComponent extends PaymentField {
    constructor(appConfig: AbstractAppConfig, sessionStorage: SessionStorageService);
    getCardPaymentReturnUrl(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<WaysToPayFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WaysToPayFieldComponent, "ccd-ways-to-pay-field", never, {}, {}, never, never, false, never>;
}

declare class PaletteService {
    private readonly componentLauncherRegistry;
    getFieldComponentClass(caseField: CaseField, write: boolean): Type<{}>;
    private getComponentLauncherComponent;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaletteService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PaletteService>;
}

declare class FieldReadComponent extends AbstractFieldReadComponent implements OnInit {
    private readonly resolver;
    private readonly paletteService;
    withLabel: boolean;
    formGroup: FormGroup;
    caseFields: CaseField[];
    fieldContainer: ViewContainerRef;
    constructor(resolver: ComponentFactoryResolver, paletteService: PaletteService);
    ngOnInit(): void;
    private labelCanBeTranslated;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldReadComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FieldReadComponent, "ccd-field-read", never, { "withLabel": { "alias": "withLabel"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "caseFields": { "alias": "caseFields"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FieldWriteComponent extends AbstractFieldWriteComponent implements OnInit, OnChanges {
    private readonly resolver;
    private readonly paletteService;
    canHaveGreyBar: boolean;
    caseFields: CaseField[];
    fieldContainer: ViewContainerRef;
    private componentRef;
    constructor(resolver: ComponentFactoryResolver, paletteService: PaletteService);
    protected addValidators(caseField: CaseField, control: AbstractControl): void;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private applyInputsToChild;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldWriteComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FieldWriteComponent, "ccd-field-write", never, { "caseFields": { "alias": "caseFields"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FieldReadLabelComponent extends AbstractFieldReadComponent implements OnChanges {
    canHaveGreyBar: boolean;
    withLabel: boolean;
    isLabel(): boolean;
    isComplex(): boolean;
    isCaseLink(): boolean;
    ngOnChanges(changes: SimpleChanges): void;
    private fixCaseField;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldReadLabelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FieldReadLabelComponent, "ccd-field-read-label", never, { "withLabel": { "alias": "withLabel"; "required": false; }; }, {}, never, ["*"], false, never>;
}

declare class LabelFieldComponent {
    caseField: CaseField;
    caseFields: CaseField[];
    labelCanBeTranslated: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<LabelFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LabelFieldComponent, "ccd-label-field", never, { "caseField": { "alias": "caseField"; "required": false; }; "caseFields": { "alias": "caseFields"; "required": false; }; "labelCanBeTranslated": { "alias": "labelCanBeTranslated"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CasePaymentHistoryViewerFieldComponent extends PaymentField {
    readonly PAYMENT_HISTORY_WARNING = "Recent payments may take a few minutes to reflect here.";
    constructor(appConfig: AbstractAppConfig, sessionStorage: SessionStorageService);
    static ɵfac: i0.ɵɵFactoryDeclaration<CasePaymentHistoryViewerFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CasePaymentHistoryViewerFieldComponent, "ccd-case-payment-history-viewer-field", never, {}, {}, never, never, false, never>;
}

declare class MoneyGbpInputComponent implements ControlValueAccessor, Validator {
    private static readonly PATTERN_REGEXP;
    id: string;
    name: string;
    mandatory: boolean;
    formControl: FormControl;
    displayValue: string;
    disabled: boolean;
    private rawValue;
    onChange(event: any): void;
    writeValue(obj: any): void;
    registerOnChange(fn: any): void;
    registerOnTouched(_: any): void;
    setDisabledState(isDisabled: boolean): void;
    validate(control: FormControl): ValidationErrors;
    registerOnValidatorChange(_: () => void): void;
    private propagateChange;
    static ɵfac: i0.ɵɵFactoryDeclaration<MoneyGbpInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MoneyGbpInputComponent, "ccd-money-gbp-input", never, { "id": { "alias": "id"; "required": false; }; "name": { "alias": "name"; "required": false; }; "mandatory": { "alias": "mandatory"; "required": false; }; "formControl": { "alias": "formControl"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CaseHistoryViewerFieldComponent extends AbstractFieldReadComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseHistoryViewerFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseHistoryViewerFieldComponent, "ccd-case-history-viewer-field", never, {}, {}, never, never, false, never>;
}

declare class EventLogComponent implements OnInit {
    events: CaseViewEvent[];
    onCaseHistory: EventEmitter<string>;
    selected: CaseViewEvent;
    isPartOfCaseTimeline: boolean;
    ngOnInit(): void;
    select(event: CaseViewEvent): void;
    caseHistoryClicked(eventId: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventLogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EventLogComponent, "ccd-event-log", never, { "events": { "alias": "events"; "required": false; }; }, { "onCaseHistory": "onCaseHistory"; }, never, never, false, never>;
}

declare class EventLogDetailsComponent {
    event: CaseViewEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventLogDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EventLogDetailsComponent, "ccd-event-log-details", never, { "event": { "alias": "event"; "required": false; }; }, {}, never, never, false, never>;
}

declare class EventLogTableComponent implements OnInit {
    private readonly sessionStorage;
    events: CaseViewEvent[];
    selected: CaseViewEvent;
    onSelect: EventEmitter<CaseViewEvent>;
    onCaseHistory: EventEmitter<string>;
    isPartOfCaseTimeline: boolean;
    isUserExternal: boolean;
    constructor(sessionStorage: SessionStorageService);
    ngOnInit(): void;
    select(event: CaseViewEvent): void;
    significantItemExist(event: CaseViewEvent): boolean;
    getSignificantItemUrl(event: CaseViewEvent): string;
    getSignificantItemDesc(event: CaseViewEvent): string;
    caseHistoryClicked(eventId: string): void;
    getAriaLabelforColumn(event: CaseViewEvent): string;
    getAriaLabelforRow(event: CaseViewEvent): string;
    getAriaLabelforLink(event: CaseViewEvent, isExternalUser: boolean): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventLogTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EventLogTableComponent, "ccd-event-log-table", never, { "events": { "alias": "events"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; }, { "onSelect": "onSelect"; "onCaseHistory": "onCaseHistory"; }, never, never, false, never>;
}

declare class ReadTextFieldComponent extends AbstractFieldReadComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadTextFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadTextFieldComponent, "ccd-read-text-field", never, {}, {}, never, never, false, never>;
}

declare class ReadTextAreaFieldComponent extends AbstractFieldReadComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadTextAreaFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadTextAreaFieldComponent, "ccd-read-text-area-field", never, {}, {}, never, never, false, never>;
}

declare class ReadNumberFieldComponent extends AbstractFieldReadComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadNumberFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadNumberFieldComponent, "ccd-read-number-field", never, {}, {}, never, never, false, never>;
}

declare class ReadEmailFieldComponent extends AbstractFieldReadComponent {
    isFieldValueEmpty(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadEmailFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadEmailFieldComponent, "ccd-read-email-field", never, {}, {}, never, never, false, never>;
}

declare class ReadPhoneUKFieldComponent extends AbstractFieldReadComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadPhoneUKFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadPhoneUKFieldComponent, "ccd-read-phone-uk-field", never, {}, {}, never, never, false, never>;
}

declare class ReadDateFieldComponent extends AbstractFieldReadComponent {
    timeZone: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadDateFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadDateFieldComponent, "ccd-read-date-field", never, {}, {}, never, never, false, never>;
}

declare class ReadCollectionFieldComponent extends AbstractFieldReadComponent implements OnInit {
    caseFields: CaseField[];
    isDisplayContextParameterAvailable: boolean;
    ngOnInit(): void;
    buildIdPrefix(index: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadCollectionFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadCollectionFieldComponent, "ccd-read-collection-field", never, { "caseFields": { "alias": "caseFields"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FocusService {
    /** unique ID of DOM element this service will focus on */
    readonly elementIdToFocus = "focusService-elementIdToFocus";
    /**
     * Focus on a specific element with the elementIdToFocus.
     * If there is no element in the DOM, no action is taken.
     */
    focus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FocusService>;
}

declare class ReadDocumentFieldComponent extends AbstractFieldReadComponent implements OnDestroy {
    private readonly windowService;
    private readonly documentManagement;
    private readonly router;
    private readonly route;
    private readonly casesService;
    caseViewSubscription: Subscription;
    constructor(windowService: WindowService, documentManagement: DocumentManagementService, router: Router, route: ActivatedRoute, casesService: CasesService);
    showMediaViewer(): void;
    openMediaViewer(documentFieldValue: any): void;
    getMediaViewerUrl(token: string): string;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadDocumentFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadDocumentFieldComponent, "ccd-read-document-field", never, {}, {}, never, never, false, never>;
}

declare class ReadJudicialUserFieldComponent extends AbstractFieldReadComponent implements OnInit, OnDestroy {
    private readonly jurisdictionService;
    judicialUser: JudicialUserModel;
    sub: Subscription;
    constructor(jurisdictionService: JurisdictionService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadJudicialUserFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadJudicialUserFieldComponent, "ccd-read-judicial-user-field", never, {}, {}, never, never, false, never>;
}

declare class YesNoService {
    private static readonly YES_INPUTS;
    private static readonly NO_INPUTS;
    private static readonly YES;
    private static readonly NO;
    private static readonly EMPTY;
    format(value: any): string;
    private isYes;
    private isNo;
    static ɵfac: i0.ɵɵFactoryDeclaration<YesNoService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<YesNoService>;
}

declare class ReadYesNoFieldComponent extends AbstractFieldReadComponent implements OnInit {
    private readonly yesNoService;
    formattedValue: string;
    constructor(yesNoService: YesNoService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadYesNoFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadYesNoFieldComponent, "ccd-read-yes-no-field", never, {}, {}, never, never, false, never>;
}

declare class ReadOrganisationFieldComponent extends AbstractFieldReadComponent implements OnInit {
    caseFields: CaseField[];
    paletteContext: typeof PaletteContext;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadOrganisationFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadOrganisationFieldComponent, "ccd-read-organisation-field", never, { "caseFields": { "alias": "caseFields"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ReadOrganisationFieldTableComponent extends AbstractFieldReadComponent implements OnInit {
    private readonly organisationService;
    private readonly organisationConverter;
    caseFields: CaseField[];
    organisations$: Observable<OrganisationVm[]>;
    selectedOrg$: Observable<SimpleOrganisationModel>;
    constructor(organisationService: OrganisationService, organisationConverter: OrganisationConverter);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadOrganisationFieldTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadOrganisationFieldTableComponent, "ccd-read-organisation-field-table", never, { "caseFields": { "alias": "caseFields"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ReadOrganisationFieldRawComponent extends AbstractFieldReadComponent implements OnInit {
    private readonly organisationService;
    private readonly organisationConverter;
    caseFields: CaseField[];
    organisations$: Observable<OrganisationVm[]>;
    selectedOrg$: Observable<SimpleOrganisationModel>;
    constructor(organisationService: OrganisationService, organisationConverter: OrganisationConverter);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadOrganisationFieldRawComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadOrganisationFieldRawComponent, "ccd-read-organisation-field-raw", never, { "caseFields": { "alias": "caseFields"; "required": false; }; }, {}, never, never, false, never>;
}

declare class Fee {
    FeeCode: string;
    FeeAmount: string;
    FeeDescription?: string;
    FeeVersion: string;
}

declare class FeeValue {
    value: Fee;
}

declare class ReadOrderSummaryFieldComponent extends AbstractFieldReadComponent {
    getFees(): FeeValue[];
    getPaymentTotal(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadOrderSummaryFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadOrderSummaryFieldComponent, "ccd-read-order-summary-field", never, {}, {}, never, never, false, never>;
}

declare class ReadOrderSummaryRowComponent extends AbstractFieldReadComponent implements OnInit {
    feeValue: FeeValue;
    ngOnInit(): void;
    getFeeAmount(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadOrderSummaryRowComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadOrderSummaryRowComponent, "[ccdReadOrderSummaryRow]", never, { "feeValue": { "alias": "feeValue"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ReadMoneyGbpFieldComponent extends AbstractFieldReadComponent implements OnInit {
    amount: any;
    value: any;
    ngOnInit(): void;
    isNumber(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadMoneyGbpFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadMoneyGbpFieldComponent, "ccd-read-money-gbp-field", never, { "amount": { "alias": "amount"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ReadMultiSelectListFieldComponent extends AbstractFieldReadComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadMultiSelectListFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadMultiSelectListFieldComponent, "ccd-read-multi-select-list-field", never, {}, {}, never, never, false, never>;
}

declare class ReadDynamicListFieldComponent extends AbstractFieldReadComponent implements OnInit {
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadDynamicListFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadDynamicListFieldComponent, "ccd-read-dynamic-list-field", never, {}, {}, never, never, false, never>;
}

declare class ReadFixedListFieldComponent extends AbstractFieldReadComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadFixedListFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadFixedListFieldComponent, "ccd-read-fixed-list-field", never, {}, {}, never, never, false, never>;
}

declare class ReadFixedRadioListFieldComponent extends AbstractFieldReadComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadFixedRadioListFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadFixedRadioListFieldComponent, "ccd-read-fixed-radio-list-field", never, {}, {}, never, never, false, never>;
}

declare class ReadDynamicRadioListFieldComponent extends AbstractFieldReadComponent implements OnInit {
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadDynamicRadioListFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadDynamicRadioListFieldComponent, "ccd-read-dynamic-radio-list-field", never, {}, {}, never, never, false, never>;
}

declare class ReadCaseLinkFieldComponent extends AbstractFieldReadComponent {
    hasReference(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadCaseLinkFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadCaseLinkFieldComponent, "ccd-read-case-link-field", never, {}, {}, never, never, false, never>;
}

declare class ReadComplexFieldComponent extends AbstractFieldReadComponent implements OnInit {
    caseFields: CaseField[];
    paletteContext: typeof PaletteContext;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadComplexFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadComplexFieldComponent, "ccd-read-complex-field", never, { "caseFields": { "alias": "caseFields"; "required": false; }; }, {}, never, never, false, never>;
}

/**
 * Display a complex type fields as a list of values without labels.
 * This is intended for rendering of Check Your Answer page.
 */
declare class ReadComplexFieldRawComponent extends AbstractFieldReadComponent {
    caseFields: CaseField[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadComplexFieldRawComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadComplexFieldRawComponent, "ccd-read-complex-field-raw", never, { "caseFields": { "alias": "caseFields"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ReadComplexFieldTableComponent extends AbstractFieldReadComponent implements OnInit {
    static readonly DUMMY_STRING_PRE = "parent_";
    static readonly DUMMY_STRING_POST = "value";
    caseFields: CaseField[];
    path: string;
    ngOnInit(): void;
    private setDummyPathForChildArrays;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadComplexFieldTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadComplexFieldTableComponent, "ccd-read-complex-field-table", never, { "caseFields": { "alias": "caseFields"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ReadComplexFieldCollectionTableComponent extends AbstractFieldReadComponent implements OnInit {
    columns: string[];
    columnsVerticalLabel: any;
    columnsHorizontalLabel: any;
    columnsAllLabels: any;
    rows: any[];
    isHidden: boolean[];
    private static isSortAscending;
    ngOnInit(): void;
    getImage(row: any): string;
    /**
     * Needs to be called before 'ccdFieldsFilter' pipe is used, as it needs a caseField value.
     */
    addCaseFieldValue(field: any, value: any): boolean;
    isNotBlank(value: string): boolean;
    addCaseReferenceValue(field: any, value: any): any;
    toCaseField(id: string, label: string, fieldType: any, value: any): CaseField;
    keepOriginalOrder: (a: any, b: any) => any;
    sortRowsByColumns(column: any): void;
    sortWidget(column: any): string;
    private populateHorizontalLabels;
    private populateLabels;
    private populateCaseFieldValuesIntoRows;
    private isVerticleDataNotEmpty;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadComplexFieldCollectionTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadComplexFieldCollectionTableComponent, "ccd-read-complex-field-collection-table", never, {}, {}, never, never, false, never>;
}

declare class CaseFlagStateService {
    formGroup: FormGroup;
    pageLocation: string;
    fieldStateToNavigate: number;
    lastPageFieldState: number;
    initialCaseFlags: any;
    resetCache(pageLocation: string): void;
    resetInitialCaseFlags(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFlagStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CaseFlagStateService>;
}

declare class ReadCaseFlagFieldComponent extends AbstractFieldReadComponent implements OnInit {
    private readonly route;
    private readonly router;
    private readonly caseFlagStateService;
    flagsData: FlagsWithFormGroupPath[];
    partyLevelCaseFlagData: FlagsWithFormGroupPath[];
    caseLevelCaseFlagData: FlagsWithFormGroupPath;
    paletteContext: typeof PaletteContext;
    flagForSummaryDisplay: FlagDetailDisplay;
    displayContextParameter: CaseFlagDisplayContextParameter;
    caseFlagsExternalUser: boolean;
    pathToFlagsFormGroup: string;
    private readonly caseLevelCaseFlagsFieldId;
    get caseFlagDisplayContextParameter(): typeof CaseFlagDisplayContextParameter;
    constructor(route: ActivatedRoute, router: Router, caseFlagStateService: CaseFlagStateService);
    ngOnInit(): void;
    private cleanupNavigationFormAdditions;
    private extractNewFlagToFlagDetailDisplayObject;
    navigateBackToForm(fieldState: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadCaseFlagFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadCaseFlagFieldComponent, "ccd-read-case-flag-field", never, {}, {}, never, never, false, never>;
}

interface ServiceOrg {
    business_are: string;
    ccd_case_types: string;
    ccd_service_name: string;
    jurisdiction: string;
    last_update?: string;
    org_unit: string;
    service_code: string;
    service_description: string;
    service_id: number;
    service_short_description: string;
    sub_business_area: string;
}

interface LovRefDataModel {
    category_key: string;
    key: string;
    value_en: string;
    value_cy: string;
    hint_text_en: string;
    hint_text_cy: string;
    lov_order: number;
    parent_category: string;
    parent_key: string;
    active_flag: string;
    child_nodes?: LovRefDataModel[];
    from?: string;
    selected?: boolean;
}
interface LovRefDataByServiceModel {
    list_of_values: LovRefDataModel[];
}
declare class CommonDataService {
    private readonly http;
    constructor(http: HttpClient);
    getRefData(url: string): Observable<LovRefDataByServiceModel>;
    getServiceOrgData(url: string): Observable<ServiceOrg[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CommonDataService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CommonDataService>;
}

interface LinkedCasesState {
    currentLinkedCasesPage: number;
    errorMessages?: ErrorMessage[];
    navigateToNextPage: boolean;
    navigateToPreviousPage?: boolean;
}

declare class LinkedCasesService {
    private readonly jurisdictionService;
    private readonly searchService;
    private static readonly CASE_NAME_MISSING_TEXT;
    caseFieldValue: any[];
    isLinkedCasesEventTrigger: boolean;
    caseDetails: CaseView;
    caseId: string;
    caseName: string;
    linkCaseReasons: LovRefDataModel[];
    linkedCases: CaseLink[];
    initialCaseLinks: CaseLink[];
    editMode: boolean;
    jurisdictionsResponse: Jurisdiction[];
    serverJurisdictionError: boolean;
    serverError: {
        id: string;
        message: string;
    };
    serverLinkedApiError: {
        id: string;
        message: string;
    };
    isServerReasonCodeError: boolean;
    caseJurisdictionID: any;
    storedCaseNumber: string;
    cameFromFinalStep: boolean;
    hasNavigatedInJourney: boolean;
    hasContinuedFromStart: boolean;
    cachedFieldValues: any;
    initialCaseLinkRefs: any[];
    casesToUnlink: any[];
    constructor(jurisdictionService: JurisdictionService, searchService: SearchService);
    groupLinkedCasesByCaseType: (arrObj: any, key: any) => any;
    constructElasticSearchQuery(caseIds: any[], size: number): ESQueryType;
    resetLinkedCaseData(): void;
    mapResponse(esSearchCasesResponse: any): any;
    searchCasesByCaseIds(searchCasesResponse: any[]): Observable<unknown[]>;
    getAllLinkedCaseInformation(): void;
    mapLookupIDToValueFromJurisdictions(fieldName: any, fieldValue: any): string;
    getCaseName(searchCasesResponse: CaseView): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkedCasesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LinkedCasesService>;
}

declare class ReadLinkedCasesFieldComponent implements OnInit, AfterViewInit {
    private readonly route;
    private readonly router;
    private readonly linkedCasesService;
    private readonly appConfig;
    private readonly commonDataService;
    caseField: CaseField;
    reasonListLoaded: boolean;
    reload: boolean;
    serverError: {
        id: string;
        message: string;
    };
    serverLinkedApiError: {
        id: string;
        message: string;
    };
    isServerReasonCodeError: boolean;
    isServerJurisdictionError: boolean;
    isServerLinkedFromError: boolean;
    isServerLinkedToError: boolean;
    constructor(route: ActivatedRoute, router: Router, linkedCasesService: LinkedCasesService, appConfig: AbstractAppConfig, commonDataService: CommonDataService);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    reloadCurrentRoute(): void;
    getFailureLinkedToNotification(evt: any): void;
    getFailureLinkedFromNotification(evt: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadLinkedCasesFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadLinkedCasesFieldComponent, "ccd-read-linked-cases-field", never, {}, {}, never, never, false, never>;
}

declare class IsCompoundPipe implements PipeTransform {
    private static readonly COMPOUND_TYPES;
    private static readonly EXCLUDE;
    transform(field: CaseField): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsCompoundPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<IsCompoundPipe, "ccdIsCompound", false>;
}

declare class WriteComplexFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    private readonly isCompoundPipe;
    private readonly formValidatorsService;
    caseFields: CaseField[];
    complexGroup: FormGroup;
    renderLabel: boolean;
    ignoreMandatory: boolean;
    complexFields: CaseField[];
    constructor(isCompoundPipe: IsCompoundPipe, formValidatorsService: FormValidatorsService);
    ngOnInit(): void;
    buildField(caseField: CaseField): CaseField;
    buildIdPrefix(field: CaseField): string;
    private addressValidatorsRequired;
    private isSmallAddressLine1;
    private isMandatory;
    private isAddressUK;
    private isTopLevelWithinCollection;
    private setupFields;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteComplexFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteComplexFieldComponent, "ccd-write-complex-type-field", never, { "caseFields": { "alias": "caseFields"; "required": false; }; "renderLabel": { "alias": "renderLabel"; "required": false; }; "ignoreMandatory": { "alias": "ignoreMandatory"; "required": false; }; }, {}, never, never, false, never>;
}

declare class WriteJudicialUserFieldComponent extends WriteComplexFieldComponent implements OnInit, OnDestroy {
    private readonly jurisdictionService;
    private readonly sessionStorageService;
    private readonly caseFlagRefDataService;
    private readonly compoundPipe;
    private readonly validatorsService;
    private readonly caseNotifier;
    readonly minSearchCharacters = 2;
    judicialUserControl: AbstractControl;
    jurisdiction: string;
    caseType: string;
    showAutocomplete: boolean;
    filteredJudicialUsers$: Observable<JudicialUserModel[]>;
    searchTerm: string;
    noResults: boolean;
    errors: ValidationErrors;
    invalidSearchTerm: boolean;
    judicialUserSelected: boolean;
    jurisdictionSubscription: Subscription;
    private notifierSubscription;
    constructor(jurisdictionService: JurisdictionService, sessionStorageService: SessionStorageService, caseFlagRefDataService: CaseFlagRefdataService, compoundPipe: IsCompoundPipe, validatorsService: FormValidatorsService, caseNotifier: CaseNotifier);
    ngOnInit(): void;
    filterJudicialUsers(searchTerm: string): Observable<JudicialUserModel[]>;
    loadJudicialUser(personalCode: string): void;
    displayJudicialUser(judicialUser?: JudicialUserModel): string | undefined;
    onSelectionChange(event: any): void;
    onBlur(event: any): void;
    setupValidation(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteJudicialUserFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteJudicialUserFieldComponent, "ccd-write-judicial-user-field", never, {}, {}, never, never, false, never>;
}

declare class FocusElementDirective implements AfterContentInit {
    private readonly el;
    private readonly renderer;
    constructor(el: ElementRef, renderer: Renderer2);
    ngAfterContentInit(): void;
    focus(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusElementDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FocusElementDirective, "[focusElement]", never, {}, {}, never, never, false, never>;
}

declare class FocusElementModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusElementModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FocusElementModule, [typeof FocusElementDirective], never, [typeof FocusElementDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FocusElementModule>;
}

declare class AddressOption {
    description: string;
    value: AddressModel;
    constructor(addressModel: AddressModel, description: string);
    private getDescription;
    private prefixWithCommaIfPresent;
    private removeInitialCommaIfPresent;
}

declare class WriteAddressFieldComponent extends AbstractFieldWriteComponent implements OnInit, OnChanges {
    private readonly isCompoundPipe;
    private readonly logger;
    writeComplexFieldComponent: WriteComplexFieldComponent;
    focusElementDirectives: QueryList<FocusElementDirective>;
    static readonly REQUIRED_ERROR_MESSAGE = "Enter a Postcode";
    static readonly INVALID_ERROR_MESSAGE = "Enter a valid Postcode";
    addressesService: AddressesService;
    addressFormGroup: FormGroup<{}>;
    postcode: FormControl;
    addressList: FormControl;
    addressOptions: AddressOption[];
    errorMessage: string;
    missingPostcode: boolean;
    noAddressSelected: boolean;
    loadingAddresses: boolean;
    constructor(addressesService: AddressesService, isCompoundPipe: IsCompoundPipe);
    ngOnInit(): void;
    findAddress(): void;
    refocusElement(): void;
    blankAddress(): void;
    isComplexWithHiddenFields(): boolean;
    shouldShowDetailFields(): boolean;
    addressSelected(): void;
    ngOnChanges(changes: SimpleChanges): void;
    buildIdPrefix(elementId: string): string;
    private setFormValue;
    private updateErrorsOnContinue;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteAddressFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteAddressFieldComponent, "ccd-write-address-field", never, {}, {}, never, never, false, never>;
}

declare class WriteOrganisationComplexFieldComponent extends AbstractFormFieldComponent {
    selectedOrg$: Observable<SimpleOrganisationModel>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteOrganisationComplexFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteOrganisationComplexFieldComponent, "ccd-write-organisation-complex-field", never, { "selectedOrg$": { "alias": "selectedOrg$"; "required": false; }; }, {}, never, never, false, never>;
}

declare class FileUploadStateService {
    uploadInProgress: boolean;
    setUploadInProgress(value: boolean): void;
    isUploadInProgress(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileUploadStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileUploadStateService>;
}

declare class WriteDocumentFieldComponent extends AbstractFieldWriteComponent implements OnInit, OnDestroy {
    private readonly appConfig;
    private readonly caseNotifier;
    private readonly documentManagement;
    dialog: MatDialog;
    private readonly fileUploadStateService;
    private readonly jurisdictionService;
    private readonly sessionStorageService;
    static readonly DOCUMENT_URL = "document_url";
    static readonly DOCUMENT_BINARY_URL = "document_binary_url";
    static readonly DOCUMENT_FILENAME = "document_filename";
    static readonly DOCUMENT_HASH = "document_hash";
    static readonly UPLOAD_TIMESTAMP = "upload_timestamp";
    static readonly UPLOAD_ERROR_FILE_REQUIRED = "File required";
    static readonly UPLOAD_ERROR_NOT_AVAILABLE = "Document upload facility is not available at the moment";
    static readonly UPLOAD_ERROR_INVALID_FORMAT = "Document format is not supported";
    static readonly UPLOAD_WAITING_FILE_STATUS = "Uploading...";
    static readonly ERROR_UPLOADING_FILE = "Error Uploading File";
    fileInput: ElementRef;
    selectedFile: File;
    valid: boolean;
    fileUploadMessages: string;
    confirmReplaceResult: string;
    clickInsideTheDocument: boolean;
    fileUploadSubscription: Subscription;
    dialogSubscription: Subscription;
    caseNotifierSubscription: Subscription;
    jurisdictionSubs: Subscription;
    private uploadedDocument;
    private dialogConfig;
    jurisdictionId: string;
    caseTypeId: string;
    caseTypeExclusions: string;
    caseId: string;
    fileSecureModeOn: boolean;
    gotFromCaseInfo: boolean;
    constructor(appConfig: AbstractAppConfig, caseNotifier: CaseNotifier, documentManagement: DocumentManagementService, dialog: MatDialog, fileUploadStateService: FileUploadStateService, jurisdictionService: JurisdictionService, sessionStorageService: SessionStorageService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    isUploadInProgress(): boolean;
    cancelUpload(): void;
    fileValidationsOnTab(): void;
    fileChangeEvent(fileInput: any, allowedRegex?: string): void;
    openFileDialog(): void;
    fileSelectEvent(): void;
    triggerReplace(): boolean;
    invalidFileFormat(): void;
    getUploadedFileName(): any;
    private resetUpload;
    private fileValidations;
    private openDialog;
    private isAMandatoryComponent;
    private displayFileUploadMessages;
    private isUpLoadingAFile;
    private validateFormUploadedDocument;
    private updateDocumentForm;
    private createDocumentFormWithValidator;
    private createDocumentForm;
    private getErrorMessage;
    private extractSecureErrorMessage;
    private buildDocumentUploadData;
    generateLogMessage(cdamEnabled: boolean): void;
    private handleDocumentUploadResult;
    private handleDocumentUploadError;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteDocumentFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteDocumentFieldComponent, "ccd-write-document-field", never, {}, {}, never, never, false, never>;
}

declare class WriteDynamicListFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    dynamicListFormControl: FormControl;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteDynamicListFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteDynamicListFieldComponent, "ccd-write-dynamic-list-field", never, {}, {}, never, never, false, never>;
}

declare class WriteDynamicRadioListFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    dynamicRadioListControl: FormControl;
    ngOnInit(): void;
    createElementId(name: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteDynamicRadioListFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteDynamicRadioListFieldComponent, "ccd-write-dynamic-radio-list-field", never, {}, {}, never, never, false, never>;
}

declare class WriteTextFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    textControl: FormControl;
    ngOnInit(): void;
    onBlur($event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteTextFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteTextFieldComponent, "ccd-write-text-field", never, {}, {}, never, never, false, never>;
}

declare class WriteDateContainerFieldComponent extends AbstractFormFieldComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteDateContainerFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteDateContainerFieldComponent, "ccd-write-date-container-field", never, {}, {}, never, never, false, never>;
}

declare class BrowserService {
    isFirefox(): boolean;
    isSafari(): boolean;
    isIEOrEdge(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<BrowserService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BrowserService>;
}

declare class WriteTextAreaFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    private readonly browserService;
    textareaControl: FormControl;
    constructor(browserService: BrowserService);
    ngOnInit(): void;
    autoGrow(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteTextAreaFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteTextAreaFieldComponent, "ccd-write-text-area-field", never, {}, {}, never, never, false, never>;
}

declare class WritePhoneUKFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    phoneUkControl: FormControl;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WritePhoneUKFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WritePhoneUKFieldComponent, "ccd-write-phone-uk-field", never, {}, {}, never, never, false, never>;
}

declare class WriteNumberFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    numberControl: FormControl;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteNumberFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteNumberFieldComponent, "ccd-write-number-field", never, {}, {}, never, never, false, never>;
}

declare class WriteEmailFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    emailControl: FormControl;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteEmailFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteEmailFieldComponent, "ccd-write-email-field", never, {}, {}, never, never, false, never>;
}

declare class WriteDateFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    dateControl: FormControl;
    ngOnInit(): void;
    isDateTime(): boolean;
    getId(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteDateFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteDateFieldComponent, "ccd-write-date-field", never, {}, {}, never, never, false, never>;
}

type CaseEditValidationError = {
    id: string;
    message: string;
    label?: string;
};

declare class CaseEditDataService {
    private details$;
    private title$;
    private formValidationErrors$;
    private editForm$;
    private isLinkedCasesJourneyAtFinalStep$;
    private eventTriggerName$;
    private triggerSubmitEvent$;
    caseDetails$: rxjs.Observable<CaseView>;
    caseTitle$: rxjs.Observable<string>;
    caseEditForm$: rxjs.Observable<FormGroup<any>>;
    caseFormValidationErrors$: rxjs.Observable<CaseEditValidationError[]>;
    caseIsLinkedCasesJourneyAtFinalStep$: rxjs.Observable<boolean>;
    caseEventTriggerName$: rxjs.Observable<string>;
    caseTriggerSubmitEvent$: rxjs.Observable<boolean>;
    constructor();
    setCaseDetails(caseDetails: CaseView): void;
    setCaseTitle(caseTitle: string): void;
    setCaseEventTriggerName(triggerName: string): void;
    setFormValidationErrors(validationErrors: any[]): void;
    setCaseEditForm(editForm: FormGroup): void;
    clearFormValidationErrors(): void;
    setLinkedCasesJourneyAtFinalStep(isAtFinalStep: boolean): void;
    addFormValidationError(validationError: CaseEditValidationError): void;
    setTriggerSubmitEvent(state: boolean): void;
}

declare class WriteCaseFlagFieldComponent extends AbstractFieldWriteJourneyComponent implements OnInit, OnDestroy, Journey {
    private readonly route;
    private readonly caseEditDataService;
    private readonly caseFlagStateService;
    private readonly rpxTranslationService;
    private readonly router;
    private readonly linkedCasesService;
    fieldState: number;
    caseFlagFieldState: typeof CaseFlagFieldState;
    errorMessages: ErrorMessage[];
    flagsData: FlagsWithFormGroupPath[];
    selectedFlag: FlagDetailDisplayWithFormGroupPath;
    caseFlagParentFormGroup: FormGroup;
    flagCommentsOptional: boolean;
    jurisdiction: string;
    caseTypeId: string;
    hmctsServiceId: string;
    isDisplayContextParameterUpdate: boolean;
    isDisplayContextParameterExternal: boolean;
    isDisplayContextParameter2Point1Enabled: boolean;
    caseTitle: string;
    caseTitleSubscription: Subscription;
    displayContextParameter: string;
    determinedLocation: FlagsWithFormGroupPath;
    private allCaseFlagStagesCompleted;
    navigatedTo: boolean;
    private readonly otherFlagTypeCode;
    private readonly selectedManageCaseLocation;
    readonly caseNameMissing = "Case name missing";
    flagTypeSubJourneyIndex: any;
    get flagType(): FlagType | null;
    get selectedFlagsLocation(): FlagsWithFormGroupPath | null;
    set selectedFlagsLocation(selectedLocation: FlagsWithFormGroupPath | null);
    constructor(route: ActivatedRoute, caseEditDataService: CaseEditDataService, caseFlagStateService: CaseFlagStateService, rpxTranslationService: RpxTranslationService, router: Router, linkedCasesService: LinkedCasesService, multipageComponentStateService: MultipageComponentStateService);
    ngOnInit(): void;
    handleBackButton(event: any): void;
    addState(data: any, url?: any): void;
    updateFlagTypeSubJourney(event: any): void;
    validateCaseFields(caseFields: any): any;
    onPageChange(): void;
    setDisplayContextParameterUpdate(displayContextParameter: string): boolean;
    setDisplayContextParameterExternal(displayContextParameter: string): boolean;
    setDisplayContextParameter2Point1Enabled(displayContextParameter: string): boolean;
    onCaseFlagStateEmitted(caseFlagState: CaseFlagState): void;
    canMoveToFinalReviewStage(caseFlagState: CaseFlagState): boolean;
    proceedToNextState(): void;
    setFlagsCaseFieldValue(): void;
    previousPage(): void;
    addFlagToCollection(): void;
    /**
     * Determines the correct location (i.e. either the internal or external instance of a `Flags` object) for a new flag,
     * according to the following:
     *
     * * Whether the user is internal or external (no effect for external users because they can access only the external
     * instance)
     * * The existence of two `Flags` objects - one internal, one external - linked by the same `groupId`;
     * * For flags of type "Other", whether "only visible to HMCTS staff" has been selected or not ("Other" defaults to
     * externally visible);
     * * For all other flag types, the value of the `externallyAvailable` attribute.
     *
     * If the user is internal then the new flag should be assigned to the external `Flags` instance if:
     * * Such an instance exists, AND
     * * The flag type is "Other" and "only visible to HMCTS staff" was not selected, OR
     * * The flag type is not "Other" and `externallyAvailable` is `true`.
     *
     * @param isInternalUser Whether the current user is internal or not
     * @param selectedFlagsLocation The currently selected location for the new flag
     * @param formValues All the values from the `caseFlagParentFormGroup`
     * @returns The correctly determined location: either the internal or external location (if one exists) where a groupId
     * is present; the original location otherwise. **Note:** If the external location is returned as undefined, this
     * indicates a configuration error
     */
    determineLocationForFlag(isInternalUser: boolean, selectedFlagsLocation: FlagsWithFormGroupPath, formValues: any): FlagsWithFormGroupPath;
    updateFlagInCollection(): void;
    isAtFinalState(): boolean;
    navigateToErrorElement(elementId: string): void;
    onFlagCommentsOptionalEmitted(_: any): void;
    populateNewFlagDetailInstance(): FlagDetail;
    moveToFinalReviewStage(): void;
    ngOnDestroy(): void;
    get manageFlagFinalState(): CaseFlagFieldState.FLAG_UPDATE | CaseFlagFieldState.FLAG_UPDATE_WELSH_TRANSLATION;
    setDisplayContextParameter(caseFields: CaseField[]): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteCaseFlagFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteCaseFlagFieldComponent, "ccd-write-case-flag-field", never, {}, {}, never, never, false, never>;
}

declare class CaseEditDataModule {
    static forRoot(): ModuleWithProviders<CaseEditDataModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEditDataModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CaseEditDataModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CaseEditDataModule>;
}

declare enum LinkedCasesPages {
    BEFORE_YOU_START = 0,
    NO_LINKED_CASES = 1,
    LINK_CASE = 2,
    UNLINK_CASE = 3,
    CHECK_YOUR_ANSWERS = 4
}
declare enum LinkedCasesErrorMessages {
    ProposedCaseWithIn = "Case can not be linked to the same case",
    CaseNumberError = "Case numbers must have 16 digits",
    ReasonSelectionError = "Select a reason why these cases should be linked",
    SomethingWrong = "Something went wrong, please try again later",
    CaseCheckAgainError = "Check the case number and try again",
    CaseSelectionError = "You need to propose at least one case",
    CaseProposedError = "This case has already been proposed",
    CasesLinkedError = "These cases are already linked",
    UnlinkCaseSelectionError = "Select a case to unlink before continuing",
    LinkCasesNavigationError = "Please select Next to link case(s)",
    UnlinkCasesNavigationError = "Please select Next to unlink case(s)",
    BackNavigationError = "Please select Back to go to the previous page",
    otherDescriptionError = "Provide a description of the reason",
    otherDescriptionMaxLengthError = "Description provided must be 100 characters or fewer"
}
declare enum LinkedCasesEventTriggers {
    LINK_CASES = "Link cases",
    MANAGE_CASE_LINKS = "Manage case links"
}
declare enum Patterns {
    CASE_REF = "((([0-9]{4})(?: |-)?)){4}"
}

declare class WriteLinkedCasesFieldComponent extends AbstractFieldWriteJourneyComponent implements OnInit, AfterViewInit, OnDestroy {
    private readonly appConfig;
    private readonly commonDataService;
    private readonly casesService;
    private readonly linkedCasesService;
    private readonly caseEditDataService;
    private readonly router;
    caseEditForm: FormGroup;
    caseDetails: CaseView;
    linkedCasesPage: number;
    linkedCasesPages: typeof LinkedCasesPages;
    linkedCasesEventTriggers: typeof LinkedCasesEventTriggers;
    linkedCases: CaseLink[];
    private subscriptions;
    constructor(appConfig: AbstractAppConfig, commonDataService: CommonDataService, casesService: CasesService, linkedCasesService: LinkedCasesService, caseEditDataService: CaseEditDataService, router: Router, multipageComponentStateService: MultipageComponentStateService);
    ngOnInit(): void;
    handleBackButton(event: any): void;
    addState(data: any, url?: any): void;
    onPageChange(): void;
    initialiseCaseDetails(caseDetails: CaseView): void;
    ngAfterViewInit(): void;
    onLinkedCasesStateEmitted(linkedCasesState: LinkedCasesState): void;
    getLinkedCaseReasons(serviceId: string): void;
    getOrgService(): void;
    proceedToNextPage(): void;
    submitLinkedCases(): void;
    isAtFinalPage(): boolean;
    getNextPage(linkedCasesState: LinkedCasesState): number;
    getLinkedCases(): void;
    ngOnDestroy(): void;
    previousPage(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteLinkedCasesFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteLinkedCasesFieldComponent, "ccd-write-linked-cases-field", never, {}, {}, never, never, false, never>;
}

declare class WriteYesNoFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    private readonly yesNoService;
    yesNoValues: string[];
    yesNoControl: FormControl;
    constructor(yesNoService: YesNoService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteYesNoFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteYesNoFieldComponent, "ccd-write-yes-no-field", never, {}, {}, never, never, false, never>;
}

declare class WriteOrganisationFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    private readonly organisationService;
    private readonly organisationConverter;
    private readonly windowService;
    private static readonly EMPTY_SIMPLE_ORG;
    private static readonly MAX_RESULT_COUNT;
    private static readonly ORGANISATION_ID;
    private static readonly ORGANISATION_NAME;
    private static readonly PRE_POPULATE_TO_USERS_ORGANISATION;
    private static readonly ORGANISATION_DETAILS;
    private static readonly YES;
    private static readonly MANDATORY;
    defaultOrg: any;
    organisationFormGroup: FormGroup;
    searchOrgTextFormControl: FormControl;
    organisationIDFormControl: FormControl;
    organisationNameFormControl: FormControl;
    organisations$: Observable<OrganisationVm[]>;
    searchOrgValue$: Observable<string>;
    simpleOrganisations$: Observable<SimpleOrganisationModel[]>;
    selectedOrg$: Observable<SimpleOrganisationModel>;
    constructor(organisationService: OrganisationService, organisationConverter: OrganisationConverter, windowService: WindowService);
    ngOnInit(): void;
    onSearchOrg(orgSearchText: string): void;
    searchOrg(organisations: OrganisationVm[], lowerOrgSearchText: string): SimpleOrganisationModel[];
    trimAll(oldText: string): string;
    selectOrg(selectedOrg: SimpleOrganisationModel): void;
    deSelectOrg(): void;
    private preSelectDefaultOrg;
    private preSelectEmptyOrg;
    private instantiateOrganisationFormGroup;
    private addOrganisationValidators;
    private searchCriteria;
    private searchWithSpace;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteOrganisationFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteOrganisationFieldComponent, "ccd-write-organisation-field", never, {}, {}, never, never, false, never>;
}

declare class WriteOrderSummaryFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    ngOnInit(): void;
    private getFeeValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteOrderSummaryFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteOrderSummaryFieldComponent, "ccd-write-order-summary-field", never, {}, {}, never, never, false, never>;
}

declare class WriteMoneyGbpFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    moneyGbpControl: FormControl;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteMoneyGbpFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteMoneyGbpFieldComponent, "ccd-write-money-gbp-field", never, {}, {}, never, never, false, never>;
}

declare class WriteMultiSelectListFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    checkboxes: FormArray;
    ngOnInit(): void;
    onCheckChange(event: any): void;
    isSelected(code: any): AbstractControl;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteMultiSelectListFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteMultiSelectListFieldComponent, "ccd-write-multi-select-list-field", never, {}, {}, never, never, false, never>;
}

declare class WriteFixedListFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    fixedListFormControl: FormControl;
    get listItems(): any[];
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteFixedListFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteFixedListFieldComponent, "ccd-write-fixed-list-field", never, {}, {}, never, never, false, never>;
}

declare class WriteFixedRadioListFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    fixedRadioListControl: FormControl;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteFixedRadioListFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteFixedRadioListFieldComponent, "ccd-write-fixed-radio-list-field", never, {}, {}, never, never, false, never>;
}

declare class WriteCaseLinkFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    caseReferenceControl: AbstractControl;
    caseLinkGroup: FormGroup;
    writeComplexFieldComponent: WriteComplexFieldComponent;
    ngOnInit(): void;
    private caseReferenceValidator;
    private validCaseReference;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteCaseLinkFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteCaseLinkFieldComponent, "ccd-write-case-link-field", never, {}, {}, never, never, false, never>;
}

type CollectionItem = {
    uid: string;
    caseField: CaseField;
    item: any;
    prefix: string;
    index: number;
    container: FormGroup;
};
declare class WriteCollectionFieldComponent extends AbstractFieldWriteComponent implements OnInit, OnDestroy {
    private readonly dialog;
    private readonly profileNotifier;
    private readonly cdRef;
    private static readonly SCROLL_OFFSET_PX;
    caseFields: CaseField[];
    formArray: FormArray;
    profile: Profile;
    profileSubscription: Subscription;
    private readonly items;
    readonly collItems: CollectionItem[];
    private collectionItemUidCounter;
    constructor(dialog: MatDialog, profileNotifier: ProfileNotifier, cdRef: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    buildCaseField(item: any, index: number, isNew?: boolean): CaseField;
    buildIdPrefix(index: number): string;
    isSearchFilter(): boolean;
    addItem(doScroll: boolean): void;
    private scrollToCollectionItem;
    private isCollectionDynamic;
    private newCaseField;
    private getContainer;
    private focusLastItem;
    private removeItem;
    trackByCollectionItem(_: number, item: CollectionItem): string;
    private createCollectionItemUid;
    private resetIds;
    itemLabel(index: number): string;
    isNotAuthorisedToCreate(): boolean;
    getCollectionPermission(field: CaseField, type: string): boolean;
    isNotAuthorisedToUpdate(index: any): boolean;
    hasUpdateAccess(role: any): boolean;
    isNotAuthorisedToDelete(index: number): boolean;
    openModal(i: number): void;
    /**
     * Applied full solution as part of EUI-3505
     */
    private getControlIdAt;
    private isCollectionOfSimpleType;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteCollectionFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteCollectionFieldComponent, "ccd-write-collection-field", never, { "caseFields": { "alias": "caseFields"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ConvertHrefToRouterService {
    private readonly router;
    private readonly hrefMarkdownLinkContent;
    constructor(router: Router);
    updateHrefLink(content: string): void;
    getHrefMarkdownLinkContent(): Observable<string>;
    callAngularRouter(hrefMarkdownLinkContent: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConvertHrefToRouterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConvertHrefToRouterService>;
}

declare class RouterHelperService {
    getUrlSegmentsFromRoot(route: ActivatedRouteSnapshot): string[];
    static ɵfac: i0.ɵɵFactoryDeclaration<RouterHelperService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RouterHelperService>;
}

declare class EventTriggerService {
    eventTriggerSource: Subject<CaseEventTrigger>;
    announceEventTrigger(eventTrigger: CaseEventTrigger): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventTriggerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EventTriggerService>;
}

declare class WizardFactoryService {
    create(eventTrigger: CaseEventTrigger): Wizard;
}

declare class CaseEditWizardGuard implements Resolve<boolean> {
    private readonly router;
    private readonly routerHelper;
    private readonly wizardFactory;
    private readonly alertService;
    private readonly eventTriggerService;
    constructor(router: Router, routerHelper: RouterHelperService, wizardFactory: WizardFactoryService, alertService: AlertService, eventTriggerService: EventTriggerService);
    resolve(route: ActivatedRouteSnapshot): Promise<boolean>;
    private processEventTrigger;
    private goToFirst;
    private goToSubmit;
    private buildState;
    private parentUrlSegments;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEditWizardGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CaseEditWizardGuard>;
}

interface Caseworker {
    firstName: string;
    lastName: string;
    idamId: string;
    email: string;
    location: Location;
    roleCategory: string;
    service?: string;
}
interface CaseworkersByService {
    service: string;
    caseworkers: Caseworker[];
}

declare class CaseworkerService {
    private readonly http;
    private readonly appConfig;
    private readonly errorService;
    constructor(http: HttpService, appConfig: AbstractAppConfig, errorService: HttpErrorService);
    getCaseworkers(serviceId: any): Observable<CaseworkersByService[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseworkerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CaseworkerService>;
}

declare class EventCompletionStateMachineService {
    private readonly abstractConfig;
    stateCheckTasksCanBeCompleted: State;
    stateCompleteEventAndTask: State;
    stateCancelEvent: State;
    stateCompleteEventNotTask: State;
    stateTaskCompletedOrCancelled: State;
    stateTaskAssignedToAnotherUser: State;
    stateTaskReassignToUser: State;
    stateTaskAssignToUser: State;
    stateTaskUnassigned: State;
    stateFinal: State;
    constructor(abstractConfig: AbstractAppConfig);
    initialiseStateMachine(context: EventCompletionStateMachineContext): StateMachine;
    startStateMachine(stateMachine: StateMachine): void;
    createStates(stateMachine: StateMachine): void;
    addTransitions(): void;
    entryActionForStateCheckTasksCanBeCompleted: (state: State, context: EventCompletionStateMachineContext) => void;
    entryActionForStateTaskCompletedOrCancelled(state: State, context: EventCompletionStateMachineContext): void;
    entryActionForStateCompleteEventAndTask: (state: State, context: EventCompletionStateMachineContext) => void;
    entryActionForStateTaskAssignedToAnotherUser(state: State, context: EventCompletionStateMachineContext): void;
    entryActionForStateTaskUnassigned(state: State, context: EventCompletionStateMachineContext): void;
    entryActionForStateFinal(state: State, context: EventCompletionStateMachineContext): void;
    addTransitionsForStateCheckTasksCanBeCompleted(): void;
    addTransitionsForStateTaskCompletedOrCancelled(): void;
    addTransitionsForStateCompleteEventAndTask(): void;
    addTransitionsForStateTaskAssignedToAnotherUser(): void;
    addTransitionsForStateTaskUnassigned(): void;
    taskPresentInSessionStorage(context: EventCompletionStateMachineContext): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventCompletionStateMachineService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EventCompletionStateMachineService>;
}

interface Judicialworker {
    title: string;
    knownAs: string;
    full_name: string;
    sidam_id: string;
    email_id: string;
}

declare class JudicialworkerService {
    private readonly http;
    private readonly appConfig;
    private readonly errorService;
    constructor(http: HttpService, appConfig: AbstractAppConfig, errorService: HttpErrorService);
    getJudicialworkers(userIds: string[], serviceId: string): Observable<Judicialworker[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<JudicialworkerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JudicialworkerService>;
}

declare class PageValidationService {
    private readonly caseFieldService;
    constructor(caseFieldService: CaseFieldService);
    getInvalidFields(page: WizardPage, editForm: FormGroup): CaseField[];
    isHidden(caseField: CaseField, editForm: FormGroup, path?: string): boolean;
    private checkDocumentField;
    private checkOptionalField;
    private checkMandatoryField;
    static ɵfac: i0.ɵɵFactoryDeclaration<PageValidationService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PageValidationService>;
}

declare class CaseFileViewFieldComponent implements OnInit, AfterViewInit, OnDestroy {
    private readonly elementRef;
    private readonly route;
    private caseFileViewService;
    private documentManagementService;
    private readonly loadingService;
    private readonly sessionStorageService;
    private readonly windowService;
    private readonly caseNotifier;
    private readonly abstractConfig;
    static readonly PARAM_CASE_ID = "cid";
    allowMoving: boolean;
    categoriesAndDocuments$: Observable<CategoriesAndDocuments>;
    categoriesAndDocumentsSubscription: Subscription;
    getCategoriesAndDocumentsError: boolean;
    currentDocument: CaseFileViewDocument | undefined;
    errorMessages: string[];
    private caseVersion;
    caseField: CaseField;
    icp_jurisdictions: string[];
    icpEnabled: boolean;
    caseId: string;
    constructor(elementRef: ElementRef, route: ActivatedRoute, caseFileViewService: CaseFileViewService, documentManagementService: DocumentManagementService, loadingService: LoadingService, sessionStorageService: SessionStorageService, windowService: WindowService, caseNotifier: CaseNotifier, abstractConfig: AbstractAppConfig);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    setMediaViewerFile(document: DocumentTreeNode): void;
    moveDocument(data: {
        document: DocumentTreeNode;
        newCategory: string;
    }): void;
    reloadPage(): void;
    resetErrorMessages(): void;
    ngOnDestroy(): void;
    isIcpEnabled(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFileViewFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseFileViewFieldComponent, "ccd-case-file-view-field", never, {}, {}, never, never, false, never>;
}

declare const MEDIA_VIEWER_LOCALSTORAGE_KEY = "media-viewer-info";
declare class CaseFileViewFolderComponent implements OnInit, OnDestroy {
    private readonly windowService;
    private readonly router;
    private readonly documentManagementService;
    private readonly dialog;
    private static readonly UNCATEGORISED_DOCUMENTS_TITLE;
    private static readonly DOCUMENT_SEARCH_FORM_CONTROL_NAME;
    private static readonly MINIMUM_SEARCH_CHARACTERS;
    categoriesAndDocuments: Observable<CategoriesAndDocuments>;
    allowMoving: boolean;
    clickedDocument: EventEmitter<DocumentTreeNode>;
    moveDocument: EventEmitter<{
        newCategory: string;
        document: DocumentTreeNode;
    }>;
    nestedTreeControl: NestedTreeControl<DocumentTreeNode>;
    nestedDataSource: DocumentTreeNode[];
    categories: CaseFileViewCategory[];
    categoriesAndDocumentsSubscription: Subscription;
    selectedNodeItem: DocumentTreeNode | undefined;
    documentFilterFormGroup: FormGroup;
    documentSearchFormControl: FormControl;
    documentTreeData: DocumentTreeNode[];
    documentFilterSubscription: Subscription;
    searchTermLength: number;
    private getChildren;
    nestedChildren: (_: number, nodeData: DocumentTreeNode) => DocumentTreeNode[];
    get documentCount(): number;
    constructor(windowService: WindowService, router: Router, documentManagementService: DocumentManagementService, dialog: MatDialog);
    collapseAll(expand: boolean): void;
    expandAll(expand: boolean): void;
    ngOnInit(): void;
    generateTreeData(categories: CaseFileViewCategory[]): DocumentTreeNode[];
    getDocuments(documents: CaseFileViewDocument[]): DocumentTreeNode[];
    getUncategorisedDocuments(uncategorisedDocuments: CaseFileViewDocument[]): DocumentTreeNode;
    filter(searchTerm: string): Observable<DocumentTreeNode[]>;
    triggerDocumentAction(actionType: 'changeFolder' | 'openInANewTab' | 'download' | 'print', documentTreeNode: DocumentTreeNode): void;
    sortDataSourceAscending(column: number): void;
    sortDataSourceDescending(column: number): void;
    updateNodeData(data: DocumentTreeNode[]): void;
    ngOnDestroy(): void;
    private openMoveDialog;
    printDocument(url: string): void;
    downloadFile(url: string, downloadFileName: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFileViewFolderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseFileViewFolderComponent, "ccd-case-file-view-folder", never, { "categoriesAndDocuments": { "alias": "categoriesAndDocuments"; "required": false; }; "allowMoving": { "alias": "allowMoving"; "required": false; }; }, { "clickedDocument": "clickedDocument"; "moveDocument": "moveDocument"; }, never, never, false, never>;
}

interface CaseFileViewOverlayMenuItem {
    actionText: string;
    iconSrc?: string;
    actionFn(): void;
}

declare class CaseFileViewFolderSortComponent implements OnInit {
    private readonly appConfig;
    isOpen: boolean;
    sortAscending: EventEmitter<number>;
    sortDescending: EventEmitter<number>;
    overlayMenuItems: CaseFileViewOverlayMenuItem[];
    constructor(appConfig: AbstractAppConfig);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFileViewFolderSortComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseFileViewFolderSortComponent, "ccd-case-file-view-folder-sort", never, {}, { "sortAscending": "sortAscending"; "sortDescending": "sortDescending"; }, never, never, false, never>;
}

declare class CaseFileViewFolderToggleComponent {
    private readonly appConfig;
    isOpen: boolean;
    expandAll: EventEmitter<boolean>;
    collapseAll: EventEmitter<boolean>;
    overlayMenuItems: CaseFileViewOverlayMenuItem[];
    constructor(appConfig: AbstractAppConfig);
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFileViewFolderToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseFileViewFolderToggleComponent, "ccd-case-file-view-folder-toggle", never, {}, { "expandAll": "expandAll"; "collapseAll": "collapseAll"; }, never, never, false, never>;
}

declare class CaseFileViewOverlayMenuComponent {
    title: string;
    menuItems: CaseFileViewOverlayMenuItem[];
    isOpen: boolean;
    isOpenChange: EventEmitter<boolean>;
    closeOverlay(): void;
    setOpen(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFileViewOverlayMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseFileViewOverlayMenuComponent, "ccd-case-file-view-overlay-menu", never, { "title": { "alias": "title"; "required": false; }; "menuItems": { "alias": "menuItems"; "required": false; }; "isOpen": { "alias": "isOpen"; "required": false; }; }, { "isOpenChange": "isOpenChange"; }, never, ["[trigger]"], false, never>;
}

declare class CaseFileViewFolderDocumentActionsComponent implements OnInit {
    isOpen: boolean;
    allowMoving: boolean;
    changeFolderAction: EventEmitter<void>;
    openInANewTabAction: EventEmitter<void>;
    downloadAction: EventEmitter<void>;
    printAction: EventEmitter<void>;
    overlayMenuItems: CaseFileViewOverlayMenuItem[];
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFileViewFolderDocumentActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseFileViewFolderDocumentActionsComponent, "ccd-case-file-view-folder-document-actions", never, { "allowMoving": { "alias": "allowMoving"; "required": false; }; }, { "changeFolderAction": "changeFolderAction"; "openInANewTabAction": "openInANewTabAction"; "downloadAction": "downloadAction"; "printAction": "printAction"; }, never, never, false, never>;
}

declare class CaseFileViewFolderSelectorComponent implements AfterViewInit {
    dialogRef: MatDialogRef<CaseFileViewFolderSelectorComponent>;
    data: {
        categories: CaseFileViewCategory[];
        document: DocumentTreeNode;
    };
    currentCategories: CaseFileViewCategory[];
    selected: string;
    constructor(dialogRef: MatDialogRef<CaseFileViewFolderSelectorComponent>, data: {
        categories: CaseFileViewCategory[];
        document: DocumentTreeNode;
    });
    ngAfterViewInit(): void;
    handleChange(evt: any): void;
    select(categoryId: string): void;
    cancel(): void;
    save(): void;
    private findPath;
    private containsDocument;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFileViewFolderSelectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseFileViewFolderSelectorComponent, "xui-case-file-view-folder-selector", never, {}, {}, never, never, false, never>;
}

declare class WriteDynamicMultiSelectListFieldComponent extends AbstractFieldWriteComponent implements OnInit {
    checkboxes: FormArray;
    dynamicListFormControl: FormControl;
    ngOnInit(): void;
    onCheckChange(event: Event): void;
    isSelected(code: string): AbstractControl;
    private getValueListItem;
    private setInitialCaseList;
    private setInitialCaseFieldValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<WriteDynamicMultiSelectListFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WriteDynamicMultiSelectListFieldComponent, "ccd-write-dynamic-multi-select-list-field", never, {}, {}, never, never, false, never>;
}

declare class ReadDynamicMultiSelectListFieldComponent extends AbstractFieldReadComponent implements OnInit {
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadDynamicMultiSelectListFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadDynamicMultiSelectListFieldComponent, "ccd-read-dynamic-multi-select-list-field", never, {}, {}, never, never, false, never>;
}

declare class CaseFlagTableComponent {
    tableCaption: string;
    flagData: FlagsWithFormGroupPath;
    firstColumnHeader: string;
    caseFlagsExternalUser: boolean;
    readonly pvpDisplayText = "POTENTIALLY VIOLENT PERSON";
    get caseFlagStatus(): typeof CaseFlagStatus;
    isPvpFlag(flagDetail: FlagDetail): boolean;
    isActivePvpFlag(flagDetail: FlagDetail): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFlagTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseFlagTableComponent, "ccd-case-flag-table", never, { "tableCaption": { "alias": "tableCaption"; "required": false; }; "flagData": { "alias": "flagData"; "required": false; }; "firstColumnHeader": { "alias": "firstColumnHeader"; "required": false; }; "caseFlagsExternalUser": { "alias": "caseFlagsExternalUser"; "required": false; }; }, {}, never, never, false, never>;
}

declare abstract class AbstractJourneyComponent implements Journey {
    protected readonly multipageComponentStateService: MultipageComponentStateService;
    journeyStartPageNumber: number;
    journeyEndPageNumber: number;
    journeyPageNumber: number;
    journeyPreviousPageNumber: number;
    journeyId: string;
    childJourney: Journey;
    constructor(multipageComponentStateService: MultipageComponentStateService);
    next(): void;
    previous(): void;
    protected previousPage(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    hasNext(): boolean;
    hasPrevious(): boolean;
    isFinished(): boolean;
    isStart(): boolean;
    getId(): string;
    onPageChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractJourneyComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AbstractJourneyComponent, never, never, { "journeyId": { "alias": "journeyId"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SelectFlagTypeComponent extends AbstractJourneyComponent implements OnInit, OnDestroy, Journey {
    private readonly caseFlagRefdataService;
    formGroup: FormGroup;
    jurisdiction: string;
    caseTypeId: string;
    hmctsServiceId: string;
    isDisplayContextParameterExternal: boolean;
    isDisplayContextParameter2Point1Enabled: boolean;
    selectedFlagsLocation: FlagsWithFormGroupPath;
    caseFlagStateEmitter: EventEmitter<CaseFlagState>;
    flagCommentsOptionalEmitter: EventEmitter<any>;
    flagTypeSubJourneyEmitter: EventEmitter<any>;
    flagTypes: FlagType[];
    errorMessages: ErrorMessage[];
    flagTypeNotSelectedErrorMessage: string;
    flagTypeErrorMessage: string;
    flagRefdata$: Subscription;
    refdataError: boolean;
    cachedPath: (FlagType | false)[];
    cachedFlagType: FlagType;
    flagTypeControlChangesSubscription: Subscription;
    caseFlagFormField: typeof CaseFlagFormFields;
    isCaseLevelFlag: boolean;
    cachedRDFlagTypes: FlagType[];
    subJourneyIndex: number;
    private readonly maxCharactersForOtherFlagType;
    private readonly otherFlagTypeCode;
    private readonly caseLevelCaseFlagsFieldId;
    get caseFlagWizardStepTitle(): typeof CaseFlagWizardStepTitle;
    constructor(caseFlagRefdataService: CaseFlagRefdataService, pageStateService: MultipageComponentStateService);
    get selectedFlagType(): FlagType | null;
    get otherFlagTypeSelected(): boolean;
    ngOnInit(): void;
    handleBackButtonSubJourney(event: Event): void;
    addState(data: number, url?: string): void;
    ngOnDestroy(): void;
    checkForExistingPath(): void;
    onNext(): void;
    private emitCaseFlagState;
    private emitFlagCommentsOptional;
    private handleFlagTypeSelection;
    private loadChildFlagTypes;
    private completeSubJourney;
    onPrevious(): void;
    identifyFlagType(_: number, flagType: FlagType): string;
    private validateForm;
    processFlagTypes(flagTypes: FlagType[]): void;
    private onRefdataError;
    next(): void;
    previous(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectFlagTypeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectFlagTypeComponent, "ccd-select-flag-type", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "jurisdiction": { "alias": "jurisdiction"; "required": false; }; "caseTypeId": { "alias": "caseTypeId"; "required": false; }; "hmctsServiceId": { "alias": "hmctsServiceId"; "required": false; }; "isDisplayContextParameterExternal": { "alias": "isDisplayContextParameterExternal"; "required": false; }; "isDisplayContextParameter2Point1Enabled": { "alias": "isDisplayContextParameter2Point1Enabled"; "required": false; }; "selectedFlagsLocation": { "alias": "selectedFlagsLocation"; "required": false; }; }, { "caseFlagStateEmitter": "caseFlagStateEmitter"; "flagCommentsOptionalEmitter": "flagCommentsOptionalEmitter"; "flagTypeSubJourneyEmitter": "flagTypeSubJourneyEmitter"; }, never, never, false, never>;
}

declare enum SearchLanguageInterpreterControlNames {
    LANGUAGE_SEARCH_TERM = "languageSearchTerm",
    MANUAL_LANGUAGE_ENTRY = "manualLanguageEntry"
}

declare class SearchLanguageInterpreterComponent extends AbstractJourneyComponent implements OnInit, Journey {
    private readonly rpxTranslationService;
    get searchLanguageInterpreterStep(): typeof SearchLanguageInterpreterStep;
    readonly SearchLanguageInterpreterControlNames: typeof SearchLanguageInterpreterControlNames;
    formGroup: FormGroup;
    flagType: FlagType;
    caseFlagStateEmitter: EventEmitter<CaseFlagState>;
    readonly minSearchCharacters = 3;
    filteredLanguages$: Observable<Language[]>;
    searchTerm: string;
    isCheckboxEnabled: boolean;
    searchLanguageInterpreterHint: SearchLanguageInterpreterStep;
    errorMessages: ErrorMessage[];
    languageNotSelectedErrorMessage: string;
    languageNotEnteredErrorMessage: string;
    languageCharLimitErrorMessage: string;
    languageEnteredInBothFieldsErrorMessage: string;
    noResults: boolean;
    private readonly languageMaxCharLimit;
    private readonly signLanguageFlagCode;
    constructor(rpxTranslationService: RpxTranslationService, multipageComponentStateService: MultipageComponentStateService);
    ngOnInit(): void;
    onNext(): void;
    onEnterLanguageManually(event: Event): void;
    displayLanguage(language?: Language): string | undefined;
    private validateLanguageEntry;
    private filterLanguages;
    next(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchLanguageInterpreterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchLanguageInterpreterComponent, "ccd-search-language-interpreter", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "flagType": { "alias": "flagType"; "required": false; }; }, { "caseFlagStateEmitter": "caseFlagStateEmitter"; }, never, never, false, never>;
}

declare class SelectFlagLocationComponent extends AbstractJourneyComponent implements OnInit, Journey {
    formGroup: FormGroup;
    flagsData: FlagsWithFormGroupPath[];
    isDisplayContextParameterExternal: boolean;
    caseFlagStateEmitter: EventEmitter<CaseFlagState>;
    flagLocationTitle: CaseFlagWizardStepTitle;
    errorMessages: ErrorMessage[];
    flagLocationNotSelectedErrorMessage: SelectFlagLocationErrorMessage;
    filteredFlagsData: FlagsWithFormGroupPath[];
    cachedLocation: string;
    caseFlagsConfigError: boolean;
    readonly selectedLocationControlName = "selectedLocation";
    readonly caseLevelFlagLabel = "Case level";
    private readonly caseLevelCaseFlagsFieldId;
    ngOnInit(): void;
    onNext(): void;
    private validateSelection;
    private onCaseFlagsConfigError;
    next(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectFlagLocationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectFlagLocationComponent, "ccd-select-flag-location", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "flagsData": { "alias": "flagsData"; "required": false; }; "isDisplayContextParameterExternal": { "alias": "isDisplayContextParameterExternal"; "required": false; }; }, { "caseFlagStateEmitter": "caseFlagStateEmitter"; }, never, never, false, never>;
}

declare class ManageCaseFlagsComponent extends AbstractJourneyComponent implements OnInit, Journey {
    private readonly sanitizer;
    formGroup: FormGroup;
    flagsData: FlagsWithFormGroupPath[];
    caseTitle: string;
    displayContextParameter: string;
    caseFlagStateEmitter: EventEmitter<CaseFlagState>;
    manageCaseFlagTitle: CaseFlagWizardStepTitle;
    errorMessages: ErrorMessage[];
    manageCaseFlagSelectedErrorMessage: SelectFlagErrorMessage;
    flagsDisplayData: FlagDetailDisplayWithFormGroupPath[];
    flags: Flags;
    noFlagsError: boolean;
    readonly selectedControlName = "selectedManageCaseLocation";
    private readonly excludedFlagStatuses;
    cachedControls: {
        [key: string]: AbstractControl;
    };
    constructor(multipageComponentStateService: MultipageComponentStateService, sanitizer: DomSanitizer);
    ngOnInit(): void;
    onFlagSelectionChange(selectedFlag: FormControl): void;
    private updateFlagDetails;
    private updateCaseFieldDetails;
    isSelected(flagDisplay: FlagDetailDisplayWithFormGroupPath): boolean;
    getFlagID(flag: FlagDetailDisplayWithFormGroupPath): string;
    mapFlagDetailForDisplay(flagDetail: FlagDetail, flagsInstance: FlagsWithFormGroupPath, originalStatusFromFG: string, originalPathToFlag: string): FlagDetailDisplayWithFormGroupPath;
    getStatusToUse(flagsInstance: FlagsWithFormGroupPath, originalPathToFlag: string, originalStatusFromFG: string, originalFlagDetail: CaseField): string;
    onNext(): void;
    setManageCaseFlagTitle(displayContextParameter: string): CaseFlagWizardStepTitle;
    private validateSelection;
    private onNoFlagsError;
    next(): void;
    reapplyCachedControls(): void;
    sanitizeHtml(content: string | null | undefined): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ManageCaseFlagsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ManageCaseFlagsComponent, "ccd-manage-case-flags", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "flagsData": { "alias": "flagsData"; "required": false; }; "caseTitle": { "alias": "caseTitle"; "required": false; }; "displayContextParameter": { "alias": "displayContextParameter"; "required": false; }; }, { "caseFlagStateEmitter": "caseFlagStateEmitter"; }, never, never, false, never>;
}

declare class UpdateFlagComponent extends AbstractJourneyComponent implements OnInit, Journey {
    private readonly rpxTranslationService;
    formGroup: FormGroup;
    displayContextParameter: string;
    caseFlagStateEmitter: EventEmitter<CaseFlagState>;
    selectedFlag: FlagDetailDisplayWithFormGroupPath;
    updateFlagTitle: string;
    errorMessages: ErrorMessage[];
    commentsNotEnteredErrorMessage: UpdateFlagErrorMessage;
    commentsCharLimitErrorMessage: UpdateFlagErrorMessage;
    statusReasonNotEnteredErrorMessage: UpdateFlagErrorMessage;
    statusReasonCharLimitErrorMessage: UpdateFlagErrorMessage;
    updateFlagStepEnum: typeof UpdateFlagStep;
    validStatusProgressions: string[];
    readonly caseFlagStatusEnum: typeof CaseFlagStatus;
    readonly caseFlagFormFields: typeof CaseFlagFormFields;
    private readonly textMaxCharLimit;
    private readonly selectedManageCaseLocation;
    private flagDetail;
    caseFlagDisplayContextParameter: typeof CaseFlagDisplayContextParameter;
    externalUserUpdate: boolean;
    internalUserUpdate: boolean;
    internalUser2Point1EnabledUpdate: boolean;
    get externallyVisibleFlag(): boolean;
    constructor(rpxTranslationService: RpxTranslationService, multipageComponentStateService: MultipageComponentStateService);
    ngOnInit(): void;
    setUpdateCaseFlagTitle(flagDetail: FlagDetail): string;
    onNext(): void;
    validateTranslationNeeded(): void;
    onMakeInactive(): void;
    private validateTextEntry;
    next(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdateFlagComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UpdateFlagComponent, "ccd-update-flag", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "displayContextParameter": { "alias": "displayContextParameter"; "required": false; }; }, { "caseFlagStateEmitter": "caseFlagStateEmitter"; }, never, never, false, never>;
}

declare class CaseFlagSummaryListComponent implements OnInit {
    private readonly rpxTranslationService;
    flagForSummaryDisplay: FlagDetailDisplay;
    displayContextParameter: string;
    changeButtonEmitter: EventEmitter<number>;
    flagDescription: string;
    flagComments: string;
    flagStatus: string;
    flagDescriptionWelsh: string;
    flagCommentsWelsh: string;
    otherDescription: string;
    otherDescriptionWelsh: string;
    flagUpdateComments: string;
    summaryListDisplayMode: CaseFlagSummaryListDisplayMode;
    addUpdateFlagHeaderText: string;
    caseFlagFieldState: typeof CaseFlagFieldState;
    displayMode: typeof CaseFlagSummaryListDisplayMode;
    flagTypeHeaderText: string;
    caseFlagCheckYourAnswersPageStep: typeof CaseFlagCheckYourAnswersPageStep;
    is2Point1Enabled: boolean;
    externalUserUpdate: boolean;
    constructor(rpxTranslationService: RpxTranslationService);
    ngOnInit(): void;
    private getFlagDescription;
    private getAddUpdateFlagHeaderText;
    private getFlagTypeHeaderText;
    private getSummaryListDisplayMode;
    private getDisplayContextParameter2Point1Enabled;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFlagSummaryListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseFlagSummaryListComponent, "ccd-case-flag-summary-list", never, { "flagForSummaryDisplay": { "alias": "flagForSummaryDisplay"; "required": false; }; "displayContextParameter": { "alias": "displayContextParameter"; "required": false; }; }, { "changeButtonEmitter": "changeButtonEmitter"; }, never, never, false, never>;
}

declare class ConfirmFlagStatusComponent extends AbstractJourneyComponent implements OnInit, Journey {
    formGroup: FormGroup;
    defaultStatus: string;
    caseFlagStateEmitter: EventEmitter<CaseFlagState>;
    confirmFlagStatusTitle: CaseFlagWizardStepTitle;
    caseFlagStatusEnum: typeof CaseFlagStatus;
    flagCreationStatuses: string[];
    errorMessages: ErrorMessage[];
    statusReasonNotEnteredErrorMessage: ConfirmStatusErrorMessage;
    statusReasonCharLimitErrorMessage: ConfirmStatusErrorMessage;
    statusReasonHint: ConfirmStatusStep;
    statusReasonCharLimitInfo: ConfirmStatusStep;
    readonly selectedStatusControlName = "selectedStatus";
    readonly statusReasonControlName = "statusReason";
    private readonly reasonMaxCharLimit;
    ngOnInit(): void;
    onNext(): void;
    next(): void;
    private validateTextEntry;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmFlagStatusComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmFlagStatusComponent, "ccd-confirm-flag-status", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "defaultStatus": { "alias": "defaultStatus"; "required": false; }; }, { "caseFlagStateEmitter": "caseFlagStateEmitter"; }, never, never, false, never>;
}

declare class UpdateFlagAddTranslationFormComponent extends AbstractJourneyComponent implements OnInit, Journey {
    formGroup: FormGroup;
    caseFlagStateEmitter: EventEmitter<CaseFlagState>;
    selectedFlag: FlagDetailDisplayWithFormGroupPath;
    updateFlagAddTranslationTitle: CaseFlagWizardStepTitle;
    errorMessages: ErrorMessage[];
    otherFlagDescriptionCharLimitErrorMessage: UpdateFlagAddTranslationErrorMessage;
    otherFlagDescriptionWelshCharLimitErrorMessage: UpdateFlagAddTranslationErrorMessage;
    flagCommentsCharLimitErrorMessage: UpdateFlagAddTranslationErrorMessage;
    flagCommentsWelshCharLimitErrorMessage: UpdateFlagAddTranslationErrorMessage;
    updateFlagAddTranslationStepEnum: typeof UpdateFlagAddTranslationStep;
    readonly caseFlagFormFields: typeof CaseFlagFormFields;
    private readonly textMaxCharLimit;
    private readonly selectedManageCaseLocation;
    ngOnInit(): void;
    ngOnDestroy(): void;
    onNext(): void;
    private validateTextEntry;
    next(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UpdateFlagAddTranslationFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UpdateFlagAddTranslationFormComponent, "ccd-update-flag-add-translation-form", never, { "formGroup": { "alias": "formGroup"; "required": false; }; }, { "caseFlagStateEmitter": "caseFlagStateEmitter"; }, never, never, false, never>;
}

interface LinkedCasesResponse {
    caseReference: string;
    caseName: string;
    caseType: string;
    caseTypeDescription: string;
    service: string;
    state: string;
    stateDescription: string;
    reasons: string[];
}
declare class LinkedCasesToTableComponent implements OnInit, AfterViewInit {
    private readonly route;
    private readonly linkedCasesService;
    private readonly casesService;
    private static readonly CASE_CONSOLIDATED_REASON_CODE;
    private static readonly CASE_PROGRESS_REASON_CODE;
    caseField: CaseField;
    notifyAPIFailure: EventEmitter<boolean>;
    caseDetails: CaseView;
    isLoaded: boolean;
    linkedCasesFromResponse: LinkedCasesResponse[];
    caseId: string;
    isServerError: boolean;
    isServerReasonCodeError: boolean;
    jurisdictionsResponse: Jurisdiction[];
    constructor(route: ActivatedRoute, linkedCasesService: LinkedCasesService, casesService: CasesService);
    ngAfterViewInit(): void;
    ngOnInit(): void;
    getCaseRefereneLink(caseRef: string): string;
    sortLinkedCasesByReasonCode(searchCasesResponse: any): LinkedCasesResponse[];
    getAllLinkedCaseInformation(): void;
    sortReasonCodes(searchCasesResponse: any): LinkedCasesResponse[];
    getReasonSortOrder(reasonCode: string): number;
    searchCasesByCaseIds(searchCasesResponse: any[]): Observable<unknown[]>;
    hasLeadCaseOrConsolidated(reasonCode: string): boolean;
    mapResponse(esSearchCasesResponse: any): LinkedCasesResponse;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkedCasesToTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkedCasesToTableComponent, "ccd-linked-cases-to-table", never, { "caseField": { "alias": "caseField"; "required": false; }; }, { "notifyAPIFailure": "notifyAPIFailure"; }, never, never, false, never>;
}

declare class LinkedCasesFromTableComponent implements OnInit, AfterViewInit {
    private readonly route;
    private readonly casesService;
    private readonly linkedCasesService;
    private static readonly CASE_NAME_MISSING_TEXT;
    private static readonly CASE_CONSOLIDATED_REASON_CODE;
    private static readonly CASE_PROGRESS_REASON_CODE;
    caseField: CaseField;
    notifyAPIFailure: EventEmitter<boolean>;
    caseDetails: CaseView;
    parentUrl: string;
    isLoaded: boolean;
    getLinkedCasesResponse: CaseLinkResponse[];
    linkedCaseReasons: LovRefDataModel[];
    caseId: string;
    showHideLinkText: string;
    noLinkedCases: boolean;
    isServerError: boolean;
    isServerReasonCodeError: boolean;
    constructor(route: ActivatedRoute, casesService: CasesService, linkedCasesService: LinkedCasesService);
    ngAfterViewInit(): void;
    ngOnInit(): void;
    fetchPageData(): void;
    getLinkedCases(): Observable<LinkedCasesResponse$1>;
    mapLookupIDToValueFromJurisdictions(fieldName: any, fieldValue: any): string;
    getCaseReferenceLink(caseRef: string): string;
    hasLeadCaseOrConsolidated(reasonCode: string): boolean;
    onClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkedCasesFromTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkedCasesFromTableComponent, "ccd-linked-cases-from-table", never, { "caseField": { "alias": "caseField"; "required": false; }; }, { "notifyAPIFailure": "notifyAPIFailure"; }, never, never, false, never>;
}

declare class BeforeYouStartComponent extends AbstractJourneyComponent implements Journey {
    private readonly router;
    private readonly linkedCasesService;
    linkedCasesStateEmitter: EventEmitter<LinkedCasesState>;
    isLinkCasesJourney: boolean;
    errorMessages: ErrorMessage[];
    serverLinkedApiError: {
        id: string;
        message: string;
    };
    constructor(router: Router, linkedCasesService: LinkedCasesService, multipageComponentStateService: MultipageComponentStateService);
    next(): void;
    onBack(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BeforeYouStartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BeforeYouStartComponent, "ccd-linked-cases-before-you-start", never, {}, { "linkedCasesStateEmitter": "linkedCasesStateEmitter"; }, never, never, false, never>;
}

declare class ValidatorsUtils {
    numberLengthValidator(inputLength: number): ValidatorFn;
    formArraySelectedValidator(): ValidatorFn;
    regexPattern(regexPattern: string): ValidatorFn;
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidatorsUtils, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ValidatorsUtils>;
}

declare class LinkCasesComponent extends AbstractJourneyComponent implements OnInit, Journey {
    private readonly casesService;
    private readonly fb;
    private readonly validatorsUtils;
    private readonly linkedCasesService;
    linkedCasesStateEmitter: EventEmitter<LinkedCasesState>;
    errorMessages: ErrorMessage[];
    linkCaseForm: FormGroup;
    selectedCases: CaseLink[];
    caseNumberError: string;
    caseReasonError: string;
    caseReasonCommentsError: string;
    caseSelectionError: string;
    noSelectedCaseError: string;
    caseId: string;
    caseName: string;
    linkCaseReasons: LovRefDataModel[];
    showComments: boolean;
    private readonly ISO_FORMAT;
    constructor(casesService: CasesService, fb: FormBuilder, validatorsUtils: ValidatorsUtils, linkedCasesService: LinkedCasesService, multipageComponentStateService: MultipageComponentStateService);
    ngOnInit(): void;
    initForm(): void;
    get getReasonTypeFormArray(): FormArray;
    toggleLinkCaseReasonOtherComments(event: any): void;
    submitCaseInfo(): void;
    isCaseSelected(linkedCases: CaseLink[]): boolean;
    isCaseInInitial(proposedCaseLink: string): boolean;
    private isCaseSelectedSameAsCurrentCase;
    private isOtherOptionSelectedButOtherDescriptionNotEntered;
    showErrorInfo(): void;
    getCaseInfo(): void;
    emitLinkedCasesState(isNavigateToNextPage: boolean): void;
    getSelectedCaseReasons(): LinkReason[];
    getSelectedCCDTypeCaseReason(): LinkReason[];
    onSelectedLinkedCaseRemove(pos: any, selectedCaseReference: any): void;
    onNext(): void;
    ngOnDestroy(): void;
    next(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkCasesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LinkCasesComponent, "ccd-link-cases", never, {}, { "linkedCasesStateEmitter": "linkedCasesStateEmitter"; }, never, never, false, never>;
}

declare class CheckYourAnswersComponent extends AbstractJourneyComponent implements OnInit, Journey {
    private readonly linkedCasesService;
    linkedCasesStateEmitter: EventEmitter<LinkedCasesState>;
    linkedCases: CaseLink[];
    casesToUnlink: CaseLink[];
    isLinkCasesJourney: boolean;
    linkedCasesTableCaption: string;
    constructor(linkedCasesService: LinkedCasesService, multipageComponentStateService: MultipageComponentStateService);
    ngOnInit(): void;
    ensureDataIntegrity(): void;
    onChange(): void;
    next(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckYourAnswersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckYourAnswersComponent, "ccd-linked-cases-check-your-answers", never, {}, { "linkedCasesStateEmitter": "linkedCasesStateEmitter"; }, never, never, false, never>;
}

declare class UnLinkCasesComponent extends AbstractFieldWriteJourneyComponent implements OnInit, Journey {
    private readonly fb;
    private readonly casesService;
    private readonly linkedCasesService;
    private static readonly LINKED_CASES_TAB_ID;
    private static readonly CASE_NAME_MISSING_TEXT;
    private static readonly LINKED_CASES_TAB_ID_2;
    linkedCasesStateEmitter: EventEmitter<LinkedCasesState>;
    notifyAPIFailure: EventEmitter<boolean>;
    unlinkCaseForm: FormGroup;
    caseId: string;
    linkedCases: CaseLink[];
    errorMessages: ErrorMessage[];
    unlinkErrorMessage: string;
    isLoaded: boolean;
    isServerError: boolean;
    constructor(fb: FormBuilder, casesService: CasesService, linkedCasesService: LinkedCasesService, multipageComponentStateService: MultipageComponentStateService);
    ngOnInit(): void;
    getJourneyCollection(): Journey;
    getLinkedCases(): void;
    getLinkedCaseId(linkedCase: any): string;
    getAllLinkedCaseInformation(): void;
    searchCasesByCaseIds(searchCasesResponse: any[]): Observable<unknown[]>;
    initForm(): void;
    get getLinkedCasesFormArray(): FormArray;
    onChange(caseSelected: any): void;
    onNext(): void;
    next(): void;
    emitLinkedCasesState(isNavigateToNextPage: boolean): void;
    resetErrorMessages(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<UnLinkCasesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<UnLinkCasesComponent, "ccd-unlink-cases", never, {}, { "linkedCasesStateEmitter": "linkedCasesStateEmitter"; "notifyAPIFailure": "notifyAPIFailure"; }, never, never, false, never>;
}

declare class NoLinkedCasesComponent extends AbstractJourneyComponent implements OnInit, Journey {
    private readonly router;
    private readonly linkedCasesService;
    serverLinkedApiError: {
        id: string;
        message: string;
    };
    constructor(router: Router, linkedCasesService: LinkedCasesService, multipageComponentStateService: MultipageComponentStateService);
    ngOnInit(): void;
    onBack(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<NoLinkedCasesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NoLinkedCasesComponent, "ccd-no-linked-cases", never, {}, {}, never, never, false, never>;
}

interface QueryMessageDocument {
    id: string;
    value: FormDocument;
}
interface CaseMessage {
    id: string;
    subject?: string;
    name: string;
    body: string;
    attachments?: QueryMessageDocument[];
    isHearingRelated: string;
    hearingDate?: string;
    createdOn: Date;
    createdBy: string;
    parentId?: string;
    isClosed?: string;
    messageType?: string;
    isHmctsStaff?: string;
}
interface QueryMessage {
    id: string;
    value: CaseMessage;
}
interface CaseQueriesCollection {
    partyName: string;
    roleOnCase: string;
    caseMessages: QueryMessage[];
}
interface QmCaseQueriesCollection {
    [key: string]: CaseQueriesCollection;
}

interface QualifyingQuestion {
    name: string;
    markdown: string;
    url: string;
}

type CaseTypeQualifyingQuestions = {
    [caseTypeId: string]: QualifyingQuestion[];
};

declare enum QueryCreateContext {
    NEW_QUERY_QUALIFYING_QUESTION_OPTIONS = "NewQueryQualifyingQuestionOptions",
    NEW_QUERY_QUALIFYING_QUESTION_DETAIL = "NewQueryQualifyingQuestionDetail",
    NEW_QUERY = "NewQuery",
    RESPOND = "Respond",
    FOLLOWUP = "Followup",
    HMCTSSTAFF = "HMCTS"
}

declare enum SortOrder {
    ASCENDING = 0,
    DESCENDING = 1,
    UNSORTED = 2
}

interface QueryListColumn {
    name: string;
    displayName: string;
    sortOrder: SortOrder;
}

declare enum QueryItemResponseStatus {
    NEW = "New",
    RESPONDED = "Responded",
    AWAITING = "Awaiting Response",
    CLOSED = "Closed"
}

declare class QueryListItem implements CaseMessage {
    id: string;
    subject?: string;
    name: string;
    body: string;
    attachments?: QueryMessageDocument[];
    isHearingRelated: string;
    hearingDate?: string;
    createdOn: Date;
    createdBy: string;
    parentId?: string;
    isClosed?: string;
    messageType?: string;
    isHmctsStaff?: string;
    children: QueryListItem[];
    messageIndexInParent?: number | null;
    get lastSubmittedMessage(): QueryListItem;
    get lastSubmittedBy(): string;
    get lastSubmittedDate(): Date;
    get lastResponseBy(): string;
    get lastResponseDate(): Date | null;
    get responseStatus(): QueryItemResponseStatus;
}

declare class QueryListData {
    partyName: string;
    roleOnCase: string;
    queries: QueryListItem[];
    constructor(caseQueriesCollection: CaseQueriesCollection);
    private buildQueryListItem;
}

declare class ReadQueryManagementFieldComponent extends AbstractFieldReadComponent implements OnInit, OnDestroy {
    private readonly route;
    private sessionStorageService;
    private readonly caseNotifier;
    private readonly abstractConfig;
    caseQueriesCollections: CaseQueriesCollection[];
    query: QueryListItem;
    showQueryList: boolean;
    caseId: string;
    messageType: string;
    followUpQuery: string;
    respondToQuery: string;
    isQueryClosed: boolean;
    value: boolean;
    isMultipleFollowUpEnabled: boolean;
    currentJurisdictionId: string;
    enableServiceSpecificMultiFollowups: string[];
    private caseSubscription;
    constructor(route: ActivatedRoute, sessionStorageService: SessionStorageService, caseNotifier: CaseNotifier, abstractConfig: AbstractAppConfig);
    ngOnInit(): void;
    ngOnDestroy(): void;
    setQuery(query: any): void;
    backToQueryListPage(): void;
    isInternalUser(): boolean;
    isJudiciaryUser(): boolean;
    getMessageType(query: any): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadQueryManagementFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReadQueryManagementFieldComponent, "ccd-read-query-management-field", never, {}, {}, never, never, false, never>;
}

declare class QueryDetailsComponent implements OnChanges, OnInit, OnDestroy {
    private readonly sessionStorageService;
    private readonly route;
    private readonly router;
    private readonly abstractConfig;
    private readonly caseNotifier;
    query: QueryListItem;
    caseId: string;
    queryResponseStatus: string;
    backClicked: EventEmitter<boolean>;
    hasResponded: EventEmitter<boolean>;
    showItem: boolean;
    private static readonly QUERY_ITEM_RESPOND;
    private static readonly QUERY_ITEM_FOLLOW_UP;
    private queryItemId;
    followUpQuery: string;
    respondToQuery: string;
    hmctsStaff: string;
    enableServiceSpecificMultiFollowups: string[];
    currentJurisdictionId: string;
    isMultipleFollowUpEnabled: boolean;
    private caseSubscription;
    constructor(sessionStorageService: SessionStorageService, route: ActivatedRoute, router: Router, abstractConfig: AbstractAppConfig, caseNotifier: CaseNotifier);
    onBack(): void;
    isInternalUser(): boolean;
    ngOnInit(): void;
    ngOnChanges(): void;
    ngOnDestroy(): void;
    toggleLinkVisibility(): void;
    hasRespondedToQuery(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryDetailsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QueryDetailsComponent, "ccd-query-details", never, { "query": { "alias": "query"; "required": false; }; "caseId": { "alias": "caseId"; "required": false; }; "queryResponseStatus": { "alias": "queryResponseStatus"; "required": false; }; }, { "backClicked": "backClicked"; "hasResponded": "hasResponded"; }, never, never, false, never>;
}

declare class QueryListComponent implements OnChanges {
    caseQueriesCollection: CaseQueriesCollection;
    selectedQuery: EventEmitter<QueryListItem>;
    queryListData: QueryListData | undefined;
    displayedColumns: QueryListColumn[];
    hmctsStaff: string;
    ngOnChanges(simpleChanges: SimpleChanges): void;
    sortTable(col: QueryListColumn): void;
    getAriaSortHeaderValue(col: QueryListColumn): 'ascending' | 'descending' | 'none';
    showDetails(query: any): void;
    private sort;
    private sortDate;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QueryListComponent, "ccd-query-list", never, { "caseQueriesCollection": { "alias": "caseQueriesCollection"; "required": false; }; }, { "selectedQuery": "selectedQuery"; }, never, never, false, never>;
}

declare enum RaiseQueryErrorMessage {
    FULL_NAME = "Enter a full name",
    QUERY_SUBJECT = "Enter a query subject",
    QUERY_BODY = "Enter query details",
    QUERY_HEARING_RELATED = "Select whether the query is hearing related or not",
    QUERY_HEARING_DATE = "Enter a valid date",
    QUERY_SUBJECT_MAX_LENGTH = "Query subject must be less than 201 characters in length",
    RESPOND_QUERY_BODY = "Add a response before continue"
}

declare enum RespondToQueryErrorMessages {
    FULL_NAME = "Enter a full name",
    QUERY_BODY = "Add a response before continue"
}

declare enum QualifyingQuestionsErrorMessage {
    SELECT_AN_OPTION = "Select an option"
}

declare class QualifyingQuestionService {
    private qualifyingQuestionSelection;
    setQualifyingQuestionSelection(selection: QualifyingQuestion): void;
    getQualifyingQuestionSelection(): QualifyingQuestion | null;
    clearQualifyingQuestionSelection(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QualifyingQuestionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QualifyingQuestionService>;
}

declare class QueryManagementService {
    private readonly router;
    private readonly sessionStorageService;
    private readonly logger;
    caseQueriesCollections: CaseQueriesCollection[];
    fieldId: string;
    constructor(router: Router, sessionStorageService: SessionStorageService);
    isInternalUser(): boolean;
    isJudiciaryUser(): boolean;
    generateCaseQueriesCollectionData(formGroup: FormGroup, queryCreateContext: QueryCreateContext, queryItem: QueryListItem, messageId?: string): QmCaseQueriesCollection;
    setCaseQueriesCollectionData(eventData: CaseEventTrigger, queryCreateContext: QueryCreateContext, caseDetails: CaseView, messageId?: string): void;
    private resolveFieldId;
    private getCaseQueriesCollectionFieldOrderFromWizardPages;
    private getCollectionSelectionMethod;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryManagementService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<QueryManagementService>;
}

declare class QueryWriteRespondToQueryComponent implements OnInit, OnChanges {
    private readonly caseNotifier;
    private readonly route;
    private queryManagementService;
    private readonly logger;
    queryItem: QueryListItem;
    formGroup: FormGroup;
    queryCreateContext: QueryCreateContext;
    submitted: boolean;
    caseQueriesCollections: CaseQueriesCollection[];
    showForm: any;
    triggerSubmission: boolean;
    eventData: CaseEventTrigger | null;
    queryDataCreated: EventEmitter<QmCaseQueriesCollection>;
    hasRespondedToQueryTask: EventEmitter<boolean>;
    readonly queryCreateContextEnum: typeof QueryCreateContext;
    readonly raiseQueryErrorMessages: typeof RaiseQueryErrorMessage;
    caseId: string;
    queryItemId: string;
    caseDetails: any;
    queryResponseStatus: string;
    queryListData: QueryListItem | undefined;
    hasRespondedToQuery: boolean;
    messageId: string;
    private static readonly QUERY_ITEM_RESPOND;
    private static readonly QUERY_ITEM_FOLLOWUP;
    constructor(caseNotifier: CaseNotifier, route: ActivatedRoute, queryManagementService: QueryManagementService);
    ngOnInit(): void;
    ngOnChanges(): void;
    hasResponded(value: boolean): void;
    setCaseQueriesCollectionData(): boolean;
    private generateCaseQueriesCollectionData;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryWriteRespondToQueryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QueryWriteRespondToQueryComponent, "ccd-query-write-respond-to-query", never, { "queryItem": { "alias": "queryItem"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "queryCreateContext": { "alias": "queryCreateContext"; "required": false; }; "submitted": { "alias": "submitted"; "required": false; }; "caseQueriesCollections": { "alias": "caseQueriesCollections"; "required": false; }; "showForm": { "alias": "showForm"; "required": false; }; "triggerSubmission": { "alias": "triggerSubmission"; "required": false; }; "eventData": { "alias": "eventData"; "required": false; }; }, { "queryDataCreated": "queryDataCreated"; "hasRespondedToQueryTask": "hasRespondedToQueryTask"; }, never, never, false, never>;
}

interface EventCompletionParams {
    caseId: string;
    eventId: string;
    task: Task;
}

declare class QueryWriteRaiseQueryComponent implements OnChanges {
    private queryManagementService;
    private readonly route;
    private readonly logger;
    formGroup: FormGroup;
    submitted: boolean;
    caseDetails: CaseView;
    showForm: boolean;
    serviceMessage: string | null;
    queryCreateContext: QueryCreateContext;
    eventData: CaseEventTrigger | null;
    queryItem: QueryListItem;
    validate: (caseEventData: CaseEventData, pageId: string) => Observable<object>;
    triggerSubmission: boolean;
    queryDataCreated: EventEmitter<QmCaseQueriesCollection>;
    raiseQueryErrorMessage: typeof RaiseQueryErrorMessage;
    eventCompletionParams: EventCompletionParams;
    messageId: string;
    constructor(queryManagementService: QueryManagementService, route: ActivatedRoute);
    ngOnChanges(): void;
    onSubjectInput(): void;
    getSubjectErrorMessage(): string;
    setCaseQueriesCollectionData(): boolean;
    private generateCaseQueriesCollectionData;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryWriteRaiseQueryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QueryWriteRaiseQueryComponent, "ccd-query-write-raise-query", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "submitted": { "alias": "submitted"; "required": false; }; "caseDetails": { "alias": "caseDetails"; "required": false; }; "showForm": { "alias": "showForm"; "required": false; }; "serviceMessage": { "alias": "serviceMessage"; "required": false; }; "queryCreateContext": { "alias": "queryCreateContext"; "required": false; }; "eventData": { "alias": "eventData"; "required": false; }; "queryItem": { "alias": "queryItem"; "required": false; }; "validate": { "alias": "validate"; "required": false; }; "triggerSubmission": { "alias": "triggerSubmission"; "required": false; }; }, { "queryDataCreated": "queryDataCreated"; }, never, never, false, never>;
}

declare class QueryCaseDetailsHeaderComponent implements OnInit {
    caseDetails: CaseView;
    caseTitle: CaseField;
    caseFields: CaseField[];
    ngOnInit(): void;
    private getCaseFieldsInfo;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryCaseDetailsHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QueryCaseDetailsHeaderComponent, "ccd-query-case-details-header", never, { "caseDetails": { "alias": "caseDetails"; "required": false; }; }, {}, never, never, false, never>;
}

declare class QueryCheckYourAnswersComponent implements OnInit, OnDestroy {
    private readonly route;
    private readonly router;
    private readonly casesService;
    private readonly caseNotifier;
    private readonly workAllocationService;
    private readonly qualifyingQuestionService;
    private queryManagementService;
    private readonly errorNotifierService;
    private readonly alertService;
    private readonly logger;
    private readonly RAISE_A_QUERY_EVENT_TRIGGER_ID;
    private readonly RESPOND_TO_QUERY_EVENT_TRIGGER_ID;
    private readonly CASE_QUERIES_COLLECTION_ID;
    static readonly TRIGGER_TEXT_CONTINUE = "Ignore Warning and Continue";
    static readonly TRIGGER_TEXT_START = "Continue";
    readonly FIELD_TYPE_COMPLEX = "Complex";
    readonly DISPLAY_CONTEXT_READONLY = "READONLY";
    readonly QM_SELECT_FIRST_COLLECTION = "selectFirstCollection";
    readonly QM_COLLECTION_PROMPT = "promptQmCollection";
    readonly CIVIL_JURISDICTION = "CIVIL";
    triggerTextStart: string;
    triggerTextIgnoreWarnings: string;
    formGroup: FormGroup;
    queryItem: QueryListItem;
    queryCreateContext: QueryCreateContext;
    eventData: CaseEventTrigger | null;
    multipleFollowUpFeature: boolean;
    qmCaseQueriesCollectionData: QmCaseQueriesCollection;
    backClicked: EventEmitter<boolean>;
    querySubmitted: EventEmitter<boolean>;
    callbackConfirmationMessage: EventEmitter<{
        [key: string]: string;
    }>;
    createEventResponse: EventEmitter<CaseQueriesCollection>;
    private caseViewTrigger;
    caseDetails: CaseView;
    private queryId;
    private tid;
    private createEventSubscription;
    private searchTasksSubscription;
    queryCreateContextEnum: typeof QueryCreateContext;
    eventCompletionParams: EventCompletionParams;
    caseQueriesCollections: CaseQueriesCollection[];
    fieldId: string;
    attachments: FormDocument[];
    errorMessages: ErrorMessage[];
    filteredTasks: Task[];
    readyToSubmit: boolean;
    isSubmitting: boolean;
    messageId: string;
    callbackErrorsSubject: Subject<any>;
    error: any;
    constructor(route: ActivatedRoute, router: Router, casesService: CasesService, caseNotifier: CaseNotifier, workAllocationService: WorkAllocationService, qualifyingQuestionService: QualifyingQuestionService, queryManagementService: QueryManagementService, errorNotifierService: ErrorNotifierService, alertService: AlertService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    goBack(): void;
    submit(): void;
    private createEvent;
    private finaliseSubmission;
    private handleError;
    private getDocumentAttachments;
    isServiceErrorFound(error: any): boolean;
    setCaseQueriesCollectionData(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryCheckYourAnswersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QueryCheckYourAnswersComponent, "ccd-query-check-your-answers", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "queryItem": { "alias": "queryItem"; "required": false; }; "queryCreateContext": { "alias": "queryCreateContext"; "required": false; }; "eventData": { "alias": "eventData"; "required": false; }; "multipleFollowUpFeature": { "alias": "multipleFollowUpFeature"; "required": false; }; "qmCaseQueriesCollectionData": { "alias": "qmCaseQueriesCollectionData"; "required": false; }; }, { "backClicked": "backClicked"; "querySubmitted": "querySubmitted"; "callbackConfirmationMessage": "callbackConfirmationMessage"; "createEventResponse": "createEventResponse"; }, never, never, false, never>;
}

declare class QueryWriteAddDocumentsComponent implements OnInit, AfterViewInit, OnDestroy {
    static DOCUMENTS_FORM_CONTROL_NAME: string;
    formGroup: FormGroup;
    label: string;
    hintText: string;
    documentFormGroup: FormGroup<{}>;
    mockDocumentCaseField: CaseField;
    private documentFormControlSubscription;
    documentCollectionUpdate: EventEmitter<FormDocument[]>;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryWriteAddDocumentsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QueryWriteAddDocumentsComponent, "ccd-query-write-add-documents", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "label": { "alias": "label"; "required": false; }; "hintText": { "alias": "hintText"; "required": false; }; }, { "documentCollectionUpdate": "documentCollectionUpdate"; }, never, never, false, never>;
}

declare class QueryWriteDateInputComponent implements ControlValueAccessor {
    formControlName: string;
    day: number;
    month: number;
    year: number;
    disabled: boolean;
    private onChange;
    private onTouched;
    writeValue(date: Date): void;
    registerOnChange(fn: (value: Date) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    updateDate(): void;
    private isValidDateInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryWriteDateInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QueryWriteDateInputComponent, "ccd-query-write-date-input", never, { "formControlName": { "alias": "formControlName"; "required": false; }; }, {}, never, never, false, never>;
}

declare class QualifyingQuestionOptionsComponent implements OnInit {
    private readonly route;
    private readonly router;
    private readonly qualifyingQuestionService;
    qualifyingQuestionsControl: FormControl;
    qualifyingQuestions$: Observable<QualifyingQuestion[]>;
    questionSelected: EventEmitter<QualifyingQuestion>;
    qualifyingQuestionsErrorMessage: typeof QualifyingQuestionsErrorMessage;
    caseId: string;
    jurisdiction: string;
    caseType: string;
    constructor(route: ActivatedRoute, router: Router, qualifyingQuestionService: QualifyingQuestionService);
    ngOnInit(): void;
    click(): void;
    get displayError(): boolean;
    onSelectionChange(qualifyingQuestion: QualifyingQuestion): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QualifyingQuestionOptionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QualifyingQuestionOptionsComponent, "ccd-qualifying-question-options", never, { "qualifyingQuestionsControl": { "alias": "qualifyingQuestionsControl"; "required": false; }; "qualifyingQuestions$": { "alias": "qualifyingQuestions$"; "required": false; }; }, { "questionSelected": "questionSelected"; }, never, never, false, never>;
}

declare class QualifyingQuestionDetailComponent {
    qualifyingQuestion: QualifyingQuestion;
    static ɵfac: i0.ɵɵFactoryDeclaration<QualifyingQuestionDetailComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QualifyingQuestionDetailComponent, "ccd-qualifying-question-detail", never, { "qualifyingQuestion": { "alias": "qualifyingQuestion"; "required": false; }; }, {}, never, never, false, never>;
}

declare class QueryAttachmentsReadComponent implements OnChanges {
    attachments: FormDocument[];
    caseFieldWithAttachments: CaseField;
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryAttachmentsReadComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QueryAttachmentsReadComponent, "ccd-query-attachments-read", never, { "attachments": { "alias": "attachments"; "required": false; }; }, {}, never, never, false, never>;
}

declare class QueryEventCompletionComponent {
    eventCompletionParams: EventCompletionParams;
    onEventCanBeCompleted(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryEventCompletionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QueryEventCompletionComponent, "ccd-query-event-completion", never, { "eventCompletionParams": { "alias": "eventCompletionParams"; "required": false; }; }, {}, never, never, false, never>;
}

declare class QueryConfirmationComponent implements OnInit {
    private readonly route;
    private readonly sessionStorageService;
    private readonly logger;
    queryCreateContext: QueryCreateContext;
    callbackConfirmationMessageText: {
        [key: string]: string;
    };
    eventResponseData: CaseQueriesCollection;
    caseId: string;
    jurisdiction: string;
    caseType: string;
    queryCreateContextEnum: typeof QueryCreateContext;
    isHmctsStaffRaisedQuery: string;
    isHmctsStaff: string;
    queryListData: QueryListData | undefined;
    constructor(route: ActivatedRoute, sessionStorageService: SessionStorageService);
    ngOnInit(): void;
    isInternalUser(): boolean;
    isJudiciaryUser(): boolean;
    resolveHmctsStaffRaisedQuery(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<QueryConfirmationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<QueryConfirmationComponent, "ccd-query-confirmation", never, { "queryCreateContext": { "alias": "queryCreateContext"; "required": false; }; "callbackConfirmationMessageText": { "alias": "callbackConfirmationMessageText"; "required": false; }; "eventResponseData": { "alias": "eventResponseData"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CloseQueryComponent {
    formGroup: FormGroup;
    static ɵfac: i0.ɵɵFactoryDeclaration<CloseQueryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CloseQueryComponent, "ccd-close-query", never, { "formGroup": { "alias": "formGroup"; "required": false; }; }, {}, never, never, false, never>;
}

declare enum EventCompletionTaskStates {
    TaskCancelled = 0,
    TaskReassigned = 1
}

declare const COMPONENT_PORTAL_INJECTION_TOKEN: InjectionToken<CaseEventCompletionComponent>;
declare class CaseEventCompletionComponent implements OnChanges, EventCompletionComponentEmitter {
    private readonly service;
    private readonly router;
    private readonly route;
    private readonly sessionStorageService;
    private readonly workAllocationService;
    private readonly alertService;
    eventCompletionParams: EventCompletionParams;
    eventCanBeCompleted: EventEmitter<boolean>;
    eventCompletionTaskStates: typeof EventCompletionTaskStates;
    stateMachine: StateMachine;
    context: EventCompletionStateMachineContext;
    taskState: EventCompletionTaskStates;
    constructor(service: EventCompletionStateMachineService, router: Router, route: ActivatedRoute, sessionStorageService: SessionStorageService, workAllocationService: WorkAllocationService, alertService: AlertService);
    ngOnChanges(changes?: SimpleChanges): void;
    setTaskState(taskState: number): void;
    setEventCanBeCompleted(completable: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEventCompletionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseEventCompletionComponent, "ccd-case-event-completion", never, { "eventCompletionParams": { "alias": "eventCompletionParams"; "required": false; }; }, { "eventCanBeCompleted": "eventCanBeCompleted"; }, never, never, false, never>;
}

declare class CaseEventCompletionTaskCancelledComponent implements OnInit {
    context: EventCompletionStateMachineContext;
    notifyEventCompletionCancelled: EventEmitter<boolean>;
    caseId: string;
    jurisdiction: string;
    caseType: string;
    ngOnInit(): void;
    onContinue(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEventCompletionTaskCancelledComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseEventCompletionTaskCancelledComponent, "app-case-event-completion-task-cancelled", never, { "context": { "alias": "context"; "required": false; }; }, { "notifyEventCompletionCancelled": "notifyEventCompletionCancelled"; }, never, never, false, never>;
}

declare class CaseEventCompletionTaskReassignedComponent implements OnInit, OnDestroy {
    private readonly sessionStorageService;
    private readonly judicialworkerService;
    private readonly caseworkerService;
    context: EventCompletionStateMachineContext;
    notifyEventCompletionReassigned: EventEmitter<boolean>;
    caseId: string;
    assignedUserId: string;
    assignedUserName: string;
    subscription: Subscription;
    caseworkerSubscription: Subscription;
    judicialworkerSubscription: Subscription;
    jurisdiction: string;
    caseType: string;
    constructor(sessionStorageService: SessionStorageService, judicialworkerService: JudicialworkerService, caseworkerService: CaseworkerService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onContinue(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEventCompletionTaskReassignedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseEventCompletionTaskReassignedComponent, "app-case-event-completion-task-reassigned", never, { "context": { "alias": "context"; "required": false; }; }, { "notifyEventCompletionReassigned": "notifyEventCompletionReassigned"; }, never, never, false, never>;
}

declare class DatePipe implements PipeTransform {
    private readonly formatTrans;
    private static readonly DATE_FORMAT_REGEXP;
    private static readonly MONTHS;
    /**
     * constructor to allow format translator to be injected
     * @param formatTrans format translator
     */
    constructor(formatTrans: FormatTranslatorService);
    transform(value: string, zone?: string, format?: string): string;
    private translateDateFormat;
    private getOffsetDate;
    private getDate;
    private getHour;
    private toInt;
    private pad;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DatePipe, "ccdDate", false>;
}

declare class FieldLabelPipe implements PipeTransform {
    private readonly rpxTranslationPipe;
    constructor(rpxTranslationPipe: RpxTranslatePipe);
    transform(field: CaseField): string;
    private getTranslatedLabel;
    getOriginalLabelForYesNoTranslation(field: CaseField): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldLabelPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FieldLabelPipe, "ccdFieldLabel", false>;
}

declare class FirstErrorPipe implements PipeTransform, OnDestroy {
    private readonly rpxTranslationService;
    private readonly injector;
    private asyncPipe;
    constructor(rpxTranslationService: RpxTranslationService, injector: Injector);
    transform(value: ValidationErrors, args?: string): string;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FirstErrorPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FirstErrorPipe, "ccdFirstError", false>;
}

declare class IsMandatoryPipe implements PipeTransform {
    private readonly caseFieldService;
    constructor(caseFieldService: CaseFieldService);
    transform(field: CaseField): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsMandatoryPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<IsMandatoryPipe, "ccdIsMandatory", false>;
}

declare class IsReadOnlyPipe implements PipeTransform {
    private readonly caseFieldService;
    constructor(caseFieldService: CaseFieldService);
    transform(field: CaseField): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsReadOnlyPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<IsReadOnlyPipe, "ccdIsReadOnly", false>;
}

declare class IsReadOnlyAndNotCollectionPipe implements PipeTransform {
    private readonly caseFieldService;
    constructor(caseFieldService: CaseFieldService);
    transform(field: CaseField): boolean;
    private isCollection;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsReadOnlyAndNotCollectionPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<IsReadOnlyAndNotCollectionPipe, "ccdIsReadOnlyAndNotCollection", false>;
}

declare class DashPipe implements PipeTransform {
    transform(value: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DashPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<DashPipe, "ccdDash", false>;
}

declare class PaletteUtilsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PaletteUtilsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PaletteUtilsModule, [typeof DatePipe, typeof FieldLabelPipe, typeof FirstErrorPipe, typeof IsCompoundPipe, typeof IsMandatoryPipe, typeof IsReadOnlyPipe, typeof IsReadOnlyAndNotCollectionPipe, typeof DashPipe], [typeof i2.CommonModule, typeof i7.RpxTranslationModule], [typeof DatePipe, typeof FieldLabelPipe, typeof FirstErrorPipe, typeof IsCompoundPipe, typeof IsMandatoryPipe, typeof IsReadOnlyPipe, typeof IsReadOnlyAndNotCollectionPipe, typeof DashPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PaletteUtilsModule>;
}

declare class CaseReferencePipe implements PipeTransform {
    transform(caseReference: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseReferencePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CaseReferencePipe, "ccdCaseReference", false>;
}

declare class SortSearchResultPipe implements PipeTransform {
    transform(searchResults: SearchResultViewItem[], sortParameters: SortParameters): SearchResultViewItem[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SortSearchResultPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SortSearchResultPipe, "ccdSortSearchResult", false>;
}

declare class PlaceholderService {
    resolvePlaceholders(pageFormFields: object, stringToResolve: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PlaceholderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PlaceholderService>;
}
declare namespace PlaceholderService {
    class PlaceholderSubstitutor {
        private static readonly PLACEHOLDER_CONTENT_PATTERN;
        private static readonly PLACEHOLDER_PATTERN;
        private static readonly STARTING_PLACEHOLDER;
        private static readonly CLOSING_PLACEHOLDER;
        private static readonly OPENING_PLACEHOLDER;
        private static readonly NEW_LINE;
        private static readonly PLACEHOLDER_START;
        private static readonly PLACEHOLDER_END;
        private stringToResolve;
        private scanIndex;
        private numberCollectionItemsAsPlaceholder;
        private collectionItemIndex;
        private fieldIdToSubstitute;
        private startSubstitutionIndex;
        private isCollecting;
        private readonly resolvedFormValues;
        private readonly pageFormFields;
        private readonly originalStringToResolve;
        private static wrapPlaceholder;
        constructor(values: {
            stringToResolve: string;
            pageFormFields: object;
        });
        resolvePlaceholders(): string;
        private isScanningStringToResolve;
        private doesPlaceholderContainCollectionItems;
        private hasUnresolvedPlaceholder;
        private isStartPlaceholderAndNotCollecting;
        private isOpeningPlaceholder;
        private isClosingPlaceholder;
        private resetPlaceholderSubstitutor;
        private substitute;
        private appendOriginalStringIfCollectionItemAsPlaceholder;
        private setStartCollecting;
        private appendCharacter;
        private isMatchingPlaceholderPattern;
        private isFieldIdInFormFields;
        private isFieldIdToSubstituteReferringItself;
        private getSubstitutionValueLengthOrZero;
        /**
         * Gets the value from `this` field, which could be any of a number of different types:
         *   string | number | object | string[] | object[] | maybe others...
         * @returns The value associated with `this` field.
         */
        private getFieldValue;
        private getSubstitutionValueOrEmpty;
        private getNumberOfCollectionItemsIfAny;
        private isStartingPlaceholder;
        private updateNumberOfCollectionItemsAsPlaceholder;
        private substituteFromFormFields;
        private substituteWithEmptyString;
        private doSubstitution;
        private resetScanIndexAfterSubstitution;
    }
}

declare class CcdCaseTitlePipe implements PipeTransform {
    private readonly placeholderService;
    private readonly fieldsUtils;
    constructor(placeholderService: PlaceholderService, fieldsUtils: FieldsUtils);
    transform(caseTitle: string, caseFields: CaseField[], values: any): any;
    private getReadOnlyAndFormFields;
    static ɵfac: i0.ɵɵFactoryDeclaration<CcdCaseTitlePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CcdCaseTitlePipe, "ccdCaseTitle", false>;
}

declare class CcdCollectionTableCaseFieldsFilterPipe implements PipeTransform {
    transform(objs: {
        [key: string]: any;
    }[], caseField: CaseField, value: {}): CaseField;
    static ɵfac: i0.ɵɵFactoryDeclaration<CcdCollectionTableCaseFieldsFilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CcdCollectionTableCaseFieldsFilterPipe, "ccdCollectionTableCaseFieldsFilter", false>;
}

declare class CcdCYAPageLabelFilterPipe implements PipeTransform {
    transform(caseFields: CaseField[]): CaseField[];
    private readonly getNonLabelComplexFieldType;
    static ɵfac: i0.ɵɵFactoryDeclaration<CcdCYAPageLabelFilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CcdCYAPageLabelFilterPipe, "ccdCYAPageLabelFilter", false>;
}

declare class ReadFieldsFilterPipe implements PipeTransform {
    private static readonly EMPTY_VALUES;
    private static readonly ALWAYS_NULL_FIELDS;
    private static readonly NESTED_TYPES;
    /**
     * Complex type should have at least on simple field descendant with a value.
     */
    private static isValidComplex;
    private static isValidCollection;
    private static isEmpty;
    private static isCompound;
    private static findAncestorOfType;
    private static getCollectionItemValue;
    private static getBaseConditionalShowContext;
    private static resolvePrefixedConditionalShowContext;
    private static resolveCollectionConditionalShowContext;
    private static resolveFallbackConditionalShowContext;
    private static getConditionalShowContext;
    private static cloneFieldWithValue;
    private static applyDisplayContextAndHidden;
    private static isValidCompound;
    private static keepField;
    private static getValue;
    private static evaluateConditionalShow;
    /**
     * Filter out fields having no data to display and harmonise field values coming parent's value.
     */
    transform(complexField: CaseField, keepEmpty?: boolean, index?: number, setupHidden?: boolean, formGroup?: FormGroup | AbstractControl, path?: string, idPrefix?: string): CaseField[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ReadFieldsFilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ReadFieldsFilterPipe, "ccdReadFieldsFilter", false>;
}

declare class CcdTabFieldsPipe implements PipeTransform {
    transform(tab: CaseTab): CaseField;
    static ɵfac: i0.ɵɵFactoryDeclaration<CcdTabFieldsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CcdTabFieldsPipe, "ccdTabFields", false>;
}

declare class CcdPageFieldsPipe implements PipeTransform {
    transform(page: WizardPage, dataFormGroup: FormGroup): CaseField;
    static ɵfac: i0.ɵɵFactoryDeclaration<CcdPageFieldsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CcdPageFieldsPipe, "ccdPageFields", false>;
}

declare class LinkCasesReasonValuePipe implements PipeTransform {
    private readonly linkedCasesService;
    constructor(linkedCasesService: LinkedCasesService);
    transform(linkReason: LinkReason): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkCasesReasonValuePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<LinkCasesReasonValuePipe, "ccdLinkCasesReasonValue", false>;
}

declare class LinkCasesFromReasonValuePipe implements PipeTransform {
    private readonly linkedCasesService;
    constructor(linkedCasesService: LinkedCasesService);
    transform(linkFromReason: LinkFromReason): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<LinkCasesFromReasonValuePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<LinkCasesFromReasonValuePipe, "ccdLinkCasesFromReasonValue", false>;
}

declare class EnumDisplayDescriptionPipe implements PipeTransform {
    transform(value: any): unknown[];
    static ɵfac: i0.ɵɵFactoryDeclaration<EnumDisplayDescriptionPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<EnumDisplayDescriptionPipe, "enumDisplayDescription", false>;
}

declare class PipesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PipesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PipesModule, [typeof CaseReferencePipe, typeof SortSearchResultPipe, typeof CcdCaseTitlePipe, typeof CcdCollectionTableCaseFieldsFilterPipe, typeof CcdCYAPageLabelFilterPipe, typeof ReadFieldsFilterPipe, typeof CcdTabFieldsPipe, typeof CcdPageFieldsPipe, typeof LinkCasesReasonValuePipe, typeof LinkCasesFromReasonValuePipe, typeof EnumDisplayDescriptionPipe], [typeof i2.CommonModule], [typeof CaseReferencePipe, typeof SortSearchResultPipe, typeof CcdCaseTitlePipe, typeof CcdCollectionTableCaseFieldsFilterPipe, typeof CcdCYAPageLabelFilterPipe, typeof ReadFieldsFilterPipe, typeof CcdTabFieldsPipe, typeof CcdPageFieldsPipe, typeof LinkCasesReasonValuePipe, typeof LinkCasesFromReasonValuePipe, typeof EnumDisplayDescriptionPipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PipesModule>;
}

declare class NotificationBannerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NotificationBannerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NotificationBannerModule, [typeof NotificationBannerComponent], [typeof i2.CommonModule], [typeof NotificationBannerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NotificationBannerModule>;
}

declare class BannersModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BannersModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BannersModule, never, [typeof i2.CommonModule, typeof AlertModule, typeof NotificationBannerModule], [typeof AlertModule, typeof NotificationBannerModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BannersModule>;
}

declare class FootersModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FootersModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FootersModule, [typeof FooterComponent], [typeof i2.CommonModule, typeof i7.RpxTranslationModule], [typeof FooterComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FootersModule>;
}

declare class BodyModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<BodyModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<BodyModule, [typeof BodyComponent], [typeof i2.CommonModule, typeof i3.RouterModule], [typeof BodyComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<BodyModule>;
}

declare class FormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FormModule, [typeof DateInputComponent], [typeof i2.CommonModule, typeof i7.RpxTranslationModule], [typeof DateInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FormModule>;
}

declare class LabelSubstitutorDirective implements OnInit, OnDestroy {
    private readonly fieldsUtils;
    private readonly placeholderService;
    private readonly rpxTranslationPipe;
    private readonly rpxTranslationService;
    caseField: CaseField;
    contextFields: CaseField[];
    formGroup: FormGroup;
    elementsToSubstitute: string[];
    private initialLabel;
    private initialHintText;
    private languageSubscription;
    constructor(fieldsUtils: FieldsUtils, placeholderService: PlaceholderService, rpxTranslationPipe: RpxTranslatePipe, rpxTranslationService: RpxTranslationService);
    ngOnInit(): void;
    private noCacheProcessing;
    private applySubstitutions;
    private applyLabelSubstitution;
    private applyTranslatedLabelState;
    private translateLabel;
    private translateLabelOnLanguageChange;
    private setLabelState;
    private onLanguageChange;
    private resetToInitialValues;
    ngOnDestroy(): void;
    private shouldSubstitute;
    private getReadOnlyAndFormFields;
    private removeDuplicates;
    private getFormFieldsValuesIncludingDisabled;
    private resolvePlaceholders;
    static ɵfac: i0.ɵɵFactoryDeclaration<LabelSubstitutorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<LabelSubstitutorDirective, "[ccdLabelSubstitutor]", never, { "caseField": { "alias": "caseField"; "required": false; }; "contextFields": { "alias": "contextFields"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "elementsToSubstitute": { "alias": "elementsToSubstitute"; "required": false; }; }, {}, never, never, false, never>;
}

declare class LabelSubstitutorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LabelSubstitutorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LabelSubstitutorModule, [typeof LabelSubstitutorDirective], never, [typeof LabelSubstitutorDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LabelSubstitutorModule>;
}

/**
 * @directive TranslatedMarkdownDirective
 *
 * @description
 * Structural directive that emits language-appropriate markdown content based on the user's UI language.
 * It is designed for service-supplied content that optionally includes a Welsh (`markdown_cy`) version.
 *
 * The directive:
 * - Emits `markdown_cy` if the UI language is Welsh and the field exists
 * - Emits `markdown` otherwise (no translation is applied within the directive)
 * - Leaves it up to the consuming template to apply fallback translation (e.g. via `rpxTranslate`)
 *
 * This allows cleaner templates and better separation of content choice vs. translation logic.
 *
 * @usage
 * ```html
 * <div *ngFor="let qq of qualifyingQuestions">
 *   <ng-container *translatedMarkdown="qq; let content">
 *     <markdown [data]="qq ? content : (qq.markdown | rpxTranslate)"></markdown>
 *   </ng-container>
 * </div>
 * ```
 *
 * @input dataItem - An object expected to contain:
 * - `markdown` (string): the default English content
 * - `markdown_cy` (string | optional): the Welsh version of the content
 * - Any additional metadata used in context
 *
 * @example
 * // --- LaunchDarkly JSON format ---
 * {
 *   "UNSPEC_CLAIM": [
 *     {
 *       "name": "Raise a query",
 *       "url": "http://...",
 *       "markdown": "### Raise a query\nUse this to raise a new query.",
 *       "markdown_cy": "### Codwch ymholiad\nDefnyddiwch hwn i godi ymholiad newydd."
 *     }
 *   ]
 * }
 *
 * // --- Input object in component after processing ---
 * const dataItem = {
 *   name: 'Raise a query',
 *   url: 'http://...',
 *   markdown: '### Raise a query\nUse this to raise a new query.',
 *   markdown_cy: '### Codwch ymholiad\nDefnyddiwch hwn i godi ymholiad newydd.'
 * };
 *
 * // --- Template usage ---
 * <ng-container *translatedMarkdown="dataItem; let content">
 *   <markdown [data]="dataItem ? content : (dataItem.markdown | rpxTranslate)"></markdown>
 * </ng-container>
 */
/**
 * @directive TranslatedMarkdownDirective
 *
 * Renders Welsh markdown (`markdown_cy`) if the UI language is Welsh,
 * otherwise uses English (`markdown`). Reactively updates when the language changes.
 */
declare class TranslatedMarkdownDirective implements OnInit, OnDestroy {
    private viewContainer;
    private templateRef;
    private translationService;
    dataItem: any;
    private subscription;
    constructor(viewContainer: ViewContainerRef, templateRef: TemplateRef<any>, translationService: RpxTranslationService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslatedMarkdownDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TranslatedMarkdownDirective, "[translatedMarkdown]", never, { "dataItem": { "alias": "translatedMarkdown"; "required": false; }; }, {}, never, never, false, never>;
}

declare class TranslatedMarkdownModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslatedMarkdownModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TranslatedMarkdownModule, [typeof TranslatedMarkdownDirective], never, [typeof TranslatedMarkdownDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TranslatedMarkdownModule>;
}

declare class MarkdownComponent implements OnInit {
    private router;
    private renderer;
    private ngZone;
    private cdr;
    content: string;
    renderUrlToTextFeature?: boolean;
    constructor(router: Router, renderer: Renderer2, ngZone: NgZone, cdr: ChangeDetectorRef);
    ngOnInit(): void;
    interceptClick(event: MouseEvent): void;
    private renderUrlToText;
    private isAllowedUrl;
    private detectMarkdownLinks;
    static ɵfac: i0.ɵɵFactoryDeclaration<MarkdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MarkdownComponent, "ccd-markdown", never, { "content": { "alias": "content"; "required": false; }; "renderUrlToTextFeature": { "alias": "renderUrlToTextFeature"; "required": false; }; }, {}, never, never, false, never>;
}

declare class RouterLinkComponent {
    link: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<RouterLinkComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RouterLinkComponent, "exui-routerlink", never, {}, {}, never, ["*"], false, never>;
}

declare class MarkdownComponentModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MarkdownComponentModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MarkdownComponentModule, [typeof MarkdownComponent, typeof RouterLinkComponent], [typeof i2.CommonModule, typeof i3$1.ReactiveFormsModule, typeof PipesModule, typeof i6.MarkdownModule, typeof i3.RouterModule], [typeof MarkdownComponent, typeof RouterLinkComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MarkdownComponentModule>;
}

declare class CallbackErrorsContext {
    triggerText: string;
    ignoreWarning: boolean;
    eventId?: string;
}

declare class CallbackErrorsComponent implements OnInit {
    static readonly TRIGGER_TEXT_SUBMIT = "Submit";
    static readonly TRIGGER_TEXT_START = "Start";
    static readonly TRIGGER_TEXT_GO = "Go";
    static readonly TRIGGER_TEXT_IGNORE = "Ignore Warning and Go";
    triggerTextIgnore: string;
    triggerTextContinue: string;
    callbackErrorsSubject: Subject<any>;
    callbackErrorsContext: EventEmitter<CallbackErrorsContext>;
    error: HttpError;
    ngOnInit(): void;
    hasErrors(): boolean;
    hasWarnings(): boolean;
    private buildCallbackErrorsContext;
    private hasInvalidData;
    static ɵfac: i0.ɵɵFactoryDeclaration<CallbackErrorsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CallbackErrorsComponent, "ccd-callback-errors", never, { "triggerTextIgnore": { "alias": "triggerTextIgnore"; "required": false; }; "triggerTextContinue": { "alias": "triggerTextContinue"; "required": false; }; "callbackErrorsSubject": { "alias": "callbackErrorsSubject"; "required": false; }; }, { "callbackErrorsContext": "callbackErrorsContext"; }, never, never, false, never>;
}

declare class ErrorsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ErrorsModule, [typeof CallbackErrorsComponent], [typeof i2.CommonModule, typeof i3.RouterModule, typeof i7.RpxTranslationModule], [typeof CallbackErrorsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ErrorsModule>;
}

declare class PaletteModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PaletteModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PaletteModule, [typeof FixedListPipe, typeof FixedRadioListPipe, typeof DynamicListPipe, typeof DynamicRadioListPipe, typeof DocumentUrlPipe, typeof FlagFieldDisplayPipe, typeof LanguageInterpreterDisplayPipe, typeof ManageCaseFlagsLabelDisplayPipe, typeof UpdateFlagTitleDisplayPipe, typeof UnsupportedFieldComponent, typeof DatetimePickerComponent, typeof WaysToPayFieldComponent, typeof FieldReadComponent, typeof FieldWriteComponent, typeof FieldReadLabelComponent, typeof LabelFieldComponent, typeof CasePaymentHistoryViewerFieldComponent, typeof MoneyGbpInputComponent, typeof CaseHistoryViewerFieldComponent, typeof EventLogComponent, typeof EventLogDetailsComponent, typeof EventLogTableComponent, typeof ReadTextFieldComponent, typeof ReadTextAreaFieldComponent, typeof ReadNumberFieldComponent, typeof ReadEmailFieldComponent, typeof ReadPhoneUKFieldComponent, typeof ReadDateFieldComponent, typeof ReadCollectionFieldComponent, typeof ReadDocumentFieldComponent, typeof ReadJudicialUserFieldComponent, typeof ReadYesNoFieldComponent, typeof ReadOrganisationFieldComponent, typeof ReadOrganisationFieldTableComponent, typeof ReadOrganisationFieldRawComponent, typeof ReadOrderSummaryFieldComponent, typeof ReadOrderSummaryRowComponent, typeof ReadMoneyGbpFieldComponent, typeof ReadMultiSelectListFieldComponent, typeof ReadDynamicListFieldComponent, typeof ReadFixedListFieldComponent, typeof ReadFixedRadioListFieldComponent, typeof ReadDynamicRadioListFieldComponent, typeof ReadCaseLinkFieldComponent, typeof ReadComplexFieldComponent, typeof ReadComplexFieldRawComponent, typeof ReadComplexFieldTableComponent, typeof ReadComplexFieldCollectionTableComponent, typeof ReadCaseFlagFieldComponent, typeof ReadLinkedCasesFieldComponent, typeof WriteJudicialUserFieldComponent, typeof WriteAddressFieldComponent, typeof WriteComplexFieldComponent, typeof WriteOrganisationComplexFieldComponent, typeof WriteDocumentFieldComponent, typeof WriteDynamicListFieldComponent, typeof WriteDynamicRadioListFieldComponent, typeof WriteTextFieldComponent, typeof WriteDateContainerFieldComponent, typeof WriteTextAreaFieldComponent, typeof WritePhoneUKFieldComponent, typeof WriteNumberFieldComponent, typeof WriteEmailFieldComponent, typeof WriteDateFieldComponent, typeof WriteCaseFlagFieldComponent, typeof WriteLinkedCasesFieldComponent, typeof WriteYesNoFieldComponent, typeof WriteOrganisationFieldComponent, typeof WriteOrganisationComplexFieldComponent, typeof WriteOrderSummaryFieldComponent, typeof WriteMoneyGbpFieldComponent, typeof WriteDateContainerFieldComponent, typeof WriteMultiSelectListFieldComponent, typeof WriteFixedListFieldComponent, typeof WriteFixedRadioListFieldComponent, typeof WriteCaseLinkFieldComponent, typeof WriteCollectionFieldComponent, typeof CaseFileViewFieldComponent, typeof CaseFileViewFolderComponent, typeof CaseFileViewFolderSortComponent, typeof CaseFileViewFolderToggleComponent, typeof CaseFileViewOverlayMenuComponent, typeof CaseFileViewFolderDocumentActionsComponent, typeof CaseFileViewFolderSelectorComponent, typeof WriteDynamicMultiSelectListFieldComponent, typeof WriteDynamicRadioListFieldComponent, typeof WriteDynamicListFieldComponent, typeof ReadDynamicMultiSelectListFieldComponent, typeof ReadDynamicListFieldComponent, typeof ReadDynamicRadioListFieldComponent, typeof CaseFlagTableComponent, typeof SelectFlagTypeComponent, typeof SearchLanguageInterpreterComponent, typeof SelectFlagLocationComponent, typeof ManageCaseFlagsComponent, typeof AddCommentsComponent, typeof UpdateFlagComponent, typeof CaseFlagSummaryListComponent, typeof ConfirmFlagStatusComponent, typeof UpdateFlagAddTranslationFormComponent, typeof LinkedCasesToTableComponent, typeof LinkedCasesFromTableComponent, typeof BeforeYouStartComponent, typeof LinkCasesComponent, typeof CheckYourAnswersComponent, typeof UnLinkCasesComponent, typeof NoLinkedCasesComponent, typeof ReadQueryManagementFieldComponent, typeof QueryDetailsComponent, typeof QueryListComponent, typeof QueryWriteRespondToQueryComponent, typeof QueryWriteRaiseQueryComponent, typeof QueryCaseDetailsHeaderComponent, typeof QueryCheckYourAnswersComponent, typeof QueryWriteAddDocumentsComponent, typeof QueryWriteDateInputComponent, typeof QualifyingQuestionOptionsComponent, typeof QualifyingQuestionDetailComponent, typeof QueryAttachmentsReadComponent, typeof QueryEventCompletionComponent, typeof QueryConfirmationComponent, typeof CloseQueryComponent, typeof CaseEventCompletionComponent, typeof CaseEventCompletionTaskCancelledComponent, typeof CaseEventCompletionTaskReassignedComponent], [typeof i2.CommonModule, typeof i3.RouterModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof CaseEditDataModule, typeof PaletteUtilsModule, typeof PipesModule, typeof BannersModule, typeof HeadersModule, typeof FootersModule, typeof BodyModule, typeof FormModule, typeof TabsModule, typeof LabelSubstitutorModule, typeof TranslatedMarkdownModule, typeof i6.MarkdownModule, typeof i135.NgxMatDatepickerActions, typeof i135.NgxMatDatepickerApply, typeof i135.NgxMatDatepickerInput, typeof i135.NgxMatDatetimepicker, typeof i136.MatFormFieldModule, typeof i137.MatInputModule, typeof i138.MatDatepickerModule, typeof i139.MatAutocompleteModule, typeof i140.CdkTreeModule, typeof i141.OverlayModule, typeof i142.PaymentLibModule, typeof i7.RpxTranslationModule, typeof i140.CdkTreeModule, typeof i141.OverlayModule, typeof i144.MatDialogModule, typeof i145.MediaViewerModule, typeof LoadingModule, typeof MarkdownComponentModule, typeof ErrorsModule], [typeof i135.NgxMatDatepickerActions, typeof i135.NgxMatDatepickerApply, typeof i135.NgxMatDatepickerInput, typeof i135.NgxMatDatetimepicker, typeof TabsModule, typeof PaletteUtilsModule, typeof PipesModule, typeof MarkdownComponentModule, typeof UnsupportedFieldComponent, typeof DatetimePickerComponent, typeof WaysToPayFieldComponent, typeof FieldReadComponent, typeof FieldWriteComponent, typeof FieldReadLabelComponent, typeof LabelFieldComponent, typeof CasePaymentHistoryViewerFieldComponent, typeof MoneyGbpInputComponent, typeof CaseHistoryViewerFieldComponent, typeof EventLogComponent, typeof EventLogDetailsComponent, typeof EventLogTableComponent, typeof ReadTextFieldComponent, typeof ReadTextAreaFieldComponent, typeof ReadNumberFieldComponent, typeof ReadEmailFieldComponent, typeof ReadPhoneUKFieldComponent, typeof ReadDateFieldComponent, typeof ReadCollectionFieldComponent, typeof ReadDocumentFieldComponent, typeof ReadJudicialUserFieldComponent, typeof ReadYesNoFieldComponent, typeof ReadOrganisationFieldComponent, typeof ReadOrganisationFieldTableComponent, typeof ReadOrganisationFieldRawComponent, typeof ReadOrderSummaryFieldComponent, typeof ReadOrderSummaryRowComponent, typeof ReadMoneyGbpFieldComponent, typeof ReadMultiSelectListFieldComponent, typeof ReadDynamicListFieldComponent, typeof ReadFixedListFieldComponent, typeof ReadFixedRadioListFieldComponent, typeof ReadDynamicRadioListFieldComponent, typeof ReadCaseLinkFieldComponent, typeof ReadComplexFieldComponent, typeof ReadComplexFieldRawComponent, typeof ReadComplexFieldTableComponent, typeof ReadComplexFieldCollectionTableComponent, typeof ReadCaseFlagFieldComponent, typeof ReadLinkedCasesFieldComponent, typeof WriteJudicialUserFieldComponent, typeof WriteAddressFieldComponent, typeof WriteComplexFieldComponent, typeof WriteOrganisationComplexFieldComponent, typeof WriteDocumentFieldComponent, typeof WriteDynamicListFieldComponent, typeof WriteDynamicRadioListFieldComponent, typeof WriteTextFieldComponent, typeof WriteDateContainerFieldComponent, typeof WriteTextAreaFieldComponent, typeof WritePhoneUKFieldComponent, typeof WriteNumberFieldComponent, typeof WriteEmailFieldComponent, typeof WriteDateFieldComponent, typeof WriteCaseFlagFieldComponent, typeof WriteLinkedCasesFieldComponent, typeof WriteYesNoFieldComponent, typeof WriteOrganisationFieldComponent, typeof WriteOrganisationComplexFieldComponent, typeof WriteOrderSummaryFieldComponent, typeof WriteMoneyGbpFieldComponent, typeof WriteDateContainerFieldComponent, typeof WriteMultiSelectListFieldComponent, typeof WriteFixedListFieldComponent, typeof WriteFixedRadioListFieldComponent, typeof WriteCaseLinkFieldComponent, typeof WriteCollectionFieldComponent, typeof CaseFileViewFieldComponent, typeof CaseFileViewFolderComponent, typeof CaseFileViewFolderSortComponent, typeof CaseFileViewFolderToggleComponent, typeof CaseFileViewOverlayMenuComponent, typeof CaseFileViewFolderDocumentActionsComponent, typeof CaseFileViewFolderSelectorComponent, typeof WriteDynamicMultiSelectListFieldComponent, typeof WriteDynamicRadioListFieldComponent, typeof WriteDynamicListFieldComponent, typeof ReadDynamicMultiSelectListFieldComponent, typeof ReadDynamicListFieldComponent, typeof ReadDynamicRadioListFieldComponent, typeof CaseFlagTableComponent, typeof SelectFlagTypeComponent, typeof SearchLanguageInterpreterComponent, typeof SelectFlagLocationComponent, typeof ManageCaseFlagsComponent, typeof AddCommentsComponent, typeof UpdateFlagComponent, typeof CaseFlagSummaryListComponent, typeof ConfirmFlagStatusComponent, typeof UpdateFlagAddTranslationFormComponent, typeof LinkedCasesToTableComponent, typeof LinkedCasesFromTableComponent, typeof BeforeYouStartComponent, typeof LinkCasesComponent, typeof CheckYourAnswersComponent, typeof UnLinkCasesComponent, typeof NoLinkedCasesComponent, typeof ReadQueryManagementFieldComponent, typeof QueryDetailsComponent, typeof QueryListComponent, typeof QueryWriteRespondToQueryComponent, typeof QueryWriteRaiseQueryComponent, typeof QueryCaseDetailsHeaderComponent, typeof QueryCheckYourAnswersComponent, typeof QueryWriteAddDocumentsComponent, typeof QueryWriteDateInputComponent, typeof QualifyingQuestionOptionsComponent, typeof QualifyingQuestionDetailComponent, typeof QueryAttachmentsReadComponent, typeof QueryEventCompletionComponent, typeof QueryConfirmationComponent, typeof CloseQueryComponent, typeof CaseEventCompletionComponent, typeof CaseEventCompletionTaskCancelledComponent, typeof CaseEventCompletionTaskReassignedComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PaletteModule>;
}

declare class ConditionalShowFormDirective implements OnInit, AfterViewInit, OnDestroy {
    private readonly fieldsUtils;
    caseFields: CaseField[];
    contextFields: CaseField[];
    formGroup: FormGroup;
    private allFieldValues;
    private formChangesSubscription;
    constructor(fieldsUtils: FieldsUtils);
    ngOnInit(): void;
    /**
     * Moved the evaluation of show/hide conditions and subscription
     * to form changes until after the form has been fully created.
     *
     * Prior to this change, I traced more than 5,100,000 firings of
     * the evaluateCondition INSIDE the show_condition check on page
     * load for an event with a lot of content. After this change,
     * that number dropped to fewer than 2,500 - that's a.
     */
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    private subscribeToFormChanges;
    private evaluateControl;
    private evaluateCondition;
    private readonly handleFormControl;
    private readonly handleFormArray;
    private readonly handleFormGroup;
    evalAllShowHideConditions(): void;
    private buildPath;
    private getCurrentPagesReadOnlyAndFormFieldValues;
    private getFormFieldsValuesIncludingDisabled;
    private unsubscribeFromFormChanges;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConditionalShowFormDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ConditionalShowFormDirective, "[ccdConditionalShowForm]", never, { "caseFields": { "alias": "caseFields"; "required": false; }; "contextFields": { "alias": "contextFields"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ConditionalShowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ConditionalShowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ConditionalShowModule, [typeof ConditionalShowFormDirective], never, [typeof ConditionalShowFormDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ConditionalShowModule>;
}

declare class SearchFiltersModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchFiltersModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SearchFiltersModule, [typeof SearchFiltersComponent, typeof SearchFiltersWrapperComponent], [typeof i2.CommonModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof PaletteModule, typeof ConditionalShowModule, typeof i7.RpxTranslationModule], [typeof SearchFiltersWrapperComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SearchFiltersModule>;
}

declare class SearchService {
    private readonly appConfig;
    private readonly httpService;
    private readonly requestOptionsBuilder;
    private readonly loadingService;
    static readonly V2_MEDIATYPE_SEARCH_INPUTS = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-search-input-details.v2+json;charset=UTF-8";
    static readonly VIEW_WORKBASKET = "WORKBASKET";
    private currentJurisdiction;
    private currentCaseType;
    constructor(appConfig: AbstractAppConfig, httpService: HttpService, requestOptionsBuilder: RequestOptionsBuilder, loadingService: LoadingService);
    search(jurisdictionId: string, caseTypeId: string, metaCriteria: object, caseCriteria: object, view?: SearchView): Observable<SearchResultView>;
    searchCasesByIds(caseTypeId: string, filter: any, view?: SearchView, sort?: {
        column: string;
        order: number;
    }): Observable<{}>;
    searchCases(caseTypeId: string, metaCriteria: object, caseCriteria: object, view?: SearchView, sort?: {
        column: string;
        order: number;
    }): Observable<{}>;
    getSearchInputUrl(caseTypeId: string): string;
    getSearchInputs(jurisdictionId: string, caseTypeId: string): Observable<SearchInput[]>;
    isDataValid(jurisdictionId: string, caseTypeId: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchService>;
}

declare class RetryUtil {
    private readonly logger;
    pipeTimeoutMechanismOn<T>(in$: Observable<T>, preferredArtificialDelay: number, timeoutPeriods: number[]): Observable<T>;
    private pipeTimeOutControlOn;
    private pipeRetryMechanismOn;
    private pipeArtificialDelayOn;
    static ɵfac: i0.ɵɵFactoryDeclaration<RetryUtil, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RetryUtil>;
}

declare class WorkbasketInputFilterService {
    private readonly httpService;
    private readonly appConfig;
    static readonly V2_MEDIATYPE_WORKBASKET_INPUT_DETAILS = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-workbasket-input-details.v2+json;charset=UTF-8";
    private currentJurisdiction;
    private currentCaseType;
    constructor(httpService: HttpService, appConfig: AbstractAppConfig);
    getWorkbasketInputUrl(caseTypeId: string): string;
    getWorkbasketInputs(jurisdictionId: string, caseTypeId: string): Observable<WorkbasketInputModel[]>;
    isDataValid(jurisdictionId: string, caseTypeId: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkbasketInputFilterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<WorkbasketInputFilterService>;
}

declare class DefinitionsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DefinitionsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DefinitionsModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DefinitionsModule>;
}

declare class SearchResultViewItemComparatorFactory {
    createSearchResultViewItemComparator(column: SearchResultViewColumn): SearchResultViewItemComparator;
    private numberComparator;
    private stringComparator;
    private textArrayComparator;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchResultViewItemComparatorFactory, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchResultViewItemComparatorFactory>;
}

declare abstract class AbstractFieldWriteJourneyComponent extends AbstractFieldWriteComponent implements OnChanges, Journey {
    protected readonly multipageComponentStateService: MultipageComponentStateService;
    journeyStartPageNumber: number;
    journeyEndPageNumber: number;
    journeyPageNumber: number;
    journeyPreviousPageNumber: number;
    journeyId: string;
    childJourney: Journey;
    constructor(multipageComponentStateService: MultipageComponentStateService);
    next(): void;
    previous(): void;
    protected previousPage(): void;
    protected nextPage(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    hasNext(): boolean;
    hasPrevious(): boolean;
    isFinished(): boolean;
    isStart(): boolean;
    getId(): string;
    onPageChange(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AbstractFieldWriteJourneyComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AbstractFieldWriteJourneyComponent, never, never, { "journeyId": { "alias": "journeyId"; "required": false; }; }, {}, never, never, true, never>;
}

declare class AddCommentsComponent extends AbstractJourneyComponent implements OnInit, Journey {
    formGroup: FormGroup;
    optional: boolean;
    isDisplayContextParameterExternal: boolean;
    isDisplayContextParameter2Point1Enabled: boolean;
    caseFlagStateEmitter: EventEmitter<CaseFlagState>;
    addCommentsTitle: CaseFlagWizardStepTitle;
    errorMessages: ErrorMessage[];
    flagCommentsNotEnteredErrorMessage: AddCommentsErrorMessage;
    flagCommentsCharLimitErrorMessage: AddCommentsErrorMessage;
    addCommentsHint: AddCommentsStep;
    addCommentsStepEnum: typeof AddCommentsStep;
    readonly flagCommentsControlName = "flagComments";
    private readonly commentsMaxCharLimit;
    private readonly otherFlagTypeCode;
    get otherInternalFlagTypeSelected(): boolean;
    ngOnInit(): void;
    onNext(): void;
    private validateTextEntry;
    next(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddCommentsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddCommentsComponent, "ccd-add-comments", never, { "formGroup": { "alias": "formGroup"; "required": false; }; "optional": { "alias": "optional"; "required": false; }; "isDisplayContextParameterExternal": { "alias": "isDisplayContextParameterExternal"; "required": false; }; "isDisplayContextParameter2Point1Enabled": { "alias": "isDisplayContextParameter2Point1Enabled"; "required": false; }; }, { "caseFlagStateEmitter": "caseFlagStateEmitter"; }, never, never, false, never>;
}

declare class CaseView {
    case_id?: string;
    case_type: {
        id: string;
        name: string;
        description?: string;
        jurisdiction: {
            id: string;
            name: string;
            description?: string;
        };
        printEnabled?: boolean;
    };
    state: {
        id: string;
        name: string;
        description?: string;
        title_display?: string;
    };
    channels: string[];
    tabs: CaseTab[];
    triggers: CaseViewTrigger[];
    events: CaseViewEvent[];
    metadataFields?: CaseField[];
    basicFields?: {
        caseNameHmctsInternal?: string;
        caseManagementLocation?: {
            baseLocation?: number;
        };
    };
    case_flag?: Flags;
}

declare class DraftService {
    private readonly http;
    private readonly appConfig;
    private readonly errorService;
    static readonly V2_MEDIATYPE_DRAFT_CREATE = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-draft-create.v2+json;charset=UTF-8";
    static readonly V2_MEDIATYPE_DRAFT_UPDATE = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-draft-update.v2+json;charset=UTF-8";
    static readonly V2_MEDIATYPE_DRAFT_READ = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-draft-read.v2+json;charset=UTF-8";
    static readonly V2_MEDIATYPE_DRAFT_DELETE = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-draft-delete.v2+json;charset=UTF-8";
    constructor(http: HttpService, appConfig: AbstractAppConfig, errorService: HttpErrorService);
    createDraft(ctid: string, eventData: CaseEventData): Observable<Draft>;
    updateDraft(ctid: string, draftId: string, eventData: CaseEventData): Observable<Draft>;
    getDraft(draftId: string): Observable<CaseView>;
    deleteDraft(draftId: string): Observable<{} | any>;
    createOrUpdateDraft(caseTypeId: string, draftId: string, caseEventData: CaseEventData): Observable<Draft>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DraftService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DraftService>;
}

declare class CaseCreateComponent implements OnInit {
    private readonly casesService;
    private readonly alertService;
    private readonly draftService;
    private readonly eventTriggerService;
    jurisdiction: string;
    caseType: string;
    event: string;
    cancelled: EventEmitter<any>;
    submitted: EventEmitter<any>;
    eventTrigger: CaseEventTrigger;
    constructor(casesService: CasesService, alertService: AlertService, draftService: DraftService, eventTriggerService: EventTriggerService);
    ngOnInit(): void;
    submit(): (sanitizedEditForm: CaseEventData) => Observable<object>;
    validate(): (sanitizedEditForm: CaseEventData, pageId: string) => Observable<object>;
    saveDraft(): (caseEventData: CaseEventData) => Observable<Draft>;
    emitCancelled(event: any): void;
    emitSubmitted(event: any): void;
    isDataLoaded(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseCreateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseCreateComponent, "ccd-case-create", never, { "jurisdiction": { "alias": "jurisdiction"; "required": false; }; "caseType": { "alias": "caseType"; "required": false; }; "event": { "alias": "event"; "required": false; }; }, { "cancelled": "cancelled"; "submitted": "submitted"; }, never, never, false, never>;
}

declare class ConditionalShowRegistrarService {
    registeredDirectives: ConditionalShowFormDirective[];
    register(newDirective: ConditionalShowFormDirective): void;
    reset(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConditionalShowRegistrarService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ConditionalShowRegistrarService>;
}

/** Keeps track of initially hidden fields that toggle to show on the page (parent page).
 *  Used to decide whether to redisplay the grey bar when returning to the page during
 *  navigation between pages.
 */
declare class GreyBarService {
    private fieldsToggledToShow;
    private readonly renderer;
    constructor(rendererFactory: RendererFactory2);
    showGreyBar(field: CaseField, el: ElementRef): void;
    removeGreyBar(el: ElementRef): void;
    addToggledToShow(fieldId: string): void;
    removeToggledToShow(fieldId: string): void;
    wasToggledToShow(fieldId: string): boolean;
    reset(): void;
    private addGreyBar;
    static ɵfac: i0.ɵɵFactoryDeclaration<GreyBarService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GreyBarService>;
}

declare class ValidPageListCaseFieldsService {
    private readonly fieldsUtils;
    constructor(fieldsUtils: FieldsUtils);
    private isShown;
    deleteNonValidatedFields(validPageList: WizardPage[], caseEventDatadata: object, eventTriggerFields: CaseField[], fromPreviousPage: boolean, formFields: object): void;
    validPageListCaseFields(validPageList: WizardPage[], eventTriggerFields: CaseField[], formFields: object): CaseField[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ValidPageListCaseFieldsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ValidPageListCaseFieldsService>;
}

declare class CaseEditComponent implements OnInit, OnDestroy {
    private readonly fb;
    readonly caseNotifier: CaseNotifier;
    private readonly router;
    private readonly route;
    private readonly fieldsUtils;
    private readonly fieldsPurger;
    private readonly registrarService;
    private readonly wizardFactory;
    private readonly sessionStorageService;
    private readonly windowsService;
    private readonly formValueService;
    private readonly formErrorService;
    private readonly loadingService;
    private readonly validPageListCaseFieldsService;
    private readonly workAllocationService;
    private readonly alertService;
    private readonly abstractConfig;
    private readonly cookieService;
    static readonly ORIGIN_QUERY_PARAM = "origin";
    static readonly ALERT_MESSAGE = "Page is being refreshed so you will be redirected to the first page of this event.";
    static readonly CLIENT_CONTEXT = "clientContext";
    static readonly TASK_EVENT_COMPLETION_INFO = "taskEventCompletionInfo";
    eventTrigger: CaseEventTrigger;
    submit: (caseEventData: CaseEventData, profile?: Profile) => Observable<object>;
    validate: (caseEventData: CaseEventData, pageId: string) => Observable<object>;
    saveDraft: (caseEventData: CaseEventData) => Observable<Draft>;
    caseDetails: CaseView;
    cancelled: EventEmitter<any>;
    submitted: EventEmitter<any>;
    wizard: Wizard;
    form: FormGroup;
    confirmation: Confirmation;
    navigationOrigin: any;
    initialUrl: string;
    isPageRefreshed: boolean;
    isSubmitting: boolean;
    eventCompletionParams: EventCompletionParams;
    submitResponse: Record<string, any>;
    isEventCompletionChecksRequired: boolean;
    isCaseFlagSubmission: boolean;
    ignoreWarning: boolean;
    isLinkedCasesSubmission: boolean;
    error: HttpError;
    callbackErrorsSubject: Subject<any>;
    validPageList: WizardPage[];
    isRefreshModalVisible: boolean;
    constructor(fb: FormBuilder, caseNotifier: CaseNotifier, router: Router, route: ActivatedRoute, fieldsUtils: FieldsUtils, fieldsPurger: FieldsPurger, registrarService: ConditionalShowRegistrarService, wizardFactory: WizardFactoryService, sessionStorageService: SessionStorageService, windowsService: WindowService, formValueService: FormValueService, formErrorService: FormErrorService, loadingService: LoadingService, validPageListCaseFieldsService: ValidPageListCaseFieldsService, workAllocationService: WorkAllocationService, alertService: AlertService, abstractConfig: AbstractAppConfig, cookieService: ReadCookieService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    checkPageRefresh(): boolean;
    onRefreshModalOk(): void;
    getPage(pageId: string): WizardPage;
    first(): Promise<boolean>;
    navigateToPage(pageId: string): Promise<boolean>;
    next(currentPageId: string): Promise<boolean>;
    previous(currentPageId: string): Promise<boolean>;
    hasPrevious(currentPageId: string): boolean;
    cancel(): void;
    emitSubmitted(response: Record<string, any>): void;
    getNextPage({ wizard, currentPageId, eventTrigger, form }: CaseEditGetNextPage): WizardPage;
    confirm(confirmation: Confirmation): Promise<boolean>;
    submitForm({ eventTrigger, form, caseDetails, submit }: CaseEditSubmitForm): void;
    getCaseId(caseDetails: CaseView): string;
    private getEventId;
    private generateCaseEventData;
    /**
     * Replaces non-array value objects with `null` for any Complex-type fields whose value is effectively empty, i.e.
     * all its sub-fields and descendants are `null` or `undefined`.
     *
     * @param data The object tree representing all the form field data
     * @returns The form field data modified accordingly
     */
    private replaceEmptyComplexFieldValues;
    /**
     * Traverse *all* values of a {@link FormGroup}, including those for disabled fields (i.e. hidden ones), replacing the
     * value of any that are hidden AND have `retain_hidden_value` set to `true` in the corresponding `CaseField`, with
     * the *original* value held in the `CaseField` object.
     *
     * This is as per design in EUI-3622, where any user-driven updates to hidden fields with `retain_hidden_value` =
     * `true` are ignored (thus retaining the value displayed originally).
     *
     * * For Complex field types, the replacement above is performed recursively for all hidden sub-fields with
     * `retain_hidden_value` = `true`.
     *
     * * For Collection field types, including collections of Complex and Document field types, the replacement is
     * performed for all fields in the collection.
     *
     * @param formGroup The `FormGroup` instance whose raw values are to be traversed
     * @param caseFields The array of {@link CaseField} domain model objects corresponding to fields in `formGroup`
     * @param parentField Reference to the parent `CaseField`. Used for retrieving the sub-field values of a Complex field
     * to perform recursive replacement - the sub-field `CaseField`s themselves do *not* contain any values
     * @returns An object with the *raw* form value data (as key-value pairs), with any value replacements as necessary
     */
    private replaceHiddenFormValuesWithOriginalCaseData;
    private handleNonComplexField;
    private handleComplexField;
    private caseSubmit;
    private postCompleteTaskIfRequired;
    private finishEventCompletionLogic;
    private buildConfirmation;
    taskExistsForThisEvent(taskInSessionStorage: Task, taskEventCompletionInfo: TaskEventCompletionInfo, eventDetails: EventDetails): boolean;
    onEventCanBeCompleted({ eventTrigger, eventCanBeCompleted, caseDetails, form, submit }: CaseEditonEventCanBeCompleted): void;
    getStatus(response: object): any;
    private hasCallbackFailed;
    private eventMoreThanDayAgo;
    private eventDetailsDoNotMatch;
    private taskIsForEvent;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEditComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseEditComponent, "ccd-case-edit", never, { "eventTrigger": { "alias": "eventTrigger"; "required": false; }; "submit": { "alias": "submit"; "required": false; }; "validate": { "alias": "validate"; "required": false; }; "saveDraft": { "alias": "saveDraft"; "required": false; }; "caseDetails": { "alias": "caseDetails"; "required": false; }; }, { "cancelled": "cancelled"; "submitted": "submitted"; }, never, never, false, never>;
}

declare class CaseEditConfirmComponent {
    private readonly caseEdit;
    private readonly router;
    eventTrigger: CaseEventTrigger;
    triggerText: string;
    formGroup: FormControl<any>;
    confirmation: Confirmation;
    caseFields: CaseField[];
    editForm: FormGroup;
    constructor(caseEdit: CaseEditComponent, router: Router);
    submit(): void;
    getCaseId(): string;
    getCaseTitle(): string;
    private getCaseFields;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEditConfirmComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseEditConfirmComponent, "ng-component", never, {}, {}, never, never, false, never>;
}

declare class CaseEditFormComponent implements OnDestroy, AfterViewInit {
    private readonly formValueService;
    private readonly conditionalShowFormDirectives;
    fields: CaseField[];
    formGroup: FormGroup;
    caseFields: CaseField[];
    pageChangeSubject: Subject<boolean>;
    valuesChanged: EventEmitter<any>;
    initial: any;
    pageChangeSubscription: Subscription;
    formGroupChangeSubscription: Subscription;
    constructor(formValueService: FormValueService);
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    subscribeToFormChanges(): void;
    retrieveInitialFormValues(): void;
    detectChangesAndEmit(changes: any): void;
    syncConditionalShowStates(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEditFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseEditFormComponent, "ccd-case-edit-form", never, { "fields": { "alias": "fields"; "required": false; }; "formGroup": { "alias": "formGroup"; "required": false; }; "caseFields": { "alias": "caseFields"; "required": false; }; "pageChangeSubject": { "alias": "pageChangeSubject"; "required": false; }; }, { "valuesChanged": "valuesChanged"; }, never, never, false, never>;
}

declare class CaseEditPageComponent implements OnInit, AfterViewChecked, OnDestroy, JourneyInstigator {
    caseEdit: CaseEditComponent;
    private readonly route;
    private readonly formValueService;
    private readonly formErrorService;
    private readonly cdRef;
    private readonly pageValidationService;
    private readonly dialog;
    private readonly caseFieldService;
    private readonly caseEditDataService;
    private readonly loadingService;
    private readonly validPageListCaseFieldsService;
    private readonly multipageComponentStateService;
    private readonly addressService;
    private readonly linkedCasesService;
    private readonly caseFlagStateService;
    private readonly focusService;
    static readonly RESUMED_FORM_DISCARD = "RESUMED_FORM_DISCARD";
    static readonly NEW_FORM_DISCARD = "NEW_FORM_DISCARD";
    static readonly NEW_FORM_SAVE = "NEW_FORM_CHANGED_SAVE";
    static readonly RESUMED_FORM_SAVE = "RESUMED_FORM_SAVE";
    static readonly TRIGGER_TEXT_START = "Continue";
    static readonly TRIGGER_TEXT_SAVE = "Save and continue";
    static readonly TRIGGER_TEXT_CONTINUE = "Ignore Warning and Continue";
    eventTrigger: CaseEventTrigger;
    editForm: FormGroup;
    wizard: Wizard;
    currentPage: WizardPage;
    dialogConfig: MatDialogConfig;
    triggerTextStart: string;
    triggerTextIgnoreWarnings: string;
    triggerText: string;
    formValuesChanged: boolean;
    pageChangeSubject: Subject<boolean>;
    caseFields: CaseField[];
    failingCaseFields: CaseField[];
    validationErrors: CaseEditValidationError[];
    hasPreviousPage$: BehaviorSubject<boolean>;
    callbackErrorsSubject: Subject<any>;
    isLinkedCasesJourneyAtFinalStep: boolean;
    routeParamsSub: Subscription;
    caseEditFormSub: Subscription;
    caseIsLinkedCasesJourneyAtFinalStepSub: Subscription;
    caseTriggerSubmitEventSub: Subscription;
    validateSub: Subscription;
    dialogRefAfterClosedSub: Subscription;
    saveDraftSub: Subscription;
    caseFormValidationErrorsSub: Subscription;
    private readonly logger;
    private readonly caseEditFormComponents;
    private static scrollToTop;
    constructor(caseEdit: CaseEditComponent, route: ActivatedRoute, formValueService: FormValueService, formErrorService: FormErrorService, cdRef: ChangeDetectorRef, pageValidationService: PageValidationService, dialog: MatDialog, caseFieldService: CaseFieldService, caseEditDataService: CaseEditDataService, loadingService: LoadingService, validPageListCaseFieldsService: ValidPageListCaseFieldsService, multipageComponentStateService: MultipageComponentStateService, addressService: AddressesService, linkedCasesService: LinkedCasesService, caseFlagStateService: CaseFlagStateService, focusService: FocusService);
    onFinalNext(): void;
    onFinalPrevious(): void;
    getPageNumber(): number;
    isAtStart(): boolean;
    isAtEnd(): boolean;
    isDisabled(): boolean;
    nextStep(): void;
    previousStep(): void;
    ngOnInit(): void;
    ngAfterViewChecked(): void;
    ngOnDestroy(): void;
    applyValuesChanged(valuesChanged: boolean): void;
    first(): Promise<boolean>;
    currentPageIsNotValid(): boolean;
    isLinkedCasesJourney(): boolean;
    /**
     * caseEventData.event_data contains all the values from the previous pages so we set caseEventData.data = caseEventData.event_data
     * This builds the form with data from the previous pages
     * EUI-3732 - Breathing space data not persisted on Previous button click with ExpUI Demo
     */
    toPreviousPage(): void;
    generateErrorMessage(fields: CaseField[], container?: AbstractControl, path?: string, sourceFromComplexField?: boolean): boolean;
    navigateToErrorElement(elementId: string): void;
    checkForStagesCompleted(): void;
    submit(): void;
    updateFormData(jsonData: CaseEventData): void;
    pageWithFieldExists(caseFieldId: string): WizardPage;
    updateEventTriggerCaseFields(caseFieldId: string, jsonData: CaseEventData, eventTrigger: CaseEventTrigger): void;
    private updateJsonDataObject;
    private isAnObject;
    updateFormControlsValue(formGroup: FormGroup, caseFieldId: string, value: any): void;
    callbackErrorsNotify(errorContext: CallbackErrorsContext): void;
    next(): Promise<boolean>;
    previous(): Promise<boolean>;
    hasPrevious(): boolean;
    cancel(): void;
    resetLinkedCaseJourney(): void;
    submitting(): boolean;
    getCaseId(): string;
    getCaseTitle(): string;
    getCancelText(): string;
    private canNavigateToSummaryPage;
    private getTriggerText;
    private discard;
    private handleError;
    private resetErrors;
    private clearValidationErrors;
    private saveDraft;
    private getCaseFields;
    private getCaseFieldsFromCurrentAndPreviousPages;
    buildCaseEventData(fromPreviousPage?: boolean): CaseEventData;
    /**
     * Abstracted this method from buildCaseEventData to remove duplication.
     * @param caseFields The fields to filter the data by.
     * @param formValue The original value of the form.
     * @param clearEmpty Whether or not to clear out empty values.
     * @param clearNonCase Whether or not to clear out fields that are not part of the case.
     * @returns CaseEventData for the specified parameters.
     */
    private getFilteredCaseEventData;
    private syncCaseEditDataService;
    getRpxTranslatePipeArgs(fieldLabel: string): {
        FIELDLABEL: string;
    } | null;
    onEventCanBeCompleted(eventCanBeCompleted: boolean): void;
    private removeAllJudicialUserFormControls;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEditPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseEditPageComponent, "ccd-case-edit-page", never, {}, {}, never, never, false, never>;
}

declare class SessionErrorPageComponent {
    title: string;
    primaryMessage: string;
    secondaryMessage: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SessionErrorPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SessionErrorPageComponent, "ccd-session-error-page", never, { "title": { "alias": "title"; "required": false; }; "primaryMessage": { "alias": "primaryMessage"; "required": false; }; "secondaryMessage": { "alias": "secondaryMessage"; "required": false; }; }, {}, never, never, true, never>;
}

declare class OrderSummary {
    PaymentReference: string;
    Fees: FeeValue[];
    PaymentTotal: string;
}

/**
 * This mock file should be deleted after integrating with CCD
 * CCD development ticket: https://tools.hmcts.net/jira/browse/CCD-4590
 * ExUI tickets:
 *   https://tools.hmcts.net/jira/browse/EUI-8460
 *   https://tools.hmcts.net/jira/browse/EUI-8388
 *   https://tools.hmcts.net/jira/browse/EUI-8389
 */
declare const caseMessagesMockData: CaseQueriesCollection[];

declare class CaseEditSubmitComponent implements OnInit, OnDestroy {
    readonly caseEdit: CaseEditComponent;
    private readonly fieldsUtils;
    private readonly caseFieldService;
    private readonly route;
    private readonly orderService;
    private readonly profileNotifier;
    private readonly multipageComponentStateService;
    private readonly formValidatorsService;
    private readonly caseFlagStateService;
    private readonly linkedCasesService;
    private readonly placeholderService;
    eventTrigger: CaseEventTrigger;
    editForm: FormGroup;
    triggerText: string;
    wizard: Wizard;
    profile: Profile;
    showSummaryFields: CaseField[];
    paletteContext: PaletteContext;
    profileSubscription: Subscription;
    contextFields: CaseField[];
    task: Task;
    pageTitle: string;
    metadataFieldsObject: object;
    allFieldsValues: any;
    summary: AbstractControl;
    description: AbstractControl;
    eventSummaryLabel: string;
    eventDescriptionLabel: string;
    PLACEHOLDER_PATTERN: RegExp;
    static readonly SHOW_SUMMARY_CONTENT_COMPARE_FUNCTION: (a: CaseField, b: CaseField) => number;
    get isDisabled(): boolean;
    constructor(caseEdit: CaseEditComponent, fieldsUtils: FieldsUtils, caseFieldService: CaseFieldService, route: ActivatedRoute, orderService: OrderService, profileNotifier: ProfileNotifier, multipageComponentStateService: MultipageComponentStateService, formValidatorsService: FormValidatorsService, caseFlagStateService: CaseFlagStateService, linkedCasesService: LinkedCasesService, placeholderService: PlaceholderService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    submit(): void;
    onEventCanBeCompleted(eventCanBeCompleted: boolean): void;
    checkExistingDataInSubmission(): void;
    private getPageTitle;
    private get hasErrors();
    navigateToPage(pageId: string): void;
    callbackErrorsNotify(errorContext: CallbackErrorsContext): void;
    summaryCaseField(field: CaseField): CaseField;
    cancel(): void;
    private handleLinkedCasesSubmission;
    private getLinkedCasesTab;
    private emitCancelEvent;
    isLabel(field: CaseField): boolean;
    isChangeAllowed(field: CaseField): boolean;
    checkYourAnswerFieldsToDisplayExists(): boolean;
    readOnlySummaryFieldsToDisplayExists(): boolean;
    showEventNotes(): boolean;
    private getLastPageShown;
    previous(): void;
    hasPrevious(): boolean;
    isShown(page: WizardPage): boolean;
    canShowFieldInCYA(field: CaseField): boolean;
    private sortFieldsByShowSummaryContent;
    private getCaseFields;
    getCaseId(): string;
    getCaseTitle(): string;
    getCancelText(): string;
    private hasUnresolvedPlaceholder;
    private interpolateButtonText;
    private resolvePlaceholders;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEditSubmitComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseEditSubmitComponent, "ccd-case-edit-submit", never, {}, {}, never, never, false, never>;
}

declare class CaseProgressComponent implements OnInit {
    private readonly casesService;
    private readonly alertService;
    private readonly eventTriggerService;
    case: string;
    event: string;
    cancelled: EventEmitter<any>;
    submitted: EventEmitter<any>;
    caseDetails: CaseView;
    eventTrigger: CaseEventTrigger;
    constructor(casesService: CasesService, alertService: AlertService, eventTriggerService: EventTriggerService);
    ngOnInit(): void;
    submit(): (sanitizedEditForm: CaseEventData) => Observable<object>;
    validate(): (sanitizedEditForm: CaseEventData, pageId: string) => Observable<object>;
    emitCancelled(event: any): void;
    emitSubmitted(event: any): void;
    isDataLoaded(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseProgressComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseProgressComponent, "ccd-case-progress", never, { "case": { "alias": "case"; "required": false; }; "event": { "alias": "event"; "required": false; }; }, { "cancelled": "cancelled"; "submitted": "submitted"; }, never, never, false, never>;
}

declare class CaseEditGenericErrorsComponent {
    error: HttpError;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEditGenericErrorsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseEditGenericErrorsComponent, "ccd-case-edit-generic-errors", never, { "error": { "alias": "error"; "required": false; }; }, {}, never, never, false, never>;
}

declare class LoadingSpinnerComponent {
    loadingText: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingSpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoadingSpinnerComponent, "ccd-loading-spinner", never, { "loadingText": { "alias": "loadingText"; "required": false; }; }, {}, never, never, false, never>;
}

declare class LoadingSpinnerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingSpinnerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<LoadingSpinnerModule, [typeof LoadingSpinnerComponent], [typeof i2.CommonModule, typeof i7.RpxTranslationModule], [typeof LoadingSpinnerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<LoadingSpinnerModule>;
}

declare class CaseEditorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEditorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CaseEditorModule, [typeof CaseEditConfirmComponent, typeof CaseEditComponent, typeof CaseEditPageComponent, typeof CaseEditFormComponent, typeof CaseEditSubmitComponent, typeof CaseCreateComponent, typeof CaseProgressComponent, typeof CaseEditGenericErrorsComponent], [typeof i2.CommonModule, typeof i3.RouterModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof CaseEditDataModule, typeof LabelSubstitutorModule, typeof ConditionalShowModule, typeof ErrorsModule, typeof i16.PortalModule, typeof LoadingSpinnerModule, typeof BannersModule, typeof PaletteModule, typeof i7.RpxTranslationModule], [typeof CaseEditConfirmComponent, typeof CaseEditComponent, typeof CaseEditPageComponent, typeof CaseEditFormComponent, typeof CaseEditSubmitComponent, typeof CaseCreateComponent, typeof CaseProgressComponent, typeof CallbackErrorsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CaseEditorModule>;
}

declare const editorRouting: Routes;

declare class CaseAccessUtils {
    static readonly JUDGE_ROLE = "judge";
    static readonly JUDGE_ROLE_CATEGORY = "JUDICIAL";
    static readonly JUDGE_ROLE_NAME = "judiciary";
    static readonly ADMIN_ROLE = "admin";
    static readonly ADMIN_ROLE_CATEGORY = "ADMIN";
    static readonly ADMIN_ROLE_NAME = "admin";
    static readonly PROFESSIONAL_ROLE = "solicitor";
    static readonly PROFESSIONAL_ROLE_CATEGORY = "PROFESSIONAL";
    static readonly PROFESSIONAL_ROLE_NAME = "professional";
    static readonly LEGAL_OPERATIONS_ROLE = "caseworker";
    static readonly LEGAL_OPERATIONS_ROLE_CATEGORY = "LEGAL_OPERATIONS";
    static readonly LEGAL_OPERATIONS_ROLE_NAME = "legal-ops";
    static readonly CITIZEN_ROLE = "citizen";
    static readonly CITIZEN_ROLE_CATEGORY = "CITIZEN";
    static readonly CITIZEN_ROLE_NAME = "citizen";
    static readonly CTSC_ROLE = "ctsc";
    static readonly CTSC_ROLE_CATEGORY = "CTSC";
    static readonly CTSC_ROLE_NAME = "ctsc";
    getMappedRoleCategory(roles?: string[], roleCategories?: string[]): RoleCategory;
    roleOrCategoryExists(roleKeyword: string, roleCategory: string, roleKeywords: string[], roleCategories: string[]): boolean;
    getAMRoleName(accessType: string, aMRole: RoleCategory): string;
    getAMPayload(assignerId: string, actorId: string, roleName: string, roleCategory: RoleCategory, grantType: RoleGrantTypeCategory, caseId: string, details: ChallengedAccessRequest | SpecificAccessRequest, beginTime?: Date, endTime?: Date, isNew?: boolean): RoleRequestPayload;
}

declare class CaseHeaderComponent implements OnInit {
    caseDetails: CaseView;
    caseTitle: CaseField;
    caseFields: CaseField[];
    ngOnInit(): void;
    isDraft(): boolean;
    private getCaseFields;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseHeaderComponent, "ccd-case-header", never, { "caseDetails": { "alias": "caseDetails"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CaseHeaderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseHeaderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CaseHeaderModule, [typeof CaseHeaderComponent], [typeof i2.CommonModule, typeof i3.RouterModule, typeof PaletteModule], [typeof CaseHeaderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CaseHeaderModule>;
}

declare class DateTimeFormatUtils {
    static formatDateAtTime(date: Date, is24Hour: boolean): string;
    static formatTime(date: Date, is24Hour: boolean): string;
}
declare class CaseListComponent {
    private readonly browserService;
    classes: string;
    caption: string;
    firstCellIsHeader: boolean;
    cases: object[];
    tableConfig: TableConfig;
    selectionEnabled: boolean;
    selection: EventEmitter<any[]>;
    selectedCases: any[];
    currentPageNo: number;
    totalResultsCount?: number;
    pageSize?: number;
    pageChange: EventEmitter<any>;
    constructor(browserService: BrowserService);
    formatDate(date: Date): string;
    formatDateAtTime(date: Date): string;
    canBeShared(c: any): boolean;
    canAnyBeShared(): boolean;
    selectAll(): void;
    changeSelection(aCase: any): void;
    isSelected(aCase: any): boolean;
    allOnPageSelected(): boolean;
    onKeyUp($event: KeyboardEvent, aCase: any): void;
    goToPage(pageNumber: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseListComponent, "ccd-case-list", never, { "classes": { "alias": "classes"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "firstCellIsHeader": { "alias": "firstCellIsHeader"; "required": false; }; "cases": { "alias": "cases"; "required": false; }; "tableConfig": { "alias": "tableConfig"; "required": false; }; "selectionEnabled": { "alias": "selectionEnabled"; "required": false; }; "selectedCases": { "alias": "selectedCases"; "required": false; }; "currentPageNo": { "alias": "currentPageNo"; "required": false; }; "totalResultsCount": { "alias": "totalResultsCount"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; }, { "selection": "selection"; "pageChange": "pageChange"; }, never, never, false, never>;
}
declare class TableColumnConfig {
    header: string;
    key: string;
    type?: string;
    constructor();
}
declare class TableConfig {
    idField: string;
    columnConfigs: TableColumnConfig[];
    constructor();
}

declare class PaginationComponent {
    visibilityLabel: string;
    id: string;
    maxSize: number;
    previousLabel: string;
    nextLabel: string;
    screenReaderPaginationLabel: string;
    screenReaderPageLabel: string;
    screenReaderCurrentLabel: string;
    pageChange: EventEmitter<number>;
    pageBoundsCorrection: EventEmitter<number>;
    private pDirectionLinks;
    private pAutoHide;
    private pResponsive;
    get directionLinks(): boolean;
    set directionLinks(value: boolean);
    get autoHide(): boolean;
    set autoHide(value: boolean);
    get responsive(): boolean;
    set responsive(value: boolean);
    static ɵfac: i0.ɵɵFactoryDeclaration<PaginationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PaginationComponent, "ccd-pagination", never, { "visibilityLabel": { "alias": "visibilityLabel"; "required": false; }; "id": { "alias": "id"; "required": false; }; "maxSize": { "alias": "maxSize"; "required": false; }; "previousLabel": { "alias": "previousLabel"; "required": false; }; "nextLabel": { "alias": "nextLabel"; "required": false; }; "screenReaderPaginationLabel": { "alias": "screenReaderPaginationLabel"; "required": false; }; "screenReaderPageLabel": { "alias": "screenReaderPageLabel"; "required": false; }; "screenReaderCurrentLabel": { "alias": "screenReaderCurrentLabel"; "required": false; }; "directionLinks": { "alias": "directionLinks"; "required": false; }; "autoHide": { "alias": "autoHide"; "required": false; }; "responsive": { "alias": "responsive"; "required": false; }; }, { "pageChange": "pageChange"; "pageBoundsCorrection": "pageBoundsCorrection"; }, never, never, false, never>;
}

declare class PaginationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<PaginationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<PaginationModule, [typeof PaginationComponent], [typeof i2.CommonModule, typeof i3$2.NgxPaginationModule, typeof i7.RpxTranslationModule], [typeof PaginationComponent, typeof i3$2.PaginatePipe]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<PaginationModule>;
}

declare class CaseListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CaseListModule, [typeof CaseListComponent], [typeof i2.CommonModule, typeof i3$1.FormsModule, typeof i3.RouterModule, typeof i3$2.NgxPaginationModule, typeof PaginationModule, typeof i7.RpxTranslationModule], [typeof CaseListComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CaseListModule>;
}

declare class CaseListFiltersComponent implements OnInit {
    private readonly definitionsService;
    defaults: any;
    onApply: EventEmitter<any>;
    onReset: EventEmitter<any>;
    jurisdictions: Jurisdiction[];
    isVisible: boolean;
    constructor(definitionsService: DefinitionsService);
    ngOnInit(): void;
    onWrapperApply(value: any): void;
    onWrapperReset(value: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseListFiltersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseListFiltersComponent, "ccd-case-list-filters", never, { "defaults": { "alias": "defaults"; "required": false; }; }, { "onApply": "onApply"; "onReset": "onReset"; }, never, never, false, never>;
}

declare class WorkbasketFiltersComponent implements OnInit {
    private readonly route;
    private readonly workbasketInputFilterService;
    private readonly orderService;
    private readonly jurisdictionService;
    private readonly alertService;
    private readonly windowService;
    static readonly PARAM_JURISDICTION = "jurisdiction";
    static readonly PARAM_CASE_TYPE = "case-type";
    static readonly PARAM_CASE_STATE = "case-state";
    private readonly logger;
    caseFields: CaseField[];
    jurisdictions: Jurisdiction[];
    defaults: any;
    onApply: EventEmitter<any>;
    onReset: EventEmitter<any>;
    workbasketInputs: WorkbasketInputModel[];
    workbasketInputsReady: boolean;
    workbasketDefaults: boolean;
    selected: {
        init?: boolean;
        jurisdiction?: Jurisdiction;
        caseType?: CaseTypeLite;
        caseState?: CaseState;
        formGroup?: FormGroup;
        page?: number;
        metadataFields?: string[];
    };
    formGroup: FormGroup;
    selectedJurisdictionCaseTypes?: CaseTypeLite[];
    selectedCaseTypeStates?: CaseState[];
    initialised: boolean;
    constructor(route: ActivatedRoute, workbasketInputFilterService: WorkbasketInputFilterService, orderService: OrderService, jurisdictionService: JurisdictionService, alertService: AlertService, windowService: WindowService);
    scrollToTop(): void;
    private getDefaultJurisdiction;
    private getDefaultCaseType;
    ngOnInit(): void;
    apply(init: boolean): void;
    reset(): void;
    getMetadataFields(): string[];
    onJurisdictionIdChange(): void;
    onCaseTypeIdChange(): void;
    isCaseTypesDropdownDisabled(): boolean;
    isCaseStatesDropdownDisabled(): boolean;
    isApplyButtonDisabled(): boolean;
    isSearchableAndWorkbasketInputsReady(): boolean;
    /**
     * This method is used to clear the previously used
     * form group control filter values to make sure only the
     * currently selected form group control filter values are present.
     *
     * Has been implemented for 'Region and FRC filters' and can be extended
     * in future to incorporate other dynamic filters.
     */
    updateFormGroupFilters(): void;
    private sortStates;
    /**
     * Try to initialise filters based on query parameters or workbasket defaults.
     * Query parameters, when available, take precedence over workbasket defaults.
     */
    private initFilters;
    private selectCaseState;
    private selectCaseStateIdFromQueryOrDefaults;
    private selectCaseType;
    private selectCaseTypeIdFromQueryOrDefaults;
    private resetFieldsWhenNoDefaults;
    private clearWorkbasketInputs;
    private resetCaseState;
    private resetCaseType;
    private setFocusToTop;
    private getCaseFields;
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkbasketFiltersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WorkbasketFiltersComponent, "ccd-workbasket-filters", never, { "jurisdictions": { "alias": "jurisdictions"; "required": false; }; "defaults": { "alias": "defaults"; "required": false; }; }, { "onApply": "onApply"; "onReset": "onReset"; }, never, never, false, never>;
}

declare class WorkbasketFiltersModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<WorkbasketFiltersModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<WorkbasketFiltersModule, [typeof WorkbasketFiltersComponent], [typeof i2.CommonModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof PaletteModule, typeof ConditionalShowModule, typeof i7.RpxTranslationModule], [typeof WorkbasketFiltersComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<WorkbasketFiltersModule>;
}

declare class CaseListFiltersModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseListFiltersModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CaseListFiltersModule, [typeof CaseListFiltersComponent], [typeof i2.CommonModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof PaletteModule, typeof DefinitionsModule, typeof WorkbasketFiltersModule, typeof i7.RpxTranslationModule], [typeof CaseListFiltersComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CaseListFiltersModule>;
}

declare enum CaseTimelineDisplayMode {
    TIMELINE = 0,
    DETAILS = 1
}
declare class CaseTimelineComponent implements OnInit {
    private readonly caseNotifier;
    private readonly casesService;
    private readonly alertService;
    case: string;
    events: CaseViewEvent[];
    selectedEventId: string;
    dspMode: typeof CaseTimelineDisplayMode;
    displayMode: CaseTimelineDisplayMode;
    constructor(caseNotifier: CaseNotifier, casesService: CasesService, alertService: AlertService);
    ngOnInit(): void;
    isDataLoaded(): boolean;
    caseHistoryClicked(eventId: string): void;
    goToCaseTimeline(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseTimelineComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseTimelineComponent, "ccd-case-timeline", never, { "case": { "alias": "case"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CaseHistoryCaseType {
    id: string;
    name: string;
    description?: string;
    jurisdiction: Jurisdiction;
}
declare class CaseHistory {
    case_id?: string;
    caseType: CaseHistoryCaseType;
    tabs: CaseTab[];
    event: CaseViewEvent;
}

declare class CaseHistoryService {
    private readonly httpService;
    private readonly httpErrorService;
    private readonly appConfig;
    static readonly V2_MEDIATYPE_CASE_EVENT_VIEW = "application/vnd.uk.gov.hmcts.ccd-data-store-api.ui-event-view.v2+json;charset=UTF-8";
    constructor(httpService: HttpService, httpErrorService: HttpErrorService, appConfig: AbstractAppConfig);
    get(caseId: string, eventId: string): Observable<CaseHistory>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseHistoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CaseHistoryService>;
}

declare class CaseHistoryComponent implements OnInit, OnDestroy {
    private readonly route;
    private readonly alertService;
    private readonly orderService;
    private readonly caseNotifier;
    private readonly caseHistoryService;
    private readonly logger;
    static readonly PARAM_EVENT_ID = "eid";
    private static readonly ERROR_MESSAGE;
    event: string;
    caseHistory: CaseHistory;
    caseDetails: CaseView;
    tabs: CaseTab[];
    caseSubscription: Subscription;
    constructor(route: ActivatedRoute, alertService: AlertService, orderService: OrderService, caseNotifier: CaseNotifier, caseHistoryService: CaseHistoryService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    isDataLoaded(): boolean;
    private sortTabFieldsAndFilterTabs;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseHistoryComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseHistoryComponent, "ccd-case-history", never, { "event": { "alias": "event"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CaseHistoryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseHistoryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CaseHistoryModule, [typeof CaseHistoryComponent], [typeof i2.CommonModule, typeof i3.RouterModule, typeof CaseHeaderModule, typeof ConditionalShowModule, typeof PaletteModule, typeof LabelSubstitutorModule, typeof i7.RpxTranslationModule], [typeof CaseHistoryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CaseHistoryModule>;
}

declare class CaseTimelineModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseTimelineModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CaseTimelineModule, [typeof CaseTimelineComponent], [typeof i2.CommonModule, typeof ErrorsModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof CaseHistoryModule, typeof PaletteModule, typeof i7.RpxTranslationModule], [typeof CaseTimelineComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CaseTimelineModule>;
}

declare class CaseResolver implements Resolve<CaseView> {
    private caseNotifier;
    private draftService;
    private navigationNotifierService;
    private router;
    private sessionStorage;
    static readonly EVENT_REGEX: RegExp;
    static readonly PARAM_CASE_ID = "cid";
    static readonly CASE_CREATED_MSG = "The case has been created successfully";
    static readonly EVENT_ID_QM_RESPOND_TO_QUERY = "eventId=queryManagementRespondQuery";
    static defaultWAPage: string;
    static defaultPage: string;
    previousUrl: string;
    constructor(caseNotifier: CaseNotifier, draftService: DraftService, navigationNotifierService: NavigationNotifierService, router: Router, sessionStorage: SessionStorageService);
    resolve(route: ActivatedRouteSnapshot): Promise<CaseView>;
    private navigateToCaseList;
    private isRootCaseViewRoute;
    private isTabViewRoute;
    private getAndCacheCaseView;
    private getAndCacheDraft;
    private processErrorInCaseFetch;
    private goToDefaultPage;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CaseResolver>;
}

declare class EventTriggerResolver implements Resolve<CaseEventTrigger> {
    private readonly casesService;
    private readonly alertService;
    private readonly profileService;
    private readonly profileNotifier;
    private router;
    private appConfig;
    private errorNotifier;
    private readonly loadingService;
    private readonly sessionStorageService;
    static readonly PARAM_CASE_ID = "cid";
    static readonly PARAM_EVENT_ID = "eid";
    static readonly IGNORE_WARNING = "ignoreWarning";
    private static readonly IGNORE_WARNING_VALUES;
    private cachedEventTrigger;
    private cachedProfile;
    constructor(casesService: CasesService, alertService: AlertService, profileService: ProfileService, profileNotifier: ProfileNotifier, router: Router, appConfig: AbstractAppConfig, errorNotifier: ErrorNotifierService, loadingService: LoadingService, sessionStorageService: SessionStorageService);
    resolve(route: ActivatedRouteSnapshot): Promise<CaseEventTrigger>;
    private isRootTriggerEventRoute;
    resetCachedEventTrigger(): void;
    private getAndCacheEventTrigger;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventTriggerResolver, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EventTriggerResolver>;
}

declare class FieldsFilterPipe implements PipeTransform {
    private static readonly EMPTY_VALUES;
    private static readonly NESTED_TYPES;
    /**
     * Complex type should have at least on simple field descendant with a value.
     */
    private static isValidComplex;
    private static isEmpty;
    private static isCompound;
    private static isValidCompound;
    private static keepField;
    private static getValue;
    /**
     * Filter out fields having no data to display and harmonise field values coming parent's value.
     */
    transform(complexField: CaseField, keepEmpty?: boolean, index?: number, stripHidden?: boolean): CaseField[];
    static ɵfac: i0.ɵɵFactoryDeclaration<FieldsFilterPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<FieldsFilterPipe, "ccdFieldsFilter", false>;
}

declare class CaseEventTriggerComponent implements OnInit, OnDestroy {
    private readonly ngZone;
    private readonly casesService;
    private readonly caseNotifier;
    private readonly router;
    private readonly alertService;
    private readonly route;
    private readonly caseReferencePipe;
    private readonly activityPollingService;
    private readonly sessionStorageService;
    private readonly loadingService;
    private eventTriggerResolver;
    static readonly EVENT_COMPLETION_MESSAGE = "Case #%CASEREFERENCE% has been updated with event: %NAME%";
    static readonly CALLBACK_FAILED_MESSAGE = " but the callback service cannot be completed";
    BANNER: DisplayMode;
    eventTrigger: CaseEventTrigger;
    caseDetails: CaseView;
    activitySubscription: Subscription;
    caseSubscription: Subscription;
    parentUrl: string;
    routerCurrentNavigation: Navigation;
    constructor(ngZone: NgZone, casesService: CasesService, caseNotifier: CaseNotifier, router: Router, alertService: AlertService, route: ActivatedRoute, caseReferencePipe: CaseReferencePipe, activityPollingService: ActivityPollingService, sessionStorageService: SessionStorageService, loadingService: LoadingService, eventTriggerResolver: EventTriggerResolver);
    ngOnInit(): void;
    ngOnDestroy(): void;
    postEditActivity(): Observable<Activity[]>;
    submit(): (sanitizedEditForm: CaseEventData) => Observable<object>;
    validate(): (sanitizedEditForm: CaseEventData, pageId: string) => Observable<object>;
    submitted(event: any): void;
    private getNavigationUrl;
    cancel(): Promise<boolean>;
    isDataLoaded(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseEventTriggerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseEventTriggerComponent, "ccd-case-event-trigger", never, {}, {}, never, never, false, never>;
}

declare class CaseViewComponent implements OnInit, OnDestroy {
    private readonly navigationNotifierService;
    private readonly caseNotifier;
    private readonly casesService;
    private readonly draftService;
    private readonly alertService;
    case: string;
    hasPrint: boolean;
    hasEventSelector: boolean;
    navigationTriggered: EventEmitter<any>;
    navigationSubscription: Subscription;
    caseDetails: CaseView;
    constructor(navigationNotifierService: NavigationNotifierService, caseNotifier: CaseNotifier, casesService: CasesService, draftService: DraftService, alertService: AlertService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    isDataLoaded(): boolean;
    private getCaseView;
    private getDraft;
    private checkErrorGettingCaseView;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseViewComponent, "ccd-case-view", never, { "case": { "alias": "case"; "required": false; }; "hasPrint": { "alias": "hasPrint"; "required": false; }; "hasEventSelector": { "alias": "hasEventSelector"; "required": false; }; }, { "navigationTriggered": "navigationTriggered"; }, never, never, false, never>;
}

declare class CaseBasicAccessViewComponent implements OnInit, OnDestroy {
    private readonly casesService;
    private readonly router;
    static CANCEL_LINK_DESTINATION: string;
    caseDetails: CaseView;
    accessType: string;
    courtOrHearingCentre: string;
    showSpinner: boolean;
    private courtOrHearingCentreSubscription;
    constructor(casesService: CasesService, router: Router);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onCancel(): void;
    getRequestUrl(accessType: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseBasicAccessViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseBasicAccessViewComponent, "ccd-case-basic-access-view", never, { "caseDetails": { "alias": "caseDetails"; "required": false; }; "accessType": { "alias": "accessType"; "required": false; }; }, {}, never, never, false, never>;
}

declare class CaseFullAccessViewComponent implements OnInit, OnDestroy, OnChanges {
    private readonly ngZone;
    private readonly route;
    private readonly router;
    private readonly navigationNotifierService;
    private readonly orderService;
    private readonly activityPollingService;
    private readonly dialog;
    private readonly alertService;
    private readonly draftService;
    private readonly errorNotifierService;
    private readonly convertHrefToRouterService;
    private readonly location;
    private readonly crf;
    private readonly sessionStorageService;
    private readonly rpxTranslationPipe;
    private readonly loadingService;
    private readonly linkedCasesService;
    private readonly caseFlagStateService;
    private zone;
    static readonly ORIGIN_QUERY_PARAM = "origin";
    static readonly TRIGGER_TEXT_START = "Go";
    static readonly TRIGGER_TEXT_CONTINUE = "Ignore Warning and Go";
    static readonly UNICODE_SPACE = "%20";
    static readonly EMPTY_SPACE = " ";
    private readonly HEARINGS_TAB_LABEL;
    hasPrint: boolean;
    hasEventSelector: boolean;
    caseDetails: CaseView;
    prependedTabs: CaseTab[];
    appendedTabs: CaseTab[];
    BANNER: DisplayMode;
    sortedTabs: CaseTab[];
    caseFields: CaseField[];
    formGroup: FormGroup;
    error: any;
    triggerTextStart: string;
    triggerTextIgnoreWarnings: string;
    triggerText: string;
    ignoreWarning: boolean;
    activitySubscription: Subscription;
    caseSubscription: Subscription;
    errorSubscription: Subscription;
    dialogConfig: MatDialogConfig;
    message: string;
    subscription: Subscription;
    notificationBannerConfig: NotificationBannerConfig;
    selectedTabIndex: number;
    activeCaseFlags: boolean;
    caseFlagsExternalUser: boolean;
    private readonly caseFlagsReadExternalMode;
    private readonly potentiallyViolentPersonFlagPrefix;
    private subs;
    eventId: string;
    isEventButtonClicked: boolean;
    callbackErrorsSubject: Observable<any>;
    tabGroup: MatTabGroup;
    constructor(ngZone: NgZone, route: ActivatedRoute, router: Router, navigationNotifierService: NavigationNotifierService, orderService: OrderService, activityPollingService: ActivityPollingService, dialog: MatDialog, alertService: AlertService, draftService: DraftService, errorNotifierService: ErrorNotifierService, convertHrefToRouterService: ConvertHrefToRouterService, location: Location$1, crf: ChangeDetectorRef, sessionStorageService: SessionStorageService, rpxTranslationPipe: RpxTranslatePipe, loadingService: LoadingService, linkedCasesService: LinkedCasesService, caseFlagStateService: CaseFlagStateService, zone: NgZone);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    isPrintEnabled(): boolean;
    ngOnDestroy(): void;
    unsubscribe(subscription: any): void;
    private normalizeLabel;
    private getAbsoluteTabIndexByLabel;
    private selectTabByLabel;
    private checkRouteAndSetCaseViewTab;
    postViewActivity(): Observable<Activity[]>;
    clearErrorsAndWarnings(): void;
    applyTrigger(trigger: CaseViewTrigger): Promise<void>;
    hasTabsPresent(): boolean;
    callbackErrorsNotify(callbackErrorsContext: CallbackErrorsContext): void;
    isDraft(): boolean;
    isTriggerButtonDisabled(): boolean;
    organiseTabPosition(): void;
    findPreSelectedActiveTab(): CaseTab;
    tabChanged(tabIndexChanged: number): void;
    onLinkClicked(triggerOutputEventText: string): void;
    hasActiveCaseFlags(): boolean;
    private hasActivePotentiallyViolentPersonFlag;
    /**
     * Indicates that a CaseField is to be displayed without a label, as is expected for all ComponentLauncher-type
     * fields.
     * @param caseField The `CaseField` instance to check
     * @returns `true` if it should not have a label; `false` otherwise
     */
    isFieldToHaveNoLabel(caseField: CaseField): boolean;
    private init;
    private sortTabFieldsAndFilterTabs;
    private getTabFields;
    /**
     * For EUI-3825:
     * Builds a FormGroup from all the CaseFields contained within the view.
     * This FormGroup is necessary for evaluation the show/hide conditions of
     * fields that are dependent on a field only available on a DIFFERENT tab.
     */
    private buildFormGroup;
    private resetErrors;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseFullAccessViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseFullAccessViewComponent, "ccd-case-full-access-view", never, { "hasPrint": { "alias": "hasPrint"; "required": false; }; "hasEventSelector": { "alias": "hasEventSelector"; "required": false; }; "caseDetails": { "alias": "caseDetails"; "required": false; }; "prependedTabs": { "alias": "prependedTabs"; "required": false; }; "appendedTabs": { "alias": "appendedTabs"; "required": false; }; }, {}, never, never, false, never>;
}

declare class PrintUrlPipe implements PipeTransform {
    private readonly appConfig;
    private static readonly MSIE_BROWSER_NAME;
    private static readonly IE11_BROWSER_ENGINE;
    constructor(appConfig: AbstractAppConfig);
    /**
     * Takes a "remote" Print Service URL (for example, as returned by calling the `/documents` CCD endpoint) and
     * rewrites it into a "local", application-specific URL for the front-end. The resulting URL is of the form:
     *
     * Configurable "Local URL" (e.g. `/print`) + _pathname_ from original "remote URL"
     * (e.g. `/jurisdictions/TEST/case-types/Test1/cases/1111222233334444`)
     *
     * @param remoteUrl The "remote" URL to rewrite
     * @returns A rewritten URL as per the above description, or the original `remoteUrl` if it is `null`, `undefined`,
     * or the empty string
     */
    transform(remoteUrl: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PrintUrlPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<PrintUrlPipe, "ccdPrintUrl", false>;
}

declare class CasePrinterComponent implements OnInit, OnDestroy {
    private readonly caseNotifier;
    private readonly casesService;
    private readonly alertService;
    private readonly ERROR_MESSAGE;
    caseDetails: CaseView;
    documents: CasePrintDocument[];
    caseSubscription: Subscription;
    constructor(caseNotifier: CaseNotifier, casesService: CasesService, alertService: AlertService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    isDataLoaded(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<CasePrinterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CasePrinterComponent, "ng-component", never, {}, {}, never, never, false, never>;
}

declare class CaseViewerComponent implements OnInit, OnDestroy {
    private readonly route;
    private readonly caseNotifier;
    private readonly appConfig;
    private readonly orderService;
    static readonly METADATA_FIELD_ACCESS_PROCESS_ID = "[ACCESS_PROCESS]";
    static readonly METADATA_FIELD_ACCESS_GRANTED_ID = "[ACCESS_GRANTED]";
    static readonly NON_STANDARD_USER_ACCESS_TYPES: string[];
    static readonly BASIC_USER_ACCESS_TYPES = "BASIC";
    hasPrint: boolean;
    hasEventSelector: boolean;
    prependedTabs: CaseTab[];
    appendedTabs: CaseTab[];
    caseDetails: CaseView;
    caseSubscription: Subscription;
    userAccessType: string;
    accessGranted: boolean;
    constructor(route: ActivatedRoute, caseNotifier: CaseNotifier, appConfig: AbstractAppConfig, orderService: OrderService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    loadCaseDetails(): void;
    setUserAccessType(caseDetails: CaseView): void;
    isDataLoaded(): boolean;
    hasStandardAccess(): boolean;
    private suffixDuplicateTabs;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseViewerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseViewerComponent, "ccd-case-viewer", never, { "hasPrint": { "alias": "hasPrint"; "required": false; }; "hasEventSelector": { "alias": "hasEventSelector"; "required": false; }; "prependedTabs": { "alias": "prependedTabs"; "required": false; }; "appendedTabs": { "alias": "appendedTabs"; "required": false; }; }, {}, never, never, false, never>;
}

declare enum AccessReason$1 {
    LINKED_TO_CURRENT_CASE = "The cases or parties are linked to the case I am working on",
    CONSOLIDATE_CASE = "To determine if the case needs to be consolidated",
    ORDER_FOR_TRANSFER = "To consider an order for transfer",
    OTHER = "Other reason"
}

declare class CaseChallengedAccessRequestComponent implements OnDestroy, OnInit {
    private readonly fb;
    private readonly router;
    private readonly casesService;
    private readonly route;
    private readonly caseNotifier;
    static CANCEL_LINK_DESTINATION: string;
    title: string;
    hint: string;
    caseRefLabel: string;
    readonly accessReasons: DisplayedAccessReason$1[];
    formGroup: FormGroup;
    submitted: boolean;
    errorMessage: ErrorMessage;
    $roleAssignmentResponseSubscription: Subscription;
    private readonly genericError;
    private readonly radioSelectedControlName;
    private readonly caseReferenceControlName;
    private readonly otherReasonControlName;
    constructor(fb: FormBuilder, router: Router, casesService: CasesService, route: ActivatedRoute, caseNotifier: CaseNotifier);
    ngOnInit(): void;
    onChange(): void;
    onSubmit(): void;
    onCancel(): void;
    ngOnDestroy(): void;
    private inputEmpty;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseChallengedAccessRequestComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseChallengedAccessRequestComponent, "ccd-case-challenged-access-request", never, {}, {}, never, never, false, never>;
}
interface DisplayedAccessReason$1 {
    reason: AccessReason$1;
    checked: boolean;
}

declare class CaseSpecificAccessRequestComponent implements OnDestroy, OnInit {
    private readonly fb;
    private readonly router;
    private readonly casesService;
    private readonly route;
    private readonly caseNotifier;
    static CANCEL_LINK_DESTINATION: string;
    collapsed: boolean;
    title: string;
    hint: string;
    caseRefLabel: string;
    formGroup: FormGroup;
    submitted: boolean;
    errorMessage: ErrorMessage;
    $roleAssignmentResponseSubscription: Subscription;
    private readonly genericError;
    private readonly specificReasonControlName;
    getSpecificAccessError: boolean;
    constructor(fb: FormBuilder, router: Router, casesService: CasesService, route: ActivatedRoute, caseNotifier: CaseNotifier);
    ngOnInit(): void;
    onChange(): void;
    onSubmit(): void;
    onCancel(): void;
    ngOnDestroy(): void;
    private inputEmpty;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseSpecificAccessRequestComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseSpecificAccessRequestComponent, "ccd-case-specific-access-request", never, {}, {}, never, never, false, never>;
}

declare enum AccessReason {
    APPROVE_REQUEST = "Approve request",
    REJECT_REQUEST = "Reject request",
    REQUEST_MORE_INFORMATION = "Request more information"
}

declare class CaseReviewSpecificAccessRequestComponent implements OnInit, OnDestroy {
    private readonly fb;
    private readonly route;
    private readonly router;
    private readonly appConfig;
    static CANCEL_LINK_DESTINATION: string;
    collapsed: boolean;
    title: string;
    hint: string;
    caseRefLabel: string;
    formGroup: FormGroup;
    submitted: boolean;
    errorMessage: ErrorMessage;
    readonly accessReasons: DisplayedAccessReason[];
    requestAccessDetails: RequestAccessDetails;
    caseSubscription: Subscription;
    userAccessType: string;
    caseDetails: CaseView;
    private readonly genericError;
    private readonly radioSelectedControlName;
    constructor(fb: FormBuilder, route: ActivatedRoute, router: Router, appConfig: AbstractAppConfig);
    ngOnInit(): void;
    ngOnDestroy(): void;
    onChange(): void;
    onSubmit(): void;
    onCancel(): void;
    setMockData(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseReviewSpecificAccessRequestComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseReviewSpecificAccessRequestComponent, "ccd-case-review-specific-access-request", never, {}, {}, never, never, false, never>;
}
interface DisplayedAccessReason {
    reason: AccessReason;
    checked: boolean;
}
interface RequestAccessDetails {
    caseName: string;
    caseReference: string;
    dateSubmitted: string;
    requestFrom: string;
    reasonForCaseAccess: string;
}

declare class CaseChallengedAccessSuccessComponent implements OnInit {
    private readonly route;
    caseId: string;
    jurisdiction: string;
    caseType: string;
    constructor(route: ActivatedRoute);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseChallengedAccessSuccessComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseChallengedAccessSuccessComponent, "ccd-case-challenged-access-success", never, {}, {}, never, never, false, never>;
}

declare class CaseSpecificAccessSuccessComponent implements OnInit {
    private readonly route;
    caseId: string;
    constructor(route: ActivatedRoute);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseSpecificAccessSuccessComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseSpecificAccessSuccessComponent, "ccd-case-specific-access-success", never, {}, {}, never, never, false, never>;
}

declare class CaseReviewSpecificAccessRejectComponent implements OnInit {
    private readonly route;
    caseId: string;
    jurisdiction: string;
    caseType: string;
    readonly retunToTask = "Return to the Tasks tab for this case";
    readonly returnToMyTask = "Return to My tasks";
    constructor(route: ActivatedRoute);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseReviewSpecificAccessRejectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CaseReviewSpecificAccessRejectComponent, "case-review-specific-access-reject", never, {}, {}, never, never, false, never>;
}

interface EventStartStateMachineContext {
    tasks: Task[];
    caseId: string;
    eventId: string;
    taskId: string;
    router: Router;
    route: ActivatedRoute;
    sessionStorageService: SessionStorageService;
    cookieService: ReadCookieService;
}

declare class EventStartStateMachineService {
    private readonly abstractConfig;
    stateCheckForMatchingTasks: State;
    stateNoTask: State;
    stateOneTask: State;
    stateOneOrMoreTasks: State;
    stateTaskAssignedToUser: State;
    stateOneTaskAssignedToUser: State;
    stateMultipleTasksAssignedToUser: State;
    stateTaskUnassigned: State;
    stateFinal: State;
    constructor(abstractConfig: AbstractAppConfig);
    initialiseStateMachine(context: EventStartStateMachineContext): StateMachine;
    createStates(stateMachine: StateMachine): void;
    addTransitions(): void;
    startStateMachine(stateMachine: StateMachine): void;
    /**
     * Initial entry action for state check for matching tasks, decided based on the number of tasks
     */
    entryActionForStateCheckForMatchingTasks(state: State, context: EventStartStateMachineContext): void;
    entryActionForStateNoTask(state: State, context: EventStartStateMachineContext): void;
    entryActionForStateOneOrMoreTasks(state: State, context: EventStartStateMachineContext): void;
    entryActionForStateMultipleTasks(state: State, context: EventStartStateMachineContext): void;
    entryActionForStateTaskAssignedToUser(state: State, context: EventStartStateMachineContext): void;
    entryActionForStateTaskUnAssigned(state: State, context: EventStartStateMachineContext): void;
    entryActionForStateOneTaskAssignedToUser: (state: State, context: EventStartStateMachineContext) => void;
    entryActionForStateMultipleTasksAssignedToUser(state: State, context: EventStartStateMachineContext): void;
    finalAction(state: State): void;
    addTransitionsForStateCheckForMatchingTasks(): void;
    addTransitionsForStateNoTask(): void;
    addTransitionsForStateOneOrMoreTasks(): void;
    addTransitionsForStateTaskUnassigned(): void;
    addTransitionsForStateTaskAssignedToUser(): void;
    addTransitionsForStateOneTaskAssignedToUser(): void;
    addTransitionsForStateMultipleTasksAssignedToUser(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventStartStateMachineService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EventStartStateMachineService>;
}

declare class EventStartComponent implements OnInit {
    private service;
    private readonly router;
    private readonly route;
    private readonly sessionStorageService;
    private readonly cookieService;
    private readonly abstractConfig;
    stateMachine: StateMachine;
    context: EventStartStateMachineContext;
    constructor(service: EventStartStateMachineService, router: Router, route: ActivatedRoute, sessionStorageService: SessionStorageService, cookieService: ReadCookieService, abstractConfig: AbstractAppConfig);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventStartComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EventStartComponent, "ccd-event-start", never, {}, {}, never, never, false, never>;
}

declare class MultipleTasksExistComponent implements OnInit {
    private readonly route;
    private readonly loadingService;
    caseId: string;
    jurisdiction: string;
    caseType: string;
    constructor(route: ActivatedRoute, loadingService: LoadingService);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MultipleTasksExistComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MultipleTasksExistComponent, "app-multiple-tasks-exist", never, {}, {}, never, never, false, never>;
}

declare class NoTasksAvailableComponent {
    private readonly route;
    caseId: string;
    jurisdiction: string;
    caseType: string;
    constructor(route: ActivatedRoute);
    static ɵfac: i0.ɵɵFactoryDeclaration<NoTasksAvailableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NoTasksAvailableComponent, "app-no-tasks-available", never, {}, {}, never, never, false, never>;
}

declare class TaskAssignedComponent implements OnInit, OnDestroy {
    private readonly route;
    private readonly judicialworkerService;
    private readonly caseworkerService;
    task: Task;
    caseId: string;
    jurisdiction: string;
    caseType: string;
    assignedUserName: string;
    caseworkerSubscription: Subscription;
    judicialworkerSubscription: Subscription;
    constructor(route: ActivatedRoute, judicialworkerService: JudicialworkerService, caseworkerService: CaseworkerService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TaskAssignedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TaskAssignedComponent, "app-task-assigned", never, {}, {}, never, never, false, never>;
}

declare class TaskCancelledComponent {
    caseId: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TaskCancelledComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TaskCancelledComponent, "app-task-cancelled", never, { "caseId": { "alias": "caseId"; "required": false; }; }, {}, never, never, false, never>;
}

declare class TaskConflictComponent {
    task: Task;
    caseId: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TaskConflictComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TaskConflictComponent, "app-task-conflict", never, { "task": { "alias": "task"; "required": false; }; "caseId": { "alias": "caseId"; "required": false; }; }, {}, never, never, false, never>;
}

declare class TaskUnassignedComponent {
    private readonly route;
    caseId: string;
    jurisdiction: string;
    caseType: string;
    constructor(route: ActivatedRoute);
    static ɵfac: i0.ɵɵFactoryDeclaration<TaskUnassignedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TaskUnassignedComponent, "app-task-unassigned", never, {}, {}, never, never, false, never>;
}

declare class EventStartModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EventStartModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EventStartModule, [typeof EventStartComponent, typeof MultipleTasksExistComponent, typeof NoTasksAvailableComponent, typeof TaskAssignedComponent, typeof TaskCancelledComponent, typeof TaskConflictComponent, typeof TaskUnassignedComponent], [typeof i2.CommonModule, typeof i3$1.ReactiveFormsModule, typeof i3.RouterModule, typeof i7.RpxTranslationModule], [typeof EventStartComponent, typeof TaskAssignedComponent, typeof TaskUnassignedComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EventStartModule>;
}

declare class EventTriggerComponent implements OnChanges, OnInit {
    private readonly appConfig;
    private readonly fb;
    private readonly orderService;
    triggers: CaseViewTrigger[];
    triggerText: string;
    isDisabled: boolean;
    eventId: string;
    onTriggerSubmit: EventEmitter<CaseViewTrigger>;
    onTriggerChange: EventEmitter<any>;
    triggerForm: FormGroup;
    constructor(appConfig: AbstractAppConfig, fb: FormBuilder, orderService: OrderService);
    ngOnInit(): void;
    ngOnChanges(changes?: SimpleChanges): void;
    compareFn(c1: CaseViewTrigger, c2: CaseViewTrigger): boolean;
    isButtonDisabled(): boolean;
    triggerSubmit(): void;
    triggerChange(): void;
    private getDefault;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventTriggerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EventTriggerComponent, "ccd-event-trigger", never, { "triggers": { "alias": "triggers"; "required": false; }; "triggerText": { "alias": "triggerText"; "required": false; }; "isDisabled": { "alias": "isDisabled"; "required": false; }; "eventId": { "alias": "eventId"; "required": false; }; }, { "onTriggerSubmit": "onTriggerSubmit"; "onTriggerChange": "onTriggerChange"; }, never, never, false, never>;
}

declare class EventTriggerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EventTriggerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EventTriggerModule, [typeof EventTriggerComponent], [typeof i2.CommonModule, typeof i3$1.ReactiveFormsModule, typeof ActivityModule, typeof i7.RpxTranslationModule], [typeof EventTriggerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EventTriggerModule>;
}

declare class ErrorMessageComponent {
    error: ErrorMessage;
    static ɵfac: i0.ɵɵFactoryDeclaration<ErrorMessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ErrorMessageComponent, "exui-error-message", never, { "error": { "alias": "error"; "required": false; }; }, {}, never, never, false, never>;
}

declare class EventMessageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<EventMessageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<EventMessageModule, [typeof ErrorMessageComponent], [typeof i2.CommonModule, typeof i3$1.ReactiveFormsModule, typeof i3.RouterModule, typeof ActivityModule, typeof i7.RpxTranslationModule], [typeof ErrorMessageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<EventMessageModule>;
}

declare class CaseViewerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CaseViewerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CaseViewerModule, [typeof CaseEventTriggerComponent, typeof CasePrinterComponent, typeof CaseViewerComponent, typeof CaseFullAccessViewComponent, typeof CaseViewComponent, typeof CaseBasicAccessViewComponent, typeof PrintUrlPipe, typeof CaseChallengedAccessRequestComponent, typeof CaseSpecificAccessRequestComponent, typeof CaseReviewSpecificAccessRequestComponent, typeof CaseChallengedAccessSuccessComponent, typeof CaseSpecificAccessSuccessComponent, typeof CaseReviewSpecificAccessRejectComponent], [typeof i2.CommonModule, typeof i3.RouterModule, typeof ErrorsModule, typeof ActivityModule, typeof CaseHeaderModule, typeof EventStartModule, typeof EventTriggerModule, typeof PaletteModule, typeof CaseEditorModule, typeof ConditionalShowModule, typeof CaseHistoryModule, typeof i25.MatTabsModule, typeof i3$1.ReactiveFormsModule, typeof AlertModule, typeof LabelSubstitutorModule, typeof i7.RpxTranslationModule, typeof BannersModule, typeof LabelSubstitutorModule, typeof LoadingSpinnerModule, typeof EventMessageModule], [typeof CaseViewerComponent, typeof CaseViewComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CaseViewerModule>;
}

declare const viewerRouting: Routes;

declare class CreateCaseFiltersSelection {
    jurisdictionId: string;
    caseTypeId: string;
    eventId: string;
    constructor();
}

declare class CreateCaseFiltersComponent implements OnInit {
    private readonly orderService;
    private readonly definitionsService;
    private readonly sessionStorageService;
    private readonly jurisdictionService;
    isDisabled: boolean;
    startButtonText: string;
    selectionSubmitted: EventEmitter<CreateCaseFiltersSelection>;
    selectionChanged: EventEmitter<any>;
    formGroup: FormGroup;
    selected: {
        jurisdiction?: Jurisdiction;
        caseType?: CaseTypeLite;
        event?: CaseEvent;
        formGroup?: FormGroup;
    };
    jurisdictions: Jurisdiction[];
    selectedJurisdictionCaseTypes?: CaseTypeLite[];
    selectedCaseTypeEvents?: CaseEvent[];
    filterJurisdictionControl: FormControl;
    filterCaseTypeControl: FormControl;
    filterEventControl: FormControl;
    constructor(orderService: OrderService, definitionsService: DefinitionsService, sessionStorageService: SessionStorageService, jurisdictionService: JurisdictionService);
    ngOnInit(): void;
    onJurisdictionIdChange(): void;
    onCaseTypeIdChange(): void;
    onEventIdChange(): void;
    isCreatable(): boolean;
    apply(): void;
    initControls(): void;
    emitChange(): void;
    private sortEvents;
    private retainEventsWithNoPreStates;
    private retainEventsWithCreateRights;
    private hasCreateAccess;
    private selectJurisdiction;
    private selectCaseType;
    private selectEvent;
    private findJurisdiction;
    private findCaseType;
    private findEvent;
    private resetCaseType;
    private resetEvent;
    private isEmpty;
    static ɵfac: i0.ɵɵFactoryDeclaration<CreateCaseFiltersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CreateCaseFiltersComponent, "ccd-create-case-filters", never, { "isDisabled": { "alias": "isDisabled"; "required": false; }; "startButtonText": { "alias": "startButtonText"; "required": false; }; }, { "selectionSubmitted": "selectionSubmitted"; "selectionChanged": "selectionChanged"; }, never, never, false, never>;
}

declare class CreateCaseFiltersModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<CreateCaseFiltersModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<CreateCaseFiltersModule, [typeof CreateCaseFiltersComponent], [typeof i2.CommonModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof DefinitionsModule, typeof ErrorsModule, typeof i7.RpxTranslationModule], [typeof CreateCaseFiltersComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<CreateCaseFiltersModule>;
}

declare class DeleteOrCancelDialogComponent {
    private readonly matDialogRef;
    result: string;
    constructor(matDialogRef: MatDialogRef<DeleteOrCancelDialogComponent>);
    delete(): void;
    cancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeleteOrCancelDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeleteOrCancelDialogComponent, "ccd-delete-or-cancel-dialog", never, {}, {}, never, never, false, never>;
}

declare class DocumentDialogComponent implements OnInit {
    private readonly matDialogRef;
    result: string;
    constructor(matDialogRef: MatDialogRef<DocumentDialogComponent>);
    ngOnInit(): void;
    replace(): void;
    cancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentDialogComponent, "ccd-document-dialog", never, {}, {}, never, never, false, never>;
}

declare class RemoveDialogComponent {
    private readonly matDialogRef;
    result: string;
    constructor(matDialogRef: MatDialogRef<RemoveDialogComponent>);
    remove(): void;
    cancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RemoveDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RemoveDialogComponent, "ccd-remove-dialog", never, {}, {}, never, never, false, never>;
}

declare class SaveOrDiscardDialogComponent {
    private readonly matDialogRef;
    result: string;
    constructor(matDialogRef: MatDialogRef<SaveOrDiscardDialogComponent>);
    cancel(): void;
    save(): void;
    discard(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SaveOrDiscardDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SaveOrDiscardDialogComponent, "ccd-save-or-discard-dialog", never, {}, {}, never, never, false, never>;
}

declare class DialogsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DialogsModule, [typeof DocumentDialogComponent, typeof DeleteOrCancelDialogComponent, typeof SaveOrDiscardDialogComponent, typeof RemoveDialogComponent], [typeof i2.CommonModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof i7.RpxTranslationModule], [typeof DocumentDialogComponent, typeof DeleteOrCancelDialogComponent, typeof SaveOrDiscardDialogComponent, typeof RemoveDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DialogsModule>;
}

declare function initDialog(): MatDialogConfig;

declare class SearchResultComponent implements OnChanges, OnInit {
    private readonly activityService;
    private readonly caseReferencePipe;
    private readonly placeholderService;
    private readonly browserService;
    private readonly sessionStorageService;
    static readonly PARAM_JURISDICTION = "jurisdiction";
    static readonly PARAM_CASE_TYPE = "case-type";
    static readonly PARAM_CASE_STATE = "case-state";
    private readonly PAGINATION_MAX_ITEM_RESULT;
    ICON: DisplayMode;
    caseLinkUrlTemplate: string;
    jurisdiction: Jurisdiction;
    caseType: CaseType;
    caseState: CaseState;
    caseFilterFG: FormGroup;
    resultView: SearchResultView;
    page: number;
    paginationMetadata: PaginationMetadata;
    metadataFields: string[];
    selectionEnabled: boolean;
    showOnlySelected: boolean;
    preSelectedCases: SearchResultViewItem[];
    consumerSortingEnabled: boolean;
    selection: EventEmitter<SearchResultViewItem[]>;
    changePage: EventEmitter<any>;
    clickCase: EventEmitter<any>;
    sortHandler: EventEmitter<any>;
    paginationLimitEnforced: boolean;
    paginationPageSize: number;
    hideRows: boolean;
    selected: {
        init?: boolean;
        jurisdiction?: Jurisdiction;
        caseType?: CaseType;
        caseState?: CaseState;
        formGroup?: FormGroup;
        metadataFields?: string[];
        page?: number;
    };
    sortParameters: SortParameters;
    searchResultViewItemComparatorFactory: SearchResultViewItemComparatorFactory;
    draftsCount: number;
    consumerSortParameters: {
        column: string;
        order: SortOrder$1;
        type: string;
    };
    selectedCases: SearchResultViewItem[];
    constructor(searchResultViewItemComparatorFactory: SearchResultViewItemComparatorFactory, appConfig: AbstractAppConfig, activityService: ActivityService, caseReferencePipe: CaseReferencePipe, placeholderService: PlaceholderService, browserService: BrowserService, sessionStorageService: SessionStorageService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    isTranslatable(col: SearchResultViewColumn): boolean;
    get resultTotal(): number;
    clearSelection(): void;
    canBeShared(caseView: SearchResultViewItem): boolean;
    canAnyBeShared(): boolean;
    selectAll(): void;
    changeSelection(c: SearchResultViewItem): void;
    isSelected(c: SearchResultViewItem): boolean;
    allOnPageSelected(): boolean;
    /**
     * Hydrates result view with case field definitions.
     */
    hydrateResultView(): void;
    goToPage(page: any): void;
    buildCaseField(col: SearchResultViewColumn, result: SearchResultViewItem): CaseField;
    getColumnsWithPrefix(col: CaseField, result: SearchResultViewItem): CaseField;
    hasResults(): any;
    hasDrafts(): boolean;
    comparator(column: SearchResultViewColumn): SearchResultViewItemComparator;
    sort(column: SearchResultViewColumn): void;
    sortWidget(column: SearchResultViewColumn): "&#9660;" | "&#9650;";
    activityEnabled(): boolean;
    hyphenateIfCaseReferenceOrGet(col: any, result: any): any;
    draftPrefixOrGet(col: any, result: any): any;
    isSortAscending(column: SearchResultViewColumn): boolean;
    getFirstResult(): number;
    getLastResult(): number;
    getTotalResults(): number;
    prepareCaseLinkUrl(caseId: string): string;
    private getDraftsCountIfNotPageOne;
    private numberOfDrafts;
    goToCase(caseId: string): void;
    onKeyUp($event: KeyboardEvent, c: SearchResultViewItem): void;
    noop(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchResultComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchResultComponent, "ccd-search-result", never, { "caseLinkUrlTemplate": { "alias": "caseLinkUrlTemplate"; "required": false; }; "jurisdiction": { "alias": "jurisdiction"; "required": false; }; "caseType": { "alias": "caseType"; "required": false; }; "caseState": { "alias": "caseState"; "required": false; }; "caseFilterFG": { "alias": "caseFilterFG"; "required": false; }; "resultView": { "alias": "resultView"; "required": false; }; "page": { "alias": "page"; "required": false; }; "paginationMetadata": { "alias": "paginationMetadata"; "required": false; }; "metadataFields": { "alias": "metadataFields"; "required": false; }; "selectionEnabled": { "alias": "selectionEnabled"; "required": false; }; "showOnlySelected": { "alias": "showOnlySelected"; "required": false; }; "preSelectedCases": { "alias": "preSelectedCases"; "required": false; }; "consumerSortingEnabled": { "alias": "consumerSortingEnabled"; "required": false; }; }, { "selection": "selection"; "changePage": "changePage"; "clickCase": "clickCase"; "sortHandler": "sortHandler"; }, never, never, false, never>;
}

declare class SearchResultModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchResultModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SearchResultModule, [typeof SearchResultComponent], [typeof i2.CommonModule, typeof i3$2.NgxPaginationModule, typeof i3.RouterModule, typeof i3$1.FormsModule, typeof i3$1.ReactiveFormsModule, typeof LabelSubstitutorModule, typeof PipesModule, typeof ActivityModule, typeof PaginationModule, typeof i7.RpxTranslationModule, typeof PaletteModule], [typeof SearchResultComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SearchResultModule>;
}

declare class CaseFieldBuilder {
    private readonly caseField;
    static create(): CaseFieldBuilder;
    withACLs(acls: AccessControlList[]): CaseFieldBuilder;
    withId(id: string): CaseFieldBuilder;
    withFieldType(fieldType: FieldType): CaseFieldBuilder;
    withDisplayContext(displayContext: string): CaseFieldBuilder;
    withDisplayContextParameter(displayContextParameter: string): CaseFieldBuilder;
    withHidden(hidden: boolean): CaseFieldBuilder;
    withHintText(hintText: string): CaseFieldBuilder;
    withLabel(label: string): CaseFieldBuilder;
    withOrder(order: number): CaseFieldBuilder;
    withSecurityLabel(securityLabel: string): CaseFieldBuilder;
    withShowCondition(showCondition: string): CaseFieldBuilder;
    withShowSummaryContentOption(option: number): CaseFieldBuilder;
    withValue(value: any): CaseFieldBuilder;
    withListValue(value: any): CaseFieldBuilder;
    build(): CaseField;
}

declare const textFieldType: () => FieldType;
declare const createCaseEventTrigger: (id: string, name: string, caseId: string, showSummary: boolean, caseFields: CaseField[], wizardPages?: any[], canSaveDraft?: boolean) => CaseEventTrigger;
declare const aCaseField: (id: string, label: string, type: FieldTypeEnum, displayContext: string, showSummaryContentOption: number, typeComplexFields?: CaseField[], retainHiddenValue?: boolean, hidden?: boolean) => CaseField;
declare const createWizardPage: (id: string, label: string, order: number, wizardPageFields: WizardPageField[], caseFields: CaseField[], showCondition: string, parsedShowCondition?: ShowCondition) => WizardPage;
declare const createWizardPageField: (id: string, order: number, pageColumnNumber: number, complexFieldOverrides?: ComplexFieldOverride[]) => WizardPageField;
declare const createComplexFieldOverride: (id: string, order: number, displayContext: string, label: string, hint: string, showCondition: string) => ComplexFieldOverride;
declare const createHiddenComplexFieldOverride: (id: string) => ComplexFieldOverride;
declare const createCaseField: (id: string, label: string, hint: string, fieldType: FieldType, displayContext: string, order?: any, showCondition?: any, acls?: AccessControlList[], hidden?: boolean) => CaseField;
declare const newCaseField: (id: string, label: string, hint: string, fieldType: FieldType, displayContext: string, order?: any) => CaseFieldBuilder;
declare const createFieldType: (typeId: string, type: FieldTypeEnum, complexFields?: CaseField[], collectionFieldType?: FieldType) => FieldType;
declare const createFixedListFieldType: (typeId: string, fixedListItems?: FixedListItem[]) => FieldType;
declare const createMultiSelectListFieldType: (typeId: string, fixedListItems?: FixedListItem[]) => FieldType;
declare const createACL: (role: string, aclCreate: boolean, aclRead: boolean, aclUpdate: boolean, aclDelete: boolean) => AccessControlList;

declare class TestRouteSnapshotBuilder {
    private parent;
    private params;
    private data;
    withParent(parent: ActivatedRouteSnapshot): TestRouteSnapshotBuilder;
    withParams(params: object): TestRouteSnapshotBuilder;
    withData(data: object): TestRouteSnapshotBuilder;
    build(): ActivatedRouteSnapshot;
}

declare function safeJsonParse<T>(value: string | null, fallback?: T | null): T | null;

export { AbstractAppConfig, AbstractFieldReadComponent, AbstractFieldWriteComponent, AbstractFieldWriteJourneyComponent, AbstractJourneyComponent, Activity, ActivityBannerComponent, ActivityComponent, ActivityIconComponent, ActivityInfo, ActivityModule, ActivityPollingService, ActivityService, AddCommentsComponent, AddCommentsErrorMessage, AddCommentsStep, AddressModel, AddressOption, AddressesService, Alert, AlertComponent, AlertIconClassPipe, AlertMessageType, AlertModule, AlertService, AuthService, Banner, BannersService, BeforeYouStartComponent, BodyComponent, BrowserService, CCDCaseLinkType, COMPONENT_PORTAL_INJECTION_TOKEN, CallbackErrorsComponent, CallbackErrorsContext, CaseAccessUtils, CaseBasicAccessViewComponent, CaseChallengedAccessRequestComponent, CaseChallengedAccessSuccessComponent, CaseCreateComponent, CaseDetails, CaseEditComponent, CaseEditConfirmComponent, CaseEditDataModule, CaseEditDataService, CaseEditFormComponent, CaseEditPageComponent, CaseEditSubmitComponent, CaseEditWizardGuard, CaseEditorConfig, CaseEditorModule, CaseEvent, CaseEventCompletionComponent, CaseEventCompletionTaskCancelledComponent, CaseEventCompletionTaskReassignedComponent, CaseEventData, CaseEventTrigger, CaseEventTriggerComponent, CaseField, CaseFieldService, CaseFileViewFieldComponent, CaseFileViewFolderComponent, CaseFileViewFolderDocumentActionsComponent, CaseFileViewFolderSelectorComponent, CaseFileViewFolderSortComponent, CaseFileViewFolderToggleComponent, CaseFileViewOverlayMenuComponent, CaseFileViewService, CaseFlagCheckYourAnswersPageStep, CaseFlagDisplayContextParameter, CaseFlagErrorMessage, CaseFlagFieldState, CaseFlagFormFields, CaseFlagRefdataService, CaseFlagStatus, CaseFlagSummaryListComponent, CaseFlagSummaryListDisplayMode, CaseFlagTableComponent, CaseFlagWizardStepTitle, CaseFullAccessViewComponent, CaseHeaderComponent, CaseHeaderModule, CaseHistoryViewerFieldComponent, CaseLink, CaseLinkResponse, CaseListComponent, CaseListFiltersComponent, CaseListFiltersModule, CaseListModule, CaseNotifier, CasePaymentHistoryViewerFieldComponent, CasePrintDocument, CasePrinterComponent, CaseProgressComponent, CaseReferencePipe, CaseResolver, CaseSpecificAccessRequestComponent, CaseSpecificAccessSuccessComponent, CaseState, CaseTab, CaseTimelineComponent, CaseTimelineDisplayMode, CaseTimelineModule, CaseType, CaseTypeLite, CaseView, CaseViewComponent, CaseViewEvent, CaseViewTrigger, CaseViewerComponent, CaseViewerModule, CasesService, CaseworkerService, CcdCYAPageLabelFilterPipe, CcdCaseTitlePipe, CcdCollectionTableCaseFieldsFilterPipe, CcdPageFieldsPipe, CcdTabFieldsPipe, CheckYourAnswersComponent, CloseQueryComponent, ConditionalShowFormDirective, ConditionalShowModule, ConditionalShowRegistrarService, ConfirmFlagStatusComponent, ConfirmStatusErrorMessage, ConfirmStatusStep, Confirmation, ConvertHrefToRouterService, CreateCaseFiltersComponent, CreateCaseFiltersModule, CreateCaseFiltersSelection, DRAFT_PREFIX, DRAFT_QUERY_PARAM, DashPipe, DateInputComponent, DatePipe, DateTimeFormatUtils, DatetimePickerComponent, DefinitionsModule, DefinitionsService, DeleteOrCancelDialogComponent, DialogsModule, DisplayMode, Document, DocumentData, DocumentDialogComponent, DocumentLinks, DocumentManagementService, DocumentUrlPipe, Draft, DraftService, DynamicListPipe, DynamicRadioListPipe, ESQueryType, Embedded, EnumDisplayDescriptionPipe, ErrorMessageComponent, ErrorNotifierService, EventCaseField, EventCompletionReturnStates, EventCompletionStateMachineService, EventCompletionStates, EventLogComponent, EventLogDetailsComponent, EventLogTableComponent, EventMessageModule, EventStartComponent, EventStartModule, EventStartStateMachineService, EventStatusService, EventTriggerResolver, EventTriggerService, Fee, FeeValue, Field, FieldLabelPipe, FieldReadComponent, FieldReadLabelComponent, FieldType, FieldTypeSanitiser, FieldWriteComponent, FieldsFilterPipe, FieldsPurger, FieldsUtils, FirstErrorPipe, FixedListItem, FixedListPipe, FixedRadioListPipe, FlagFieldDisplayPipe, FocusElementDirective, FocusElementModule, FocusService, FooterComponent, FormDocument, FormErrorService, FormValidatorsService, FormValueService, FormatTranslatorService, GreyBarService, HRef, HeaderBarComponent, HeadersModule, HttpError, HttpErrorService, HttpService, IsCompoundPipe, IsMandatoryPipe, IsReadOnlyAndNotCollectionPipe, IsReadOnlyPipe, JudicialworkerService, Jurisdiction, JurisdictionService, LabelFieldComponent, LabelSubstitutorDirective, LabelSubstitutorModule, LanguageInterpreterDisplayPipe, LinkCaseReason, LinkCasesComponent, LinkCasesFromReasonValuePipe, LinkCasesReasonValuePipe, LinkDetails, LinkFromReason, LinkReason, LinkedCasesErrorMessages, LinkedCasesEventTriggers, LinkedCasesFromTableComponent, LinkedCasesPages, LinkedCasesResponse$1 as LinkedCasesResponse, LinkedCasesToTableComponent, LoadingModule, LoadingService, LoadingSpinnerComponent, LoadingSpinnerModule, MEDIA_VIEWER_LOCALSTORAGE_KEY, MULTIPLE_TASKS_FOUND, ManageCaseFlagsComponent, ManageCaseFlagsLabelDisplayPipe, MarkdownComponent, MarkdownComponentModule, MoneyGbpInputComponent, MultipageComponentStateService, MultipleTasksExistComponent, NavigationComponent, NavigationItemComponent, NavigationNotifierService, NavigationOrigin, NoLinkedCasesComponent, NoTasksAvailableComponent, NotificationBannerComponent, NotificationBannerHeaderClass, NotificationBannerType, OrderService, OrderSummary, OrganisationConverter, OrganisationService, PageValidationService, PaginationComponent, PaginationMetadata, PaginationModule, PaletteContext, PaletteModule, PaletteService, PaletteUtilsModule, Patterns, PaymentField, PhaseComponent, PipesModule, PlaceholderService, PrintUrlPipe, Profile, ProfileNotifier, ProfileService, QualifyingQuestionDetailComponent, QualifyingQuestionOptionsComponent, QualifyingQuestionService, QualifyingQuestionsErrorMessage, QueryAttachmentsReadComponent, QueryCaseDetailsHeaderComponent, QueryCheckYourAnswersComponent, QueryConfirmationComponent, QueryCreateContext, QueryDetailsComponent, QueryEventCompletionComponent, QueryItemResponseStatus, QueryListComponent, QueryListData, QueryListItem, QueryManagementService, QueryWriteAddDocumentsComponent, QueryWriteDateInputComponent, QueryWriteRaiseQueryComponent, QueryWriteRespondToQueryComponent, RaiseQueryErrorMessage, ReadCaseFlagFieldComponent, ReadCaseLinkFieldComponent, ReadCollectionFieldComponent, ReadComplexFieldCollectionTableComponent, ReadComplexFieldComponent, ReadComplexFieldRawComponent, ReadComplexFieldTableComponent, ReadCookieService, ReadDateFieldComponent, ReadDocumentFieldComponent, ReadDynamicListFieldComponent, ReadDynamicMultiSelectListFieldComponent, ReadDynamicRadioListFieldComponent, ReadEmailFieldComponent, ReadFieldsFilterPipe, ReadFixedListFieldComponent, ReadFixedRadioListFieldComponent, ReadJudicialUserFieldComponent, ReadLinkedCasesFieldComponent, ReadMoneyGbpFieldComponent, ReadMultiSelectListFieldComponent, ReadNumberFieldComponent, ReadOrderSummaryFieldComponent, ReadOrderSummaryRowComponent, ReadOrganisationFieldComponent, ReadOrganisationFieldRawComponent, ReadOrganisationFieldTableComponent, ReadPhoneUKFieldComponent, ReadQueryManagementFieldComponent, ReadTextAreaFieldComponent, ReadTextFieldComponent, ReadYesNoFieldComponent, RefdataCaseFlagType, RemoveDialogComponent, RequestOptionsBuilder, RespondToQueryErrorMessages, RetryUtil, RouterHelperService, RouterLinkComponent, SaveOrDiscardDialogComponent, SearchFiltersComponent, SearchFiltersModule, SearchFiltersWrapperComponent, SearchInput, SearchLanguageInterpreterComponent, SearchLanguageInterpreterErrorMessage, SearchLanguageInterpreterStep, SearchResultComponent, SearchResultModule, SearchResultView, SearchResultViewColumn, SearchResultViewItem, SearchResultViewItemComparatorFactory, SearchService, SelectFlagErrorMessage, SelectFlagLocationComponent, SelectFlagLocationErrorMessage, SelectFlagTypeComponent, SelectFlagTypeErrorMessage, SessionErrorPageComponent, SessionErrorRoute, SessionJsonErrorLogger, SessionStorageGuard, SessionStorageService, ShowCondition, SortOrder$1 as SortOrder, SortParameters, SortSearchResultPipe, StructuredLoggerService, TabComponent, TableColumnConfig, TableConfig, TabsComponent, TabsModule, TaskAssignedComponent, TaskCancelledComponent, TaskConflictComponent, TaskUnassignedComponent, Terms, TestRouteSnapshotBuilder, TranslatedMarkdownDirective, TranslatedMarkdownModule, UnLinkCasesComponent, UnsupportedFieldComponent, UpdateFlagAddTranslationErrorMessage, UpdateFlagAddTranslationFormComponent, UpdateFlagAddTranslationStep, UpdateFlagComponent, UpdateFlagErrorMessage, UpdateFlagStep, UpdateFlagTitleDisplayPipe, WaysToPayFieldComponent, WindowService, Wizard, WizardFactoryService, WizardPage, WizardPageField, WorkAllocationService, WorkbasketFiltersComponent, WorkbasketFiltersModule, WorkbasketInput, WorkbasketInputFilterService, WorkbasketInputModel, WriteAddressFieldComponent, WriteCaseFlagFieldComponent, WriteCaseLinkFieldComponent, WriteCollectionFieldComponent, WriteComplexFieldComponent, WriteDateContainerFieldComponent, WriteDateFieldComponent, WriteDocumentFieldComponent, WriteDynamicListFieldComponent, WriteDynamicMultiSelectListFieldComponent, WriteDynamicRadioListFieldComponent, WriteEmailFieldComponent, WriteFixedListFieldComponent, WriteFixedRadioListFieldComponent, WriteJudicialUserFieldComponent, WriteLinkedCasesFieldComponent, WriteMoneyGbpFieldComponent, WriteMultiSelectListFieldComponent, WriteNumberFieldComponent, WriteOrderSummaryFieldComponent, WriteOrganisationComplexFieldComponent, WriteOrganisationFieldComponent, WritePhoneUKFieldComponent, WriteTextAreaFieldComponent, WriteTextFieldComponent, WriteYesNoFieldComponent, YesNoService, aCaseField, caseMessagesMockData, createACL, createCaseEventTrigger, createCaseField, createComplexFieldOverride, createFieldType, createFixedListFieldType, createHiddenComplexFieldOverride, createMultiSelectListFieldType, createWizardPage, createWizardPageField, editorRouting, initDialog, newCaseField, safeJsonParse, textFieldType, viewerRouting };
export type { AccessManagementBasicViewMockModel, AccessManagementRequestReviewMockModel, AlertLevel, CaseEditCaseSubmit, CaseEditGenerateCaseEventData, CaseEditGetNextPage, CaseEditSubmitForm, CaseEditValidationError, CaseEditonEventCanBeCompleted, CaseFlagState, CaseMessage, CaseQueriesCollection, CaseTypeQualifyingQuestions, ChallengedAccessRequest, DisplayedAccessReason$1 as DisplayedAccessReason, ErrorMessage, EventCompletionComponentEmitter, EventCompletionStateMachineContext, FieldTypeEnum, FlagDetail, FlagDetailDisplay, FlagDetailDisplayWithFormGroupPath, FlagPath, Flags, FlagsWithFormGroupPath, Journey, JourneyInstigator, Language, LinkedCasesState, NotificationBannerConfig, OptionsType, Orderable, Organisation, OrganisationAddress, OrganisationSuperUser, OrganisationVm, Predicate, QmCaseQueriesCollection, QualifyingQuestion, QueryListColumn, QueryMessage, QueryMessageDocument, RequestedRole, RequestedRoleNote, ReviewSpecificAccessRequest, RoleAssignmentResponse, RoleCategory, RoleClassification, RoleGrantTypeCategory, RoleRequest, RoleRequestPayload, RoleType, SearchResultViewItemComparator, SearchView, ServiceConfig, SimpleOrganisationModel, SpecificAccessRequest, StructuredLogEntry, StructuredLogLevel, TaskSearchParameter, TaskSearchParameters, WAFeatureConfig };
//# sourceMappingURL=index.d.ts.map
